# UniAble dashboard integration updates

## Academic documents

- The standalone **Study materials** item has been removed from the administrator navigation and its legacy admin-only upload endpoints have been retired.
- Administrators upload documents from **Admin dashboard → Academic management → Modules → Academic documents**.
- The document binary is uploaded to Firebase Storage; its title, module, file name, Storage path, content type and publication state are saved in Firestore (`studyMaterials`). This means the document list is loaded from the shared database when the application is reopened rather than relying on browser memory.
- Documents can be opened from Academic management and published/unpublished for students enrolled in the selected module.
- Supported file types are PDF, DOC, DOCX, PPT and PPTX. Files must be smaller than 20 MB.
- Deploy the repository's `storage.rules` to the Firebase Storage bucket used by the app. The existing rules permit authenticated reads and restrict uploads to an administrator's own storage folder.

## Volunteer accounts

- Volunteer registration is clearly labelled as an application to become a UniAble volunteer.
- Registration verification is email OTP only; the SMS choice has been removed from the signup verification screen.
- Volunteer registration is saved under the signed-in volunteer account. Volunteer account availability and peer-request status are included in the administrator reporting data.

## Security accounts

- Security registration is labelled as a Campus Security application and requires a valid email address plus email OTP verification.
- A newly verified security application remains pending until an administrator enables it under **Staff management**. The backend blocks access to the security workspace until approval.
- Security sign-in and dashboard pages use a restrained security accent while retaining UniAble's overall design language.

## Administrator visibility

- Volunteer availability and support-request updates are available in administrator reports.
- Security alert history, including active/acknowledged/resolved status, is available in the **Campus security alerts** report.
- Administrator reports refresh automatically every 30 seconds and can also be refreshed manually.

## Configuration and verification

- Email OTP delivery requires the backend's existing Resend configuration (`RESEND_API_KEY`, `RESEND_FROM_EMAIL`, and `OTP_SECRET`). See `backend/.env.example`.
- Install frontend dependencies with `npm ci` in `frontend`, then run `npm run build`.
- Backend JavaScript syntax and all frontend/backend JavaScript/JSX parser syntax checks passed during this update. A full Vite production build could not be completed in this environment because the frontend npm dependencies were not fully available for installation.
