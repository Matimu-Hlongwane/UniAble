
import { FieldPath } from "firebase-admin/firestore";
import { getAdminDb } from "./firebase.js";
import { getSupabase } from "./supabase.js";

const PAGE_SIZE = 500;

// Start with one low-risk collection to test the connection.
// We will expand this list after the first backup succeeds.
const COLLECTIONS_TO_BACKUP = ["modules"];

function makeJsonSafe(value) {
  if (value === null || value === undefined) {
    return value ?? null;
  }

  // Convert Firestore Timestamp values into readable ISO dates.
  if (typeof value.toDate === "function") {
    return value.toDate().toISOString();
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  if (Array.isArray(value)) {
    return value.map(makeJsonSafe);
  }

  if (typeof value === "object") {
    // Preserve Firestore document references as their paths.
    if (typeof value.path === "string" && value.firestore) {
      return {
        __type: "DocumentReference",
        path: value.path
      };
    }

    // Preserve Firestore geographic points.
    if (
      typeof value.latitude === "number" &&
      typeof value.longitude === "number"
    ) {
      return {
        __type: "GeoPoint",
        latitude: value.latitude,
        longitude: value.longitude
      };
    }

    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [
        key,
        makeJsonSafe(item)
      ])
    );
  }

  return value;
}

function getSourceUpdatedAt(data) {
  const value = data.updatedAt || data.createdAt || null;

  if (!value) return null;

  if (typeof value.toDate === "function") {
    return value.toDate().toISOString();
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  if (typeof value === "string") {
    return value;
  }

  if (typeof value === "number") {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date.toISOString();
  }

  return null;
}

export async function runFirebaseBackup() {
  const firestore = getAdminDb();
  const supabase = getSupabase();

  const results = [];

  for (const collectionName of COLLECTIONS_TO_BACKUP) {
    let lastDocument = null;
    let collectionCount = 0;

    while (true) {
      let query = firestore
        .collection(collectionName)
        .orderBy(FieldPath.documentId())
        .limit(PAGE_SIZE);

      if (lastDocument) {
        query = query.startAfter(lastDocument);
      }

      const snapshot = await query.get();

      if (snapshot.empty) {
        break;
      }

      const backupRows = snapshot.docs.map(document => {
        const data = document.data() || {};

        return {
          source_collection: collectionName,
          source_document_id: document.id,
          document_data: makeJsonSafe(data),
          source_updated_at: getSourceUpdatedAt(data),
          backed_up_at: new Date().toISOString()
        };
      });

      const { error } = await supabase
        .from("uniable_backups")
        .upsert(backupRows, {
          onConflict: "source_collection,source_document_id"
        });

      if (error) {
        throw new Error(
          `Supabase backup failed for ${collectionName}: ${error.message}`
        );
      }

      collectionCount += backupRows.length;
      lastDocument = snapshot.docs[snapshot.docs.length - 1];

      if (snapshot.size < PAGE_SIZE) {
        break;
      }
    }

    results.push({
      collection: collectionName,
      documentsBackedUp: collectionCount
    });
  }

  return {
    success: true,
    completedAt: new Date().toISOString(),
    collections: results,
    totalDocuments: results.reduce(
      (total, item) => total + item.documentsBackedUp,
      0
    )
  };
}
