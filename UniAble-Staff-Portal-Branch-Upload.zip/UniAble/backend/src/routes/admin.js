import { Router } from "express";
import { getAdminAuth, getAdminDb } from "../services/firebase.js";
import { requireFirebaseUser, requireRole } from "../middleware/authMiddleware.js";
import { runFirebaseBackup } from "../services/backup.js";

const router = Router();
router.use(requireFirebaseUser, requireRole("admin"));
const db = () => getAdminDb();
const timestamp = () => new Date().toISOString();

// Administrator-only reporting endpoint. Export only the fields needed for reports;
// never return authentication secrets or detailed accessibility/accommodation notes.
// Administrator-only reporting endpoint.
// Returns only the account information required for reports.
// Detailed accessibility/accommodation information is never exported.
router.get("/reports", async (_req, res) => {
  try {
    const database = db();

    const collections = [
      "users",
      "volunteers",
      "attendance",
      "peerRequests",
      "sosAlerts",
      "accessibilityProfiles",
      "announcements",
      "modules",
      "auditLogs"
    ];

    const snapshots = await Promise.all(
      collections.map(name =>
        database.collection(name).limit(5000).get()
      )
    );

    const data = Object.fromEntries(
      collections.map((name, index) => [
        name,
        snapshots[index].docs.map(document => ({
          id: document.id,
          ...(document.data() || {})
        }))
      ])
    );

    // Index volunteer records by their user ID.
    const volunteerMap = new Map(
      data.volunteers.map(volunteer => [
        volunteer.userId || volunteer.id,
        volunteer
      ])
    );

    // Retrieve Firebase Authentication account details.
    // This provides email addresses and original registration dates
    // when older Firestore profiles do not contain those fields.
    const auth = getAdminAuth();
    const authUsers = new Map();

    let pageToken;

    do {
      const result = await auth.listUsers(1000, pageToken);

      for (const account of result.users) {
        authUsers.set(account.uid, account);
      }

      pageToken = result.pageToken;
    } while (pageToken);

    function normaliseDate(value) {
      if (!value) return "";

      if (typeof value.toDate === "function") {
        return value.toDate().toISOString();
      }

      if (value instanceof Date) {
        return value.toISOString();
      }

      if (typeof value === "number") {
        const date = new Date(value);
        return Number.isNaN(date.getTime()) ? "" : date.toISOString();
      }

      const date = new Date(value);

      return Number.isNaN(date.getTime())
        ? String(value)
        : date.toISOString();
    }

    // Build user report records.
    const users = data.users.map(profile => {
      const uid = profile.id;
      const account = authUsers.get(uid);
      const volunteer = volunteerMap.get(uid);

      const storedRole = String(
        profile.role || profile.accountType || ""
      ).trim().toLowerCase();

      let role = storedRole;

      // A real volunteer registration is reliable evidence of
      // volunteer status, even if an older profile says "student".
      if (
        volunteer &&
        (!storedRole || storedRole === "student" || storedRole === "volunteer")
      ) {
        role = "volunteer";
      }

      // Do not guess the role when no reliable information exists.
      const allowedRoles = new Set([
        "student",
        "volunteer",
        "security",
        "admin",
        "lecturer",
        "disability_office"
      ]);

      if (!allowedRoles.has(role)) {
        role = "unassigned";
      }

      const fullName =
        profile.fullName ||
        profile.displayName ||
        profile.name ||
        account?.displayName ||
        volunteer?.name ||
        "";

      const email =
        profile.email ||
        account?.email ||
        "";

      const disabled =
        account?.disabled === true ||
        profile.isActive === false ||
        String(profile.accessStatus || "").toLowerCase() === "disabled";

      const createdAt = normaliseDate(
        profile.createdAt ||
        profile.registeredAt ||
        account?.metadata?.creationTime ||
        volunteer?.createdAt ||
        profile.roleAssignedAt
      );

      return {
        id: uid,
        fullName,
        email,
        role,
        accountType: role,
        department: profile.department || profile.departmentName || "",
        accountStatus: disabled
          ? (profile.status === "pending_approval" ? "Pending approval" : "Disabled")
          : profile.accountVerificationRequired === true && profile.accountVerified !== true
            ? "Email not verified"
            : "Active",
        volunteerAvailability: volunteer ? (volunteer.available ? "Available" : "Unavailable") : "—",
        createdAt
      };
    });

    // Separate report categories.
    const students = users.filter(user => user.role === "student");
    const volunteers = users.filter(user => user.role === "volunteer");
    const security = users.filter(user => user.role === "security");

    // Only volunteers and security personnel are included in
    // this combined staff report. Administrators are excluded.
    const staff = users.filter(user =>
      ["volunteer", "security"].includes(user.role)
    );

    const unassigned = users.filter(user => user.role === "unassigned");

    // Attendance records.
    const attendance = data.attendance.map(item => ({
      id: item.id,
      studentId: item.studentId || "",
      date: normaliseDate(item.date || item.createdAt),
      session: item.session || item.moduleId || "",
      status: item.status || "",
      createdAt: normaliseDate(
        item.createdAt || item.updatedAt || item.date
      )
    }));

    // Campus security alert history, including acknowledgement and resolution changes.
    const securityAlerts = data.sosAlerts.map(item => ({
      id: item.id,
      studentId: item.studentId || "",
      status: item.status || "active",
      source: item.source || "",
      createdAt: normaliseDate(item.createdAt || item.updatedAt),
      updatedAt: normaliseDate(item.updatedAt),
      acknowledgedBy: item.acknowledgedBy || "",
      resolvedAt: normaliseDate(item.resolvedAt)
    }));

    // Peer support requests.
    const requests = data.peerRequests.map(item => ({
      id: item.id,
      type: item.type || "General assistance",
      status: item.status || "open",
      priority: item.priority || "Normal",
      createdAt: normaliseDate(
        item.createdAt || item.updatedAt
      )
    }));

    // Announcements.
    const announcements = data.announcements.map(item => ({
      id: item.id,
      title: item.title || "",
      priority: item.priority || "normal",
      published: item.published !== false,
      createdAt: normaliseDate(item.createdAt)
    }));

    // Academic modules.
    const modules = data.modules.map(item => ({
      id: item.id,
      code: item.code || "",
      name: item.name || "",
      assignedStudents: Array.isArray(item.studentIds)
        ? item.studentIds.length
        : 0,
      createdAt: normaliseDate(item.createdAt)
    }));

    // System activity.
    const auditLogs = data.auditLogs.map(item => ({
      id: item.id,
      action: item.action || item.type || "Activity",
      actorRole: item.actorRole || "",
      createdAt: normaliseDate(
        item.createdAt || item.timestamp
      )
    }));

    const accessibilityCount = data.accessibilityProfiles.length;

    return res.json({
      generatedAt: new Date().toISOString(),

      summary: {
        totalUsers: users.length,
        students: students.length,
        volunteers: volunteers.length,
        security: security.length,
        staff: staff.length,
        unassignedAccounts: unassigned.length,
        attendanceRecords: attendance.length,
        supportRequests: requests.length,
        accessibilityProfiles: accessibilityCount
      },

      reports: {
        users,
        students,
        volunteers,
        security,
        staff,
        unassigned,
        attendance,
        requests,
        securityAlerts,
        announcements,
        modules,
        auditLogs
      },

      accessibility: {
        profilesCount: accessibilityCount
      }
    });
  } catch (error) {
    console.error("Generate admin reports:", error);

    return res.status(500).json({
      error: "Could not generate administration reports."
    });
  }
});

// User directory: expose only the fields required for administration.
router.get("/users", async (_req, res) => {
  try {
    const snapshot = await db().collection("users").limit(2000).get();
    const users = snapshot.docs.map(document => {
      const item = document.data() || {};
      return {
        id: document.id,
        uid: document.id,
        firstName: item.firstName || "",
        lastName: item.lastName || "",
        displayName: item.displayName || "",
        email: item.email || "",
        role: item.role || "unassigned",
        status: item.status || "unknown",
        approvalStatus: item.approvalStatus || "",
        isActive: item.isActive !== false,
        createdAt: item.createdAt || null
      };
    });
    return res.json({ users });
  } catch (error) {
    console.error("Load admin user directory:", error);
    return res.status(500).json({ error: "Could not load user accounts." });
  }
});

router.get("/departments", async (_req, res) => {
  try {
    const snapshot = await db().collection("departments").orderBy("name").limit(500).get();
    return res.json({ departments: snapshot.docs.map(document => ({ id: document.id, ...document.data() })) });
  } catch (error) {
    console.error("Load departments:", error);
    return res.status(500).json({ error: "Could not load departments." });
  }
});

router.post("/departments", async (req, res) => {
  try {
    const name = String(req.body?.name || "").trim().slice(0, 120);
    const code = String(req.body?.code || "").trim().toUpperCase().slice(0, 20);
    const contactEmail = String(req.body?.contactEmail || "").trim().toLowerCase().slice(0, 254);
    if (!name || !code) return res.status(400).json({ error: "Department name and code are required." });
    const existing = await db().collection("departments").where("code", "==", code).limit(1).get();
    if (!existing.empty) return res.status(409).json({ error: "A department with this code already exists." });
    const record = { name, code, contactEmail, createdBy: req.firebaseToken.uid, createdAt: timestamp(), updatedAt: timestamp() };
    const ref = await db().collection("departments").add(record);
    await db().collection("auditLogs").add({ action: "department_created", actorId: req.firebaseToken.uid, actorRole: "admin", targetId: ref.id, createdAt: timestamp() });
    return res.status(201).json({ department: { id: ref.id, ...record } });
  } catch (error) {
    console.error("Create department:", error);
    return res.status(500).json({ error: "Could not create department." });
  }
});

router.delete("/departments/:id", async (req, res) => {
  try {
    await db().collection("departments").doc(req.params.id).delete();
    await db().collection("auditLogs").add({ action: "department_deleted", actorId: req.firebaseToken.uid, actorRole: "admin", targetId: req.params.id, createdAt: timestamp() });
    return res.json({ success: true });
  } catch (error) {
    console.error("Delete department:", error);
    return res.status(500).json({ error: "Could not delete department." });
  }
});

router.get("/settings", async (_req, res) => {
  try {
    const snapshot = await db().collection("system").doc("settings").get();
    return res.json({ settings: snapshot.exists ? snapshot.data() : { institutionName: "UniAble", campusName: "", supportEmail: "" } });
  } catch (error) {
    return res.status(500).json({ error: "Could not load system settings." });
  }
});

router.patch("/settings", async (req, res) => {
  try {
    const allowed = ["institutionName", "campusName", "supportEmail"];
    const updates = {};
    for (const key of allowed) {
      if (Object.hasOwn(req.body || {}, key)) updates[key] = String(req.body[key] || "").trim().slice(0, 254);
    }
    updates.updatedAt = timestamp();
    updates.updatedBy = req.firebaseToken.uid;
    await db().collection("system").doc("settings").set(updates, { merge: true });
    await db().collection("auditLogs").add({ action: "system_settings_updated", actorId: req.firebaseToken.uid, actorRole: "admin", createdAt: timestamp() });
    return res.json({ success: true, settings: updates });
  } catch (error) {
    console.error("Update system settings:", error);
    return res.status(500).json({ error: "Could not save system settings." });
  }
});

router.get("/audit-logs", async (_req, res) => {
  try {
    const snapshot = await db().collection("auditLogs").orderBy("createdAt", "desc").limit(500).get();
    return res.json({ logs: snapshot.docs.map(document => ({ id: document.id, ...document.data() })) });
  } catch (error) {
    console.error("Load audit logs:", error);
    return res.status(500).json({ error: "Could not load audit logs." });
  }
});

// Announcements are visible to signed-in students and staff through the shared collection.
router.get("/announcements", async (_req, res) => {
  try {
    const snapshot = await db().collection("announcements").orderBy("createdAt", "desc").limit(100).get();
    res.json({ announcements: snapshot.docs.map(d => ({ id: d.id, ...d.data() })) });
  } catch (error) {
    console.error("Load announcements:", error);
    res.status(500).json({ error: "Could not load announcements." });
  }
});

router.post("/announcements", async (req, res) => {
  try {
    const title = String(req.body?.title || "").trim();
    const message = String(req.body?.message || "").trim();
    const priority = ["normal", "important", "urgent"].includes(req.body?.priority) ? req.body.priority : "normal";
    if (!title || !message) return res.status(400).json({ error: "Announcement title and message are required." });
    const record = { title, message, priority, published: req.body?.published !== false, createdBy: req.firebaseToken.uid, createdAt: timestamp(), updatedAt: timestamp() };
    const ref = await db().collection("announcements").add(record);
    res.status(201).json({ announcement: { id: ref.id, ...record } });
  } catch (error) {
    console.error("Create announcement:", error);
    res.status(500).json({ error: "Could not create announcement." });
  }
});

router.patch("/announcements/:id", async (req, res) => {
  try {
    const changes = {};
    for (const key of ["title", "message", "priority", "published"]) if (Object.hasOwn(req.body || {}, key)) changes[key] = req.body[key];
    if (changes.title !== undefined) changes.title = String(changes.title).trim();
    if (changes.message !== undefined) changes.message = String(changes.message).trim();
    if (changes.priority !== undefined && !["normal", "important", "urgent"].includes(changes.priority)) return res.status(400).json({ error: "Invalid announcement priority." });
    changes.updatedAt = timestamp();
    await db().collection("announcements").doc(req.params.id).update(changes);
    res.json({ success: true });
  } catch (error) {
    console.error("Update announcement:", error);
    res.status(500).json({ error: "Could not update announcement." });
  }
});

router.delete("/announcements/:id", async (req, res) => {
  try { await db().collection("announcements").doc(req.params.id).delete(); res.json({ success: true }); }
  catch (error) { res.status(500).json({ error: "Could not delete announcement." }); }
});

router.get("/students", async (_req, res) => {
  try {
    const [users, profiles] = await Promise.all([db().collection("users").get(), db().collection("accessibilityProfiles").get()]);
    const profileMap = new Map(profiles.docs.map(d => [d.id, d.data()]));
    const students = users.docs
      .filter(d => {
        const data = d.data() || {};
        const role = String(data.role || "student").toLowerCase();
        const accessibility = String(data.accessibility || "").trim().toLowerCase();
        return role === "student" && (profileMap.has(d.id) || Boolean(data.accessibilityProfile || data.accessibilityNeeds || data.disability) || (accessibility && accessibility !== "none"));
      })
      .map(d => ({ id: d.id, ...d.data(), accessibility: profileMap.get(d.id) || d.data()?.accessibilityProfile || d.data()?.accessibility || null }));
    res.json({ students });
  } catch (error) { res.status(500).json({ error: "Could not load student records." }); }
});

router.get("/attendance", async (_req, res) => {
  try {
    const snapshot = await db().collection("attendance").orderBy("date", "desc").limit(500).get();
    res.json({ attendance: snapshot.docs.map(d => ({ id: d.id, ...d.data() })) });
  } catch (error) { res.status(500).json({ error: "Could not load attendance records." }); }
});

router.post("/attendance", async (req, res) => {
  try {
    const studentId = String(req.body?.studentId || "").trim();
    const date = String(req.body?.date || "").trim();
    const status = String(req.body?.status || "").toLowerCase();
    const session = String(req.body?.session || "").trim();
    if (!studentId || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !["present", "absent", "late", "excused"].includes(status)) return res.status(400).json({ error: "Choose a student, valid date and attendance status." });
    const student = await db().collection("users").doc(studentId).get();
    if (!student.exists || String(student.data()?.role || "student") !== "student") return res.status(404).json({ error: "Student account was not found." });
    const id = `${date}_${studentId}_${session.toLowerCase().replace(/[^a-z0-9]+/g, "-") || "general"}`;
    const record = { studentId, date, session, status, notes: String(req.body?.notes || "").trim(), recordedBy: req.firebaseToken.uid, updatedAt: timestamp() };
    await db().collection("attendance").doc(id).set(record, { merge: true });
    res.status(201).json({ attendance: { id, ...record } });
  } catch (error) { console.error("Record disability student attendance:", error); res.status(500).json({ error: "Could not record attendance." }); }
});

// Run a Firebase-to-Supabase backup.
// This endpoint is protected by the admin authentication
// middleware already applied to this router.
router.post("/backup/run", async (_req, res) => {
  try {
    const result = await runFirebaseBackup();

    console.log("Admin backup completed:", result);

    return res.json(result);
  } catch (error) {
    console.error("Admin backup failed:", error);

    return res.status(500).json({
      error: "The backup could not be completed."
    });
  }
});

export default router;
