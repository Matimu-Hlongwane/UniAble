import { getAdminAuth, getAdminDb } from "../services/firebase.js";

const VALID_ROLES = new Set([
  "student",
  "admin",
  "volunteer",
  "disability_office",
  "security",
  "lecturer",
]);

export async function requireFirebaseUser(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ")
      ? header.slice(7).trim()
      : "";

    if (!token) {
      return res.status(401).json({
        error: "Sign in is required."
      });
    }

    // checkRevoked=true also checks whether the Firebase account
    // has been disabled or its refresh tokens have been revoked.
    req.firebaseToken = await getAdminAuth().verifyIdToken(token, true);

    const snapshot = await getAdminDb()
      .collection("users")
      .doc(req.firebaseToken.uid)
      .get();

    if (snapshot.exists) {
      const profile = snapshot.data() || {};

      const isRegistrationStatusRoute =
        req.baseUrl === "/api/auth" &&
        ["/registration/start", "/verification-status"].includes(req.path) ||
        (req.baseUrl === "/api/peer" && req.path === "/volunteers/register" && req.method === "POST");

      if (profile.status === "account_creation_denied") {
        return res.status(403).json({
          error: "Account creation denied. Your UniAble application was declined by an administrator."
        });
      }

      if (profile.status === "pending_approval" && !isRegistrationStatusRoute) {
        return res.status(403).json({
          error: "Your account is awaiting administrator approval."
        });
      }

      if (
        profile.isActive === false &&
        profile.status !== "pending_approval" &&
        profile.status !== "account_creation_denied" &&
        !isRegistrationStatusRoute ||
        profile.accessStatus === "disabled"
      ) {
        return res.status(403).json({
          error: "Your account access has been disabled. Contact your administrator."
        });
      }
    }

    return next();
  } catch (error) {
    console.error("Firebase authentication failed:", error.message);

    return res.status(401).json({
      error: "Your session is invalid, disabled or expired. Please sign in again."
    });
  }
}

export function requireRole(...allowedRoles) {
  const permittedRoles = allowedRoles.map(role =>
    String(role).toLowerCase()
  );

  return async (req, res, next) => {
    try {
      if (!req.firebaseToken?.uid) {
        return res.status(401).json({
          error: "Authentication is required."
        });
      }

      const snapshot = await getAdminDb()
        .collection("users")
        .doc(req.firebaseToken.uid)
        .get();

      if (!snapshot.exists) {
        return res.status(403).json({
          error: "User profile not found."
        });
      }

      const profile = snapshot.data() || {};
      const profileRole = String(profile.role || "student").toLowerCase();

      if (profileRole === "security" && profile.status && profile.status !== "active") {
        return res.status(403).json({
          error: profile.status === "pending_approval"
            ? "Your security application is awaiting administrator approval."
            : "Verify your email address and wait for administrator approval before accessing the security workspace."
        });
      }

      if (
        profile.isActive === false ||
        profile.accessStatus === "disabled"
      ) {
        return res.status(403).json({
          error: profile.status === "pending_approval"
            ? "Your security application is awaiting administrator approval."
            : "Your account access has been disabled."
        });
      }

      if (profile.accountVerificationRequired === true && profile.accountVerified !== true) {
        return res.status(403).json({ error: "Verify your email address before accessing this UniAble feature." });
      }

      const role = String(profile.role || "student").toLowerCase();

      if (!VALID_ROLES.has(role) || !permittedRoles.includes(role)) {
        return res.status(403).json({
          error: "You do not have permission to access this resource."
        });
      }

      req.userRole = role;
      return next();
    } catch (error) {
      console.error("Role verification failed:", error.message);

      return res.status(500).json({
        error: "Could not verify your account permissions."
      });
    }
  };
}
