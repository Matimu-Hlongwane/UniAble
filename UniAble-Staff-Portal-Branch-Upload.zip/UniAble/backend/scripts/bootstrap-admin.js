import "dotenv/config";
import { getAdminAuth, getAdminDb } from "../src/services/firebase.js";

const uid = String(process.argv[2] || "").trim();

if (!uid) {
  console.error("Usage: node scripts/bootstrap-admin.js FIREBASE_UID");
  process.exit(1);
}

try {
  const db = getAdminDb();
  const auth = getAdminAuth();

  const user = await auth.getUser(uid);
  const lockRef = db.collection("system").doc("adminRegistration");
  await db.runTransaction(async (transaction) => {
    const lock = await transaction.get(lockRef);
    const adminsQuery = db.collection("users").where("role", "==", "admin").limit(1);
    const existingAdmins = await transaction.get(adminsQuery);
    if (lock.exists && lock.data()?.closed === true) {
      throw new Error("Admin account creation is permanently closed. UniAble already has its one permitted administrator account.");
    }
    if (!existingAdmins.empty) {
      throw new Error("An administrator already exists. Admin account creation is closed.");
    }
    transaction.set(lockRef, { closed: true, adminUid: uid, closedAt: new Date().toISOString() });
    transaction.set(db.collection("users").doc(uid), {
      role: "admin", email: user.email || null,
      roleAssignedAt: new Date().toISOString(), roleAssignedBy: "initial-bootstrap",
      updatedAt: new Date().toISOString()
    }, { merge: true });
  });


  await auth.setCustomUserClaims(uid, {
    ...(user.customClaims || {}),
    role: "admin"
  });

  console.log("Initial administrator successfully created.");
  console.log("UID:", uid);
  console.log("Email:", user.email || "No email on account");
} catch (error) {
  console.error("Administrator bootstrap failed:", error.message);
  process.exitCode = 1;
}
