
import "dotenv/config";
import { getAdminAuth, getAdminDb } from "../src/services/firebase.js";

const ADMIN_UID = "bPl8vGz4LMgf3c5Yyd8lWeov0i72";
const ADMIN_EMAIL = "uniable.admin@gmail.com";

async function syncAdminClaim() {
  const auth = getAdminAuth();
  const db = getAdminDb();

  // Confirm that the Firestore Admin record exists.
  const profileRef = db.collection("users").doc(ADMIN_UID);
  const profileSnapshot = await profileRef.get();

  if (!profileSnapshot.exists) {
    throw new Error("Admin Firestore profile does not exist.");
  }

  const profile = profileSnapshot.data();

  // Never grant Admin privileges unless Firestore confirms the role.
  if (String(profile.role || "").toLowerCase() !== "admin") {
    throw new Error("Firestore does not identify this account as Admin.");
  }

  // Confirm the Firebase Authentication account.
  const user = await auth.getUser(ADMIN_UID);

  if (user.email?.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
    throw new Error("Firebase account email does not match the expected Admin email.");
  }

  // Preserve existing claims and add the Admin role.
  const existingClaims = user.customClaims || {};

  await auth.setCustomUserClaims(ADMIN_UID, {
    ...existingClaims,
    role: "admin"
  });

  console.log("SUCCESS: Admin custom claim synchronised.");
  console.log("Admin email:", user.email);
  console.log("Admin UID:", user.uid);
  console.log("Role: admin");
}

syncAdminClaim().catch((error) => {
  console.error("Admin claim synchronisation failed:", error.message);
  process.exitCode = 1;
});
