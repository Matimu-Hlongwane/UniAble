# UniAble Firebase setup (required before live sign-up/login)

The `.env` files are included, but Firebase credentials are intentionally blank. They must come from YOUR Firebase project; placeholder or invented values cannot connect to Firebase. Never share the backend private key publicly or commit `.env` files.

## 1. Create/open your Firebase project
1. Open https://console.firebase.google.com/ and create a project (or select the UniAble project).
2. In Project settings (gear icon) > General > Your apps, add a Web app.
3. Copy the Firebase web config values into `frontend/.env`:
   - `VITE_FIREBASE_API_KEY` = `apiKey`
   - `VITE_FIREBASE_AUTH_DOMAIN` = `authDomain`
   - `VITE_FIREBASE_PROJECT_ID` = `projectId`
   - `VITE_FIREBASE_STORAGE_BUCKET` = `storageBucket`
   - `VITE_FIREBASE_MESSAGING_SENDER_ID` = `messagingSenderId`
   - `VITE_FIREBASE_APP_ID` = `appId`

## 2. Enable Firebase services
1. Authentication > Get started > Sign-in method > enable Email/Password.
2. Firestore Database > Create database. Select a region suitable for your users.
3. Storage > Get started, and create the default bucket. Copy the exact bucket name into `VITE_FIREBASE_STORAGE_BUCKET`.
4. In Authentication > Settings > Authorized domains, ensure `localhost` is listed for local testing.

## 3. Configure the backend Admin SDK
1. Firebase Console > Project settings > Service accounts > Generate new private key.
2. Open the downloaded JSON locally. Copy `project_id`, `client_email`, and `private_key` into `backend/.env` as:
   - `FIREBASE_PROJECT_ID` = `project_id`
   - `FIREBASE_CLIENT_EMAIL` = `client_email`
   - `FIREBASE_PRIVATE_KEY` = the full `private_key` value, including BEGIN/END lines. Keep it on one `.env` line with newlines represented as `\n` (the backend converts these back to line breaks).
3. Keep this key private. Do not upload it to GitHub, the frontend, or this chat.

## 4. Run locally (Windows PowerShell)
Terminal 1:
```powershell
cd backend
npm install
npm run dev
```
Terminal 2:
```powershell
cd frontend
npm install
npm run dev
```
Open the Vite URL shown in the terminal (usually http://localhost:5173). Restart the Vite server after changing `.env`.

## 5. Important notes
- Frontend Firebase web config is intended to be included in the browser app; protect data with Firebase Security Rules and Authentication.
- The backend service-account private key is secret and must only exist in `backend/.env` or a secure hosting secret manager.
- The API defaults to `http://localhost:4000/api`; set `VITE_API_URL` in `frontend/.env` only if your backend is at a different URL.
- `ai-service/.env` is for optional AI credentials and is not needed just to configure Firebase login.
- A Firebase project must have Authentication, Firestore and Storage enabled as required by the features being tested. Creating `.env` files alone cannot activate a Firebase project.
