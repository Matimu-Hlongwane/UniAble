# UniAble central administrator changes

## What changed

- Staff sign-in and staff dashboards no longer expose read-aloud, voice-login, microphone or audio controls. The voice-login route has been removed. Student-facing accessibility features remain separate from the staff portal.
- The lecturer dashboard source files have been removed. Lecturer and Disability Office routes now show a retirement notice instead of opening their old dashboards.
- The Admin dashboard now includes academic module/timetable/class management, student support requests, accessibility profiles, announcements, study-material uploads and disability-student attendance.
- Announcements are saved in Firestore and published announcements are returned to signed-in students.
- Study-material files are uploaded to Firebase Storage and their metadata/download URL is saved in Firestore.
- Admin attendance is restricted to student accounts that have an accessibility/disability profile or a non-empty accessibility selection other than `None`.
- Admin creation is one-time only. The bootstrap script uses a Firestore transaction and a permanent `system/adminRegistration` lock. The backend rejects further `/api/auth/admin/register` attempts and the staff-management page explains the restriction. Staff role provisioning does not permit assigning the `admin` role.

## Firebase Storage rules

Copy the contents of `storage.rules` into Firebase Console → Storage → Rules and publish them. These rules allow authenticated students and staff to read study-material attachments while only the administrator account that owns the upload path can write to it. The administrator role is checked against the Firestore `users/{uid}` profile.

Make sure the frontend Firebase configuration includes `VITE_FIREBASE_STORAGE_BUCKET` and that Firebase Storage is enabled for the project.

## One-time administrator setup

Create the initial user in Firebase Authentication, then run the existing bootstrap command once with that user's Firebase UID:

```bash
cd backend
node scripts/bootstrap-admin.js FIREBASE_UID
```

After it succeeds, the lock is stored at `system/adminRegistration`. Do not delete that lock document or run the bootstrap script for another account. If an administrator account already exists in `users`, the script refuses to create another one.

## New backend endpoints

All `/api/admin/*` endpoints require a verified Firebase session and the `admin` role:

- `GET/POST /api/admin/announcements`
- `PATCH/DELETE /api/admin/announcements/:id`
- `GET/POST /api/admin/materials`
- `DELETE /api/admin/materials/:id`
- `GET /api/admin/students`
- `GET/POST /api/admin/attendance`

The signed-in student announcement feed is `GET /api/academics/announcements`. Existing academic module, timetable, support-request and accessibility endpoints are reused by the central administrator.

## Validation

Backend JavaScript files were checked with `node --check`. A full Vite frontend build could not be run in this environment because npm dependencies were not available locally and the package installation timed out; run `npm install` (or `npm ci`) inside `frontend`, then `npm run build` to perform the frontend build in your development environment.

## Follow-up authentication changes (5 November 2026)

- Removed the Create Account link from the Admin sign-in portal.
- Blocked direct Admin sign-up page access with a message directing the user to the existing Admin login.
- Kept Admin account creation disabled; the existing administrator must sign in only.
- Staff sign-in pages opened with a staff portal parameter do not render read-aloud controls or run spoken page guidance.
- Staff sign-up links retain their staff portal parameter and open the registration form in text-only mode.
- Text-only staff sign-up hides the microphone, voice conversation, and return-to-voice controls and does not run speech guidance.
- Removed the Admin registration panel from the Admin dashboard's staff-management screen; assigning staff roles to existing Firebase accounts remains available.
