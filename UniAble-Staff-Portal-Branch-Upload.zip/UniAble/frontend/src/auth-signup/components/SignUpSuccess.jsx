﻿import React from "react";
import { Link } from "react-router-dom";
function SignUpSuccess({
    fullName,
    portal,
    onGoBack
}) {

    return (
        <div className="signup-success">

            <div className="success-icon">
                ✓
            </div>


            <h2>
                {portal === "security" ? "Email verified — approval pending" : portal === "volunteer" ? "Volunteer application verified" : "Account verified"}
            </h2>

            <p>
                Thanks, {fullName}. {portal === "security"
                  ? "Your security application has been submitted. An administrator must activate your account before you can access the security dashboard."
                  : portal === "volunteer"
                    ? "Your volunteer account email has been verified. You can now sign in to your volunteer workspace."
                    : "Your UniAble email address has been verified and your account is ready."}
            </p>

            <p className="success-note">
                {portal === "security" ? "You will be able to use the security dashboard after the administrator approves your access." : "You can now continue to your UniAble workspace."}
            </p>


            {portal && <p className="success-note"><Link to={`/login?portal=${encodeURIComponent(portal)}`}>Continue to {portal === "volunteer" ? "volunteer" : "security"} sign in</Link></p>}

            <button
                type="button"

                className="
          action-button
          secondary-action
          success-back-button
        "

                onClick={onGoBack}
            >

                â† Go Back

            </button>

        </div>
    );
}


export default SignUpSuccess;

