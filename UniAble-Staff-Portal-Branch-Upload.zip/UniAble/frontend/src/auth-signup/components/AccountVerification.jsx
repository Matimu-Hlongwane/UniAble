import React from "react";

export default function AccountVerification({
  stage, code, setCode, busy, error, email,
  onSendEmail, onVerify, onResend, onBack,
}) {
  const inputStyle = { width: "100%", boxSizing: "border-box", padding: "13px", border: "1px solid #777", borderRadius: 9, fontSize: 16, marginTop: 7, marginBottom: 14 };
  const buttonStyle = { padding: "12px 16px", borderRadius: 9, border: "1px solid currentColor", cursor: busy ? "wait" : "pointer", fontSize: 15, fontWeight: 600, margin: "5px 6px 5px 0" };

  return (
    <section aria-labelledby="verification-heading" style={{ maxWidth: 520, margin: "0 auto", padding: 18 }}>
      <h2 id="verification-heading">Verify your UniAble email address</h2>
      {stage === "choose" ? <>
        <p>We will send a one-time verification code to your email address.</p>
        <p><strong>Email address:</strong> {email || "Not available"}</p>
        <button type="button" style={buttonStyle} disabled={busy || !email} onClick={onSendEmail}>{busy ? "Sending…" : "Send verification code to email"}</button>
      </> : <>
        <p>Enter the six-digit code sent to {email}. The code expires after 10 minutes.</p>
        <label htmlFor="verification-code">Six-digit verification code</label>
        <input id="verification-code" type="text" inputMode="numeric" autoComplete="one-time-code" maxLength={6} pattern="[0-9]{6}" value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))} style={inputStyle} />
        <button type="button" style={buttonStyle} disabled={busy || code.length !== 6} onClick={onVerify}>{busy ? "Verifying…" : "Verify email"}</button>
        <button type="button" style={buttonStyle} disabled={busy} onClick={onResend}>Resend email code</button>
        <button type="button" style={buttonStyle} disabled={busy} onClick={onBack}>Back</button>
      </>}
      {error && <p role="alert" style={{ color: "#b00020", marginTop: 12 }}>{error}</p>}
      <p style={{ fontSize: 13, marginTop: 18 }}>Keep your verification code private. UniAble staff will never ask you to share it.</p>
    </section>
  );
}
