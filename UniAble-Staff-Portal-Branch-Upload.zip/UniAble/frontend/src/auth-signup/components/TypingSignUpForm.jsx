import React from "react";
import { useState } from "react";
import accessibilityOptions
  from "../data/accessibilityOptions.json";


function TypingSignUpForm({
  formData,
  errors,
  onInputChange,
  onReturnToVoice,
  onCreateAccount,
  isVolunteer = false,
  isSecurity = false
}) {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="typing-signup">

      <div className="typing-heading">

        <h2>
          {isVolunteer ? "Volunteer Application" : isSecurity ? "Security Application" : "Type Your Details"}
        </h2>

        <p>
          {isVolunteer
            ? "Tell us how you can contribute your time and skills to support UniAble students."
            : isSecurity
              ? "Register your details for a campus security account. Your access will be reviewed by the UniAble administrator before activation."
              : "Complete the information below to continue."}
        </p>

      </div>


      <div className="typing-card">


        {/* Staff applicants enter first and last names separately. */}
        {isVolunteer || isSecurity ? (
          <div className="form-grid">
            <div className="form-group">
              <label htmlFor="firstName">First Name *</label>
              <input
                type="text"
                id="firstName"
                name="firstName"
                placeholder="Enter your first name"
                value={formData.firstName || ""}
                onChange={onInputChange}
                autoComplete="given-name"
                required
                aria-invalid={Boolean(errors.firstName)}
              />
              {errors.firstName && <p className="form-error">{errors.firstName}</p>}
            </div>
            <div className="form-group">
              <label htmlFor="lastName">Last Name *</label>
              <input
                type="text"
                id="lastName"
                name="lastName"
                placeholder="Enter your last name"
                value={formData.lastName || ""}
                onChange={onInputChange}
                autoComplete="family-name"
                required
                aria-invalid={Boolean(errors.lastName)}
              />
              {errors.lastName && <p className="form-error">{errors.lastName}</p>}
            </div>
          </div>
        ) : (
          <div className="form-group">
            <label htmlFor="fullName">Full Name</label>
            <input
              type="text"
              id="fullName"
              name="fullName"
              placeholder="Enter your full name"
              value={formData.fullName}
              onChange={onInputChange}
              autoComplete="name"
              aria-invalid={Boolean(errors.fullName)}
            />
            {errors.fullName && <p className="form-error">{errors.fullName}</p>}
          </div>
        )}

        {isVolunteer ? (
          <>
            {/* VOLUNTEER AVAILABILITY */}
            <div className="form-group">
              <label htmlFor="volunteerAvailability">When are you available to volunteer? *</label>
              <select
                id="volunteerAvailability"
                name="volunteerAvailability"
                value={formData.volunteerAvailability || ""}
                onChange={onInputChange}
                aria-invalid={Boolean(errors.volunteerAvailability)}
              >
                <option value="">Select your availability</option>
                <option value="Weekdays">Weekdays</option>
                <option value="Weekends">Weekends</option>
                <option value="Both weekdays and weekends">Both weekdays and weekends</option>
                <option value="Flexible / to be arranged">Flexible / to be arranged</option>
              </select>
              {errors.volunteerAvailability && <p className="form-error">{errors.volunteerAvailability}</p>}
            </div>

            {/* VOLUNTEER SERVICE AREAS */}
            <fieldset className="form-group" style={{ border: 0, padding: 0, margin: 0 }}>
              <legend style={{ fontWeight: 600, marginBottom: 10 }}>What would you be willing to help with? *</legend>
              <p className="signup-password-help">Select all the areas where you can offer support.</p>
              {[
                "Campus navigation and finding classrooms",
                "Getting to and from classes or campus facilities",
                "Study support and note-taking",
                "Technology and digital assistance",
                "Library and learning-material assistance",
                "Events and student activities",
                "General peer support and companionship"
              ].map((area) => (
                <label key={area} style={{ display: "flex", alignItems: "flex-start", gap: 10, margin: "9px 0" }}>
                  <input
                    type="checkbox"
                    name="volunteerServiceAreas"
                    value={area}
                    checked={(formData.volunteerServiceAreas || []).includes(area)}
                    onChange={onInputChange}
                  />
                  <span>{area}</span>
                </label>
              ))}
              {errors.volunteerServiceAreas && <p className="form-error">{errors.volunteerServiceAreas}</p>}
            </fieldset>

            {/* VOLUNTEER EXPERIENCE */}
            <div className="form-group">
              <label htmlFor="volunteerExperience">Relevant skills or experience *</label>
              <textarea
                id="volunteerExperience"
                name="volunteerExperience"
                rows="3"
                placeholder="Tell us about skills, experience, training or languages that could help you support other students. If you are new to volunteering, tell us what strengths you can bring."
                value={formData.volunteerExperience || ""}
                onChange={onInputChange}
                aria-invalid={Boolean(errors.volunteerExperience)}
              />
              {errors.volunteerExperience && <p className="form-error">{errors.volunteerExperience}</p>}
            </div>

            {/* VOLUNTEER MOTIVATION */}
            <div className="form-group">
              <label htmlFor="volunteerMotivation">Why would you like to volunteer with UniAble? *</label>
              <textarea
                id="volunteerMotivation"
                name="volunteerMotivation"
                rows="3"
                placeholder="Briefly explain why you want to support students with disabilities."
                value={formData.volunteerMotivation || ""}
                onChange={onInputChange}
                aria-invalid={Boolean(errors.volunteerMotivation)}
              />
              {errors.volunteerMotivation && <p className="form-error">{errors.volunteerMotivation}</p>}
            </div>
          </>
        ) : !isSecurity ? (
          <>
            {/* ACCESSIBILITY */}
            <div className="form-group">
              <label htmlFor="accessibility">Accessibility Needs</label>
              <select
                id="accessibility"
                name="accessibility"
                value={formData.accessibility}
                onChange={onInputChange}
                aria-invalid={Boolean(errors.accessibility)}
              >
                {accessibilityOptions.map((option) => (
                  <option key={option.value || "default"} value={option.value}>{option.label}</option>
                ))}
              </select>
              {errors.accessibility && <p className="form-error">{errors.accessibility}</p>}
            </div>

            {/* ADDITIONAL INFORMATION */}
            <div className="form-group">
              <label htmlFor="additionalNeeds">Additional Information</label>
              <textarea
                id="additionalNeeds"
                name="additionalNeeds"
                rows="3"
                placeholder="Tell us how UniAble can better support you"
                value={formData.additionalNeeds}
                onChange={onInputChange}
              />
            </div>
          </>
        ) : null}

        {/* EMAIL */}

        <div className="form-group">

          <label htmlFor="email">
            Email Address
          </label>

          <input
            type="email"
            id="email"
            name="email"

            placeholder="example@email.com"

            value={formData.email}

            onChange={onInputChange}

            autoComplete="email"

            aria-invalid={
              Boolean(errors.email)
            }
          />

          {errors.email && (

            <p className="form-error">
              {errors.email}
            </p>

          )}

        </div>


        {/* PASSWORD */}

        <div className="form-group">

          <label htmlFor="password">
            Password
          </label>

          <div className="signup-password-field">
            <input
              type={showPassword ? "text" : "password"}
              id="password"
              name="password"
              placeholder="8+ characters, uppercase, lowercase, number and symbol"
              value={formData.password}
              onChange={onInputChange}
              autoComplete="new-password"
              aria-invalid={Boolean(errors.password)}
              aria-describedby="signup-password-help"
            />
            <button
              type="button"
              className="signup-password-toggle"
              aria-controls="password"
              aria-pressed={showPassword}
              onClick={() => setShowPassword((visible) => !visible)}
            >
              {showPassword ? "Hide password" : "Show password"}
            </button>
          </div>
          <p id="signup-password-help" className="signup-password-help">
            Use your screen reader, keyboard, or password manager if helpful.
          </p>

          {errors.password && (

            <p className="form-error">
              {errors.password}
            </p>

          )}

        </div>

      </div>


      <div className="typing-actions">

        <button
          type="button"

          className="
            action-button
            primary-action
          "

          onClick={
            onCreateAccount
          }
        >

          Create Account

        </button>


        {onReturnToVoice && (
          <button
            type="button"
            className="action-button secondary-action"
            onClick={onReturnToVoice}
          >
            Return to Voice Mode
          </button>
        )}

      </div>

    </div>
  );
}


export default TypingSignUpForm;




