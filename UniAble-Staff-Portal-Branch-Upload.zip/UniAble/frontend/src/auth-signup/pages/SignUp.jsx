import React, { useEffect, useState } from "react";
import { api } from "../../services/api";
import { Link } from "react-router-dom";
import {
    createAccountWithEmailPassword,
    startAccountVerification,
    getVerificationStatus,
    getCurrentUser,
    subscribeToAuth,
    sendEmailOtp,
    verifyEmailOtp,
} from "../../services/firebaseAuth";
import { speak } from "../../services/speechService";

import "../styles/signup.css";

import SignUpHeader from "../components/SignUpHeader";
import ProgressBar from "../components/ProgressBar";
import MicrophoneButton from "../components/MicrophoneButton";
import ConversationCard from "../components/ConversationCard";
import DetectedInfo from "../components/DetectedInfo";
import SignUpActions from "../components/SignUpActions";
import TypingSignUpForm from "../components/TypingSignUpForm";
import SignUpSuccess from "../components/SignUpSuccess";
import AccountVerification from "../components/AccountVerification";

import {
    isSpeechRecognitionSupported,
    requestMicrophonePermission,
    startSpeechRecognition,
    speakText
} from "../services/speechService";

import {
    detectAccessibility
} from "../utils/accessibilityDetector";

import {
    normalizeSpokenEmail
} from "../utils/emailUtils";

import {
    isValidEmail,
    validateSignUpForm
} from "../utils/validation";


function SignUp() {

    // Staff registration is text-only. Student registration retains its optional accessibility voice mode.
    const portal = new URLSearchParams(window.location.search).get("portal");
    const staffPortal = Boolean(portal);
    const adminPortal = portal === "admin";
    const signupRole = portal === "volunteer" ? "volunteer" : portal === "security" ? "security" : "student";

    /* =========================================
       PAGE MODE
       ========================================= */

    const [mode, setMode] =
        useState(staffPortal ? "typing" : "voice");


    /* =========================================
       VALIDATION
       ========================================= */

    const [errors, setErrors] = useState({});
    const [verificationStage, setVerificationStage] = useState(null);
    const [verificationCode, setVerificationCode] = useState("");
    const [verificationBusy, setVerificationBusy] = useState(false);
    const [verificationError, setVerificationError] = useState("");


    const [
        registrationValidated,
        setRegistrationValidated
    ] = useState(false);


    /* =========================================
       VOICE STATE
       ========================================= */

    const [isListening, setIsListening] =
        useState(false);


    /*
      Voice Steps
  
      0 = Full Name
      1 = Accessibility Needs
      2 = Email Address
      3 = Voice Section Complete
    */

    const [voiceStep, setVoiceStep] =
        useState(0);


    const [
        voiceQuestion,
        setVoiceQuestion
    ] = useState(
        "Speak your full name to continue"
    );


    /* =========================================
       CONVERSATION
       ========================================= */

    const [messages, setMessages] =
        useState([
            {
                speaker: "UNIABLE",
                text:
                    "Welcome! Let's set up your account together. What's your full name?"
            }
        ]);


    /* =========================================
       FORM DATA
       ========================================= */

    const [formData, setFormData] =
        useState({

            fullName: "",
            firstName: "",
            lastName: "",
            accountType: signupRole,
            accessibility: "",
            additionalNeeds: "",
            volunteerAvailability: "",
            volunteerServiceAreas: [],
            volunteerExperience: "",
            volunteerMotivation: "",
            email: "",
            password: ""

        });


    useEffect(() => {
        if (staffPortal) return undefined;
        let cancelled = false;
        let timer;

        async function announceSignup() {
            try {
                const profile = JSON.parse(
                    window.localStorage.getItem("uniableAccessibilityProfile") || "null"
                );
                const voiceFirst =
                    profile?.id === "blind" ||
                    window.localStorage.getItem("uniableVoiceFirstEnabled") === "true";

                if (!voiceFirst || cancelled) return;

                timer = window.setTimeout(async () => {
                    try {
                        await speak(
                            "UniAble create account page. Enter your full name, accessibility needs, email address, and password. You can choose voice-assisted signup or switch to typing. The microphone only listens when you activate it. Do not speak your password aloud.",
                            { locale: "en-ZA", rate: 0.94 }
                        );
                    } catch (error) {
                        console.warn("Signup page spoken guidance failed:", error);
                    }
                }, 600);
            } catch (error) {
                console.warn("Could not determine signup voice-first preference:", error);
            }
        }

        announceSignup();
        return () => {
            cancelled = true;
            if (timer) window.clearTimeout(timer);
        };
    }, [staffPortal]);

    useEffect(() => {
        let active = true;
        const unsubscribe = subscribeToAuth(async (user) => {
            if (!user) return;
            try {
                const status = await getVerificationStatus();
                if (active && status.required && !status.verified) {
                    setFormData((previous) => ({ ...previous, email: user.email || previous.email, fullName: user.displayName || previous.fullName }));
                    setVerificationStage("choose");
                    setMode("typing");
                } else if (active && status.required && status.verified) {
                    setRegistrationValidated(true);
                }
            } catch (error) {
                console.warn("Could not resume pending UniAble verification:", error);
            }
        });
        return () => { active = false; unsubscribe?.(); };
    }, []);

    /* =========================================
       SIGNUP PAGE ENTRY GUIDANCE
       ========================================= */

    useEffect(() => {
        if (staffPortal) return undefined;

        if (registrationValidated) {
            speakText(
                "Your UniAble account details have been submitted successfully."
            );
            return;
        }

        const guidance = mode === "voice"

            ? "Welcome to UniAble sign up. You can complete the first steps by speaking or switch to typing at any time. The microphone is optional. You only need to select Tap to Speak if you want to provide an answer using your voice. I will guide you through your full name, accessibility needs and email address. For your security, your password must be entered using typing mode and will never be read aloud. You can also use your keyboard to navigate the page."

            : "You are now in typing sign up mode. Enter your full name, accessibility needs, email address and password. Your password is private and will never be read aloud. You can use your keyboard to move between fields. You can return to voice sign up if you prefer.";

        const timer = window.setTimeout(() => {
            speakText(guidance);
        }, 600);

        return () => {
            window.clearTimeout(timer);
        };

    }, [mode, registrationValidated, staffPortal]);
    /* =========================================
       SWITCH INPUT MODES
       ========================================= */

    function switchToTyping() {

        setMode("typing");

    }


    function switchToVoice() {

        setMode("voice");

    }


    /* =========================================
       HANDLE TYPED INPUT
       ========================================= */

    function handleInputChange(event) {

        const {
            name,
            value
        } = event.target;


        setFormData((previousData) => {
            if (name === "volunteerServiceAreas") {
                const current = previousData.volunteerServiceAreas || [];
                return {
                    ...previousData,
                    volunteerServiceAreas: event.target.checked
                        ? [...current, value]
                        : current.filter((area) => area !== value)
                };
            }
            const updated = { ...previousData, [name]: value };
            if (name === "firstName" || name === "lastName") {
                updated.fullName = `${name === "firstName" ? value : previousData.firstName} ${name === "lastName" ? value : previousData.lastName}`.trim();
            }
            return updated;
        });


        /*
          Remove the error for the field
          once the user starts correcting it.
        */

        setErrors(
            (previousErrors) => ({

                ...previousErrors,

                [name]: ""

            })
        );

    }


    /* =========================================
       FRONTEND ACCOUNT VALIDATION
       ========================================= */

    async function handleCreateAccount() {
        const validationErrors = validateSignUpForm(formData);
        if (Object.keys(validationErrors).length > 0) { setErrors(validationErrors); return; }
        setErrors({});
        try {
            const applicantName = ["volunteer", "security"].includes(signupRole)
                ? `${formData.firstName} ${formData.lastName}`.trim()
                : formData.fullName.trim();
            const createdUser = await createAccountWithEmailPassword(
                formData.email,
                formData.password,
                applicantName,
                formData.accessibility,
                signupRole
            );

            if (portal === "volunteer") {
                try {
                    await api.registerVolunteer({
                        userId: createdUser.uid,
                        name: applicantName,
                        firstName: formData.firstName.trim(),
                        lastName: formData.lastName.trim(),
                        availability: formData.volunteerAvailability,
                        serviceAreas: formData.volunteerServiceAreas,
                        experience: formData.volunteerExperience.trim(),
                        motivation: formData.volunteerMotivation.trim()
                    });
                } catch (volunteerError) {
                    console.warn(
                        "Account created, but volunteer registration could not reach the Peer Assistance server:",
                        volunteerError
                    );
                    setVerificationError(
                        "Your account was created. Volunteer registration could not reach the server yet; please try again later."
                    );
                }
            }
            setMode("typing");
            if (["volunteer", "security"].includes(signupRole)) {
                // Staff accounts must be approved before OTP verification can begin.
                setVerificationStage("pending_approval");
                return;
            }
            setVerificationStage("choose");
            try {
                await startAccountVerification();
            } catch (setupError) {
                setVerificationError(`Your account was created, but the verification service is not ready: ${setupError.message}`);
            }
        } catch (error) {
            console.error("UniAble registration failed:", error);
            let message = error.message || "We could not create your account. Please try again.";
            if (error.code === "auth/email-already-in-use") message = "An account already exists for this email address. Sign in, then choose Create an account to resume verification if needed.";
            else if (error.code === "auth/weak-password") message = "Your password is too weak. Please choose a stronger password.";
            else if (error.code === "auth/invalid-email") message = "Please enter a valid email address.";
            else if (error.code === "auth/operation-not-allowed") message = "Email and password sign-in is not enabled in your Firebase project.";
            setErrors({ general: message });
        }
    }

    async function handleContinueAfterApproval() {
        setVerificationError("");
        try {
            const result = await startAccountVerification();
            if (result.approvalStatus === "pending") {
                setVerificationError("Your application is still awaiting administrator approval.");
                return;
            }
            setVerificationStage("code");
        } catch (error) {
            setVerificationError(error.message || "Could not check your application status.");
        }
    }

    async function handleSendEmailCode() {
        setVerificationBusy(true); setVerificationError("");
        try {
            await sendEmailOtp();
            setVerificationCode(""); setVerificationStage("code");
        } catch (error) { setVerificationError(error.message || "Could not send the email code."); }
        finally { setVerificationBusy(false); }
    }

    async function handleVerifyCode() {
        setVerificationBusy(true); setVerificationError("");
        try {
            await verifyEmailOtp(verificationCode);
            setVerificationStage(null);
            setRegistrationValidated(true);
        } catch (error) { setVerificationError(error.message || "The code could not be verified. Please try again."); }
        finally { setVerificationBusy(false); }
    }

    async function handleResendCode() {
        return handleSendEmailCode();
    }

    /* =========================================
       ADD CONVERSATION MESSAGE
       ========================================= */

    function addMessage(
        speaker,
        text
    ) {

        setMessages(
            (previousMessages) => [

                ...previousMessages,

                {
                    speaker,
                    text
                }

            ]
        );

    }


    /* =========================================
       PROCESS VOICE ANSWER
       ========================================= */

    function processVoiceAnswer(
        transcript
    ) {

        /*
          Display what the user said.
        */

        addMessage(
            "You",
            transcript
        );


        /* =====================================
           STEP 0 — FULL NAME
           ===================================== */

        if (voiceStep === 0) {

            setFormData(
                (previousData) => ({

                    ...previousData,

                    fullName: transcript

                })
            );


            const response =
                `Thank you, ${transcript}. Do you have any accessibility needs, such as visual, hearing, mobility or speech support?`;


            addMessage(
                "UNIABLE",
                response
            );


            setVoiceQuestion(
                "Tell us about your accessibility needs"
            );


            setVoiceStep(1);


            speakText(
                response
            );


            return;
        }


        /* =====================================
           STEP 1 — ACCESSIBILITY
           ===================================== */

        if (voiceStep === 1) {

            const detectedAccessibility =
                detectAccessibility(
                    transcript
                );


            setFormData(
                (previousData) => ({

                    ...previousData,

                    accessibility:
                        detectedAccessibility

                })
            );


            const response =
                detectedAccessibility === "None"

                    ? "Thank you. No accessibility needs have been selected. Now please say your email address. You can say something like name at gmail dot com."

                    : `Thank you. I've detected ${detectedAccessibility}. Now please say your email address. You can say something like name at gmail dot com.`;


            addMessage(
                "UNIABLE",
                response
            );


            setVoiceQuestion(
                "Say your email address"
            );


            setVoiceStep(2);


            speakText(
                response
            );


            return;
        }


        /* =====================================
           STEP 2 — EMAIL ADDRESS
           ===================================== */

        if (voiceStep === 2) {

            const normalizedEmail =
                normalizeSpokenEmail(
                    transcript
                );


            /*
              Email could not be validated.
            */

            if (
                !isValidEmail(
                    normalizedEmail
                )
            ) {

                const response =
                    `I heard ${normalizedEmail || transcript}, but I couldn't confirm that as a valid email address. Please say it again slowly, for example, name at gmail dot com.`;


                addMessage(
                    "UNIABLE",
                    response
                );


                setVoiceQuestion(
                    "Please say your email address again"
                );


                speakText(
                    response
                );


                /*
                  Keep voiceStep at 2.
                */

                return;
            }


            /*
              Valid email detected.
            */

            setFormData(
                (previousData) => ({

                    ...previousData,

                    email:
                        normalizedEmail

                })
            );


            const response =
                "Thank you. I've saved your email address. For your security, please create your password using typing mode.";


            addMessage(
                "UNIABLE",
                response
            );


            setVoiceQuestion(
                "Email complete. Create your password using typing mode."
            );


            setVoiceStep(3);


            speakText(
                response
            );


            /*
              Give UNIABLE a short moment
              to speak before switching modes.
            */

            setTimeout(
                () => {

                    setMode(
                        "typing"
                    );

                },
                1200
            );


            return;
        }


        /* =====================================
           STEP 3 — VOICE COMPLETE
           ===================================== */

        if (voiceStep === 3) {

            const response =
                "Your voice information is complete. Please finish creating your account using typing mode.";


            addMessage(
                "UNIABLE",
                response
            );


            speakText(
                response
            );


            setMode(
                "typing"
            );

        }

    }


    /* =========================================
       START VOICE RECOGNITION
       ========================================= */

    async function handleStartListening() {

        /*
          Prevent two listening sessions
          at the same time.
        */

        if (isListening) {

            return;

        }


        /*
          Check if browser speech
          recognition is available.
        */

        if (
            !isSpeechRecognitionSupported()
        ) {

            setVoiceQuestion(
                "Voice recognition is not supported on this browser. Please switch to typing."
            );


            return;

        }


        try {

            /*
              Ask user for microphone access.
            */

            await requestMicrophonePermission();


            /*
              Start recognition.
            */

            startSpeechRecognition({

                onStart: () => {

                    setIsListening(
                        true
                    );

                },


                onResult: (
                    transcript
                ) => {

                    processVoiceAnswer(
                        transcript
                    );

                },


                onEnd: () => {

                    setIsListening(
                        false
                    );

                },


                onError: (
                    error
                ) => {

                    console.error(
                        error
                    );


                    setIsListening(
                        false
                    );


                    setVoiceQuestion(
                        error.message
                    );

                }

            });

        }

        catch (error) {

            console.error(
                error
            );


            setIsListening(
                false
            );


            setVoiceQuestion(
                error.message
            );

        }

    }


    /* =========================================
       PAGE
       ========================================= */

    if (adminPortal) {
        return (
            <main className="signup-screen">
                <section className="signup-app" aria-labelledby="admin-signup-restricted">
                    <h1 id="admin-signup-restricted">Administrator registration unavailable</h1>
                    <p>UniAble has one administrator account. New administrator accounts cannot be created. Please sign in using the existing administrator credentials.</p>
                    <p><Link to="/login?portal=admin">Return to administrator sign in</Link></p>
                </section>
            </main>
        );
    }

    return (

        <main className="signup-screen">

            <section className={`signup-app signup-app--${portal || "student"}`}>


                {/* HEADER */}

                {portal === "volunteer" && <div className="role-signup-banner role-signup-banner--volunteer"><strong>Volunteer application</strong><span>Apply to join UniAble's student volunteer team.</span></div>}
                {portal === "security" && <div className="role-signup-banner role-signup-banner--security"><strong>Campus security application</strong><span>Register your email and submit an application for campus security access. An administrator must approve access.</span></div>}
                <SignUpHeader
                    portal={portal}
                    mode={mode}

                    isListening={
                        isListening
                    }

                />


                {/* PROGRESS */}

                <ProgressBar />


                {/* PAGE CONTENT */}

                <div className="signup-content">
                    {errors.general && <p className="form-error" role="alert">{errors.general}</p>}


                    {/* =================================
              VALIDATION SUCCESS SCREEN
              ================================= */}

                    {registrationValidated ? (

                        <SignUpSuccess
                            portal={portal}
                            fullName={
                                formData.fullName
                            }

                            onGoBack={() => {

                                setRegistrationValidated(
                                    false
                                );


                                setMode(
                                    "typing"
                                );

                            }}

                        />

                    ) : verificationStage === "pending_approval" ? (
                        <section className="signup-pending-approval" role="status">
                            <div className="signup-pending-icon">✓</div>
                            <h2>Application submitted</h2>
                            <p>Your {signupRole === "volunteer" ? "volunteer" : "campus security"} application has been sent to the UniAble administrator.</p>
                            <p>You will receive a verification code at <strong>{formData.email}</strong> after your application is approved.</p>
                            {verificationError && <p className="form-error" role="alert">{verificationError}</p>}
                            <button type="button" onClick={handleContinueAfterApproval}>I've been approved — continue</button>
                        </section>
                    ) : verificationStage ? (
                        <AccountVerification
                            stage={verificationStage}
                            code={verificationCode}
                            setCode={setVerificationCode}
                            busy={verificationBusy}
                            error={verificationError}
                            email={formData.email || getCurrentUser()?.email || ""}
                            onSendEmail={handleSendEmailCode}
                            onVerify={handleVerifyCode}
                            onResend={handleResendCode}
                            onBack={() => { setVerificationStage("choose"); setVerificationCode(""); setVerificationError(""); }}
                        />
                    ) : mode === "voice" ? (


                        /* =================================
                           VOICE MODE
                           ================================= */

                        <>

                            <MicrophoneButton

                                onStartListening={
                                    handleStartListening
                                }

                                isListening={
                                    isListening
                                }

                                voiceQuestion={
                                    voiceQuestion
                                }

                            />


                            <ConversationCard

                                messages={
                                    messages
                                }

                            />


                            <DetectedInfo

                                formData={
                                    formData
                                }

                            />


                            <SignUpActions

                                onContinueSpeaking={
                                    handleStartListening
                                }

                                onSwitchToTyping={
                                    switchToTyping
                                }

                                isListening={
                                    isListening
                                }

                            />

                        </>

                    ) : (


                        /* =================================
                           TYPING MODE
                           ================================= */

                        <TypingSignUpForm

                            formData={
                                formData
                            }

                            errors={
                                errors
                            }

                            onInputChange={
                                handleInputChange
                            }

                            onReturnToVoice={
                                staffPortal ? undefined : switchToVoice
                            }

                            onCreateAccount={
                                handleCreateAccount
                            }

                            isVolunteer={portal === "volunteer"}
                            isSecurity={portal === "security"}

                        />

                    )}
                </div>
                <p className="signup-landing-link" style={{ textAlign: "center", marginTop: 20 }}>
                    <Link to="/" style={{ textDecoration: "underline", fontWeight: 600 }}>
                        Back to landing page
                    </Link>
                </p>

            </section>

        </main>

    );

}

export default SignUp;







