/* =========================================
   UNIABLE FORM VALIDATION
   ========================================= */

export function isValidEmail(email) {
    const value = String(email || "").trim();
    if (value.length > 254) return false;
    const emailPattern = /^[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?(?:\.[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?)+$/i;
    return emailPattern.test(value) && !value.includes("..") && value.split("@")[0].length <= 64;
}


export function validateSignUpForm(formData) {

    const errors = {};


    /* STAFF FIRST AND LAST NAMES; STUDENT FULL NAME */
    if (["volunteer", "security"].includes(formData.accountType)) {
        if (!String(formData.firstName || "").trim()) errors.firstName = "Please enter your first name.";
        if (!String(formData.lastName || "").trim()) errors.lastName = "Please enter your last name.";
    } else if (!String(formData.fullName || "").trim()) {
        errors.fullName = "Please enter your full name.";
    }

    /* VOLUNTEER APPLICATION DETAILS OR STUDENT ACCESSIBILITY */
    if (formData.accountType === "volunteer") {
        if (!formData.volunteerAvailability) {
            errors.volunteerAvailability = "Please select when you are available.";
        }
        if (!Array.isArray(formData.volunteerServiceAreas) || formData.volunteerServiceAreas.length === 0) {
            errors.volunteerServiceAreas = "Please select at least one area where you can offer support.";
        }
        if (!String(formData.volunteerExperience || "").trim()) {
            errors.volunteerExperience = "Please describe your relevant skills or experience.";
        }
        if (!String(formData.volunteerMotivation || "").trim()) {
            errors.volunteerMotivation = "Please tell us why you would like to volunteer.";
        }
    } else if (formData.accountType !== "security" && !formData.accessibility) {
        errors.accessibility = "Please select an accessibility option.";
    }


    /* EMAIL */

    if (!formData.email.trim()) {

        errors.email =
            "Please enter your email address.";

    }

    else if (!isValidEmail(formData.email)) {

        errors.email =
            "Please enter a valid email address.";

    }


    /* PASSWORD */

    if (!formData.password) {

        errors.password =
            "Please create a password.";

    }

    else if (formData.password.length < 8) {
        errors.password = "Password must contain at least 8 characters.";
    }
    else if (!/[A-Z]/.test(formData.password)) {
        errors.password = "Password must contain at least one uppercase letter.";
    }
    else if (!/[a-z]/.test(formData.password)) {
        errors.password = "Password must contain at least one lowercase letter.";
    }
    else if (!/[0-9]/.test(formData.password)) {
        errors.password = "Password must contain at least one number.";
    }
    else if (!/[^A-Za-z0-9]/.test(formData.password)) {
        errors.password = "Password must contain at least one special character.";
    }


    return errors;
}

