
import { Capacitor } from "@capacitor/core";

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendSignInLinkToEmail,
  isSignInWithEmailLink,
  signInWithEmailLink,
  sendPasswordResetEmail,
  getAuth,
  onAuthStateChanged,
  getIdTokenResult,
  RecaptchaVerifier,
  signOut,
  updatePassword,
  sendEmailVerification,
  updateProfile,
  updateEmail,
  deleteUser,
  linkWithPhoneNumber,
  signInWithPhoneNumber
} from "firebase/auth";

import { initializeApp, getApps } from "firebase/app";

import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL
} from "firebase/storage";

import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  serverTimestamp
} from "firebase/firestore";

// ============================================
// FIREBASE CONFIGURATION
// ============================================

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export const firebaseConfigured =
  Object.values(firebaseConfig).every(Boolean);

let app = null;
let auth = null;
let storage = null;
let db = null;

if (firebaseConfigured) {
  app = getApps().length
    ? getApps()[0]
    : initializeApp(firebaseConfig);

  auth = getAuth(app);
  storage = getStorage(app);
  db = getFirestore(app);
}

// ============================================
// CURRENT USER
// ============================================

export function getCurrentUser() {
  return auth?.currentUser || null;
}

export function subscribeToAuth(callback) {
  if (!auth) {
    callback(null);
    return () => {};
  }

  return onAuthStateChanged(auth, callback);
}

function requireAuth() {
  if (!auth || !auth.currentUser) {
    throw new Error(
      "Your UniAble account is not connected to Firebase authentication. Sign in first."
    );
  }

  return auth.currentUser;
}

// ============================================
// USER ROLE
// ============================================

export async function getCurrentUserRole(user = auth?.currentUser) {
  if (!user) return null;

  // First check Firebase Authentication custom claims.
  const tokenResult = await getIdTokenResult(user, true);

  let role = String(
    tokenResult.claims?.role || ""
  ).toLowerCase();

  // If no custom claim exists, check the Firestore user profile.
  if (!role && db) {
    try {
      const snapshot = await getDoc(
        doc(db, "users", user.uid)
      );

      if (snapshot.exists()) {
        role = String(
          snapshot.data().role || ""
        ).toLowerCase();
      }
    } catch (error) {
      console.warn(
        "Could not retrieve the user's Firestore role:",
        error
      );
    }
  }

  const allowedRoles = new Set([
    "student",
    "admin",
    "volunteer",
    "security",
    "disability_office",
    "lecturer"
  ]);

  return allowedRoles.has(role) ? role : "student";
}

// ============================================
// ACCOUNT REGISTRATION
// ============================================

export async function createAccountWithEmailPassword(
  email,
  password,
  displayName,
  accessibility = "None",
  accountType = "student"
) {
  if (!firebaseConfigured || !auth) {
    throw new Error(
      "Firebase is not configured. Check the frontend environment variables."
    );
  }

  // Student, Volunteer and Security applications are accepted through public registration.
  const selectedRole = String(
    accountType || "student"
  ).trim().toLowerCase();

  if (!["student", "volunteer", "security"].includes(selectedRole)) {
    throw new Error("Invalid account type selected.");
  }

  const normalizedEmail = String(email || "").trim();
  const selectedName = String(displayName || "").trim();
  const selectedAccessibility =
    String(accessibility || "").trim() || "None";

  if (!normalizedEmail || !password) {
    throw new Error("Email and password are required.");
  }

  if (!db) {
    throw new Error("Firebase Firestore is not configured.");
  }

  // Create the Firebase Authentication account.
  const credential = await createUserWithEmailAndPassword(
    auth,
    normalizedEmail,
    password
  );

  const user = credential.user;

  // Set the user's Firebase display name.
  if (selectedName) {
    await updateProfile(user, {
      displayName: selectedName
    });
  }

  // Enable voice-first mode for visual impairment.
  const voiceFirstEnabled =
    selectedAccessibility === "Visual Impairment";

  try {
    localStorage.setItem(
      `uniableAccessibility:${user.uid}`,
      selectedAccessibility
    );

    localStorage.setItem(
      voiceFirstStorageKey(user.uid),
      String(voiceFirstEnabled)
    );
  } catch (error) {
    console.warn(
      "Could not save local accessibility preference:",
      error
    );
  }

  // Create the main Firestore user profile.
  try {
    await setDoc(
      doc(db, "users", user.uid),
      {
        uid: user.uid,
        email: user.email || normalizedEmail,
        displayName: selectedName,
        firstName: String(selectedName).trim().split(/\\s+/)[0] || "",
        lastName: String(selectedName).trim().split(/\\s+/).slice(1).join(" "),

        // Account classification.
        role: selectedRole,

        // Account status.
        status: ["volunteer", "security"].includes(selectedRole)
          ? "pending_approval"
          : "active",
        approvalStatus: ["volunteer", "security"].includes(selectedRole)
          ? "pending"
          : "not_required",
        isActive: !["volunteer", "security"].includes(selectedRole),

        // Account dates.
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),

        // Accessibility information.
        accessibility: selectedAccessibility,
        voiceFirstEnabled,
        voiceFirstManuallySet: false
      },
      { merge: true }
    );
  } catch (error) {
    console.error(
      "Could not save the user profile to Firestore:",
      error
    );

    throw new Error(
      "Your authentication account was created, but your UniAble profile could not be saved. Please contact the administrator before attempting registration again."
    );
  }

  return user;
}

// ============================================
// EMAIL VERIFICATION
// ============================================

export async function sendVerificationEmail(newEmail) {
  const user = requireAuth();

  if (newEmail && newEmail !== user.email) {
    await updateEmail(user, newEmail);
  }

  if (user.emailVerified) {
    return { alreadyVerified: true };
  }

  await sendEmailVerification(user);

  return { alreadyVerified: false };
}

export async function refreshCurrentUser() {
  const user = requireAuth();

  await user.reload();

  return auth.currentUser;
}

// ============================================
// PROFILE MANAGEMENT
// ============================================

export async function saveFirebaseProfile({
  displayName,
  photoFile
}) {
  const user = requireAuth();

  let photoURL = user.photoURL || "";

  if (photoFile) {
    if (!storage) {
      throw new Error("Firebase Storage is not configured.");
    }

    const fileRef = ref(
      storage,
      `profile-images/${user.uid}/profile`
    );

    await uploadBytes(fileRef, photoFile, {
      contentType: photoFile.type || "image/jpeg"
    });

    photoURL = await getDownloadURL(fileRef);
  }

  await updateProfile(user, {
    displayName,
    ...(photoURL ? { photoURL } : {})
  });

  return {
    displayName: user.displayName,
    photoURL
  };
}

// ============================================
// PHONE OTP VERIFICATION
// ============================================

let phoneRecaptchaVerifier = null;
let phoneRecaptchaContainer = null;

function clearPhoneRecaptchaVerifier() {
  if (phoneRecaptchaVerifier) {
    try {
      phoneRecaptchaVerifier.clear();
    } catch (error) {
      console.warn(
        "Could not clear the previous reCAPTCHA verifier:",
        error
      );
    }
  }

  phoneRecaptchaVerifier = null;
  phoneRecaptchaContainer = null;
}

export async function sendPhoneOtp(
  phoneNumber,
  recaptchaContainerId
) {
  if (!auth) {
    throw new Error(
      "Firebase authentication is not configured."
    );
  }

  const container = document.getElementById(
    recaptchaContainerId
  );

  if (!container) {
    throw new Error(
      "The phone verification reCAPTCHA container was not found. Please refresh the page and try again."
    );
  }

  if (
    phoneRecaptchaVerifier &&
    phoneRecaptchaContainer !== container
  ) {
    clearPhoneRecaptchaVerifier();
  }

  if (!phoneRecaptchaVerifier) {
    phoneRecaptchaVerifier = new RecaptchaVerifier(
      auth,
      recaptchaContainerId,
      {
        size: "invisible"
      }
    );

    phoneRecaptchaContainer = container;
  }

  try {
    const user = auth.currentUser;

    const confirmation = user
      ? await linkWithPhoneNumber(
          user,
          phoneNumber,
          phoneRecaptchaVerifier
        )
      : await signInWithPhoneNumber(
          auth,
          phoneNumber,
          phoneRecaptchaVerifier
        );

    return {
      confirmation,
      verifier: phoneRecaptchaVerifier
    };
  } catch (error) {
    clearPhoneRecaptchaVerifier();
    throw error;
  }
}

export async function verifyPhoneOtp(
  confirmation,
  code
) {
  if (!confirmation) {
    throw new Error("Please request an OTP first.");
  }

  const result = await confirmation.confirm(code);

  await result.user.getIdToken(true);

  clearPhoneRecaptchaVerifier();

  return result.user;
}

// ============================================
// PASSWORD MANAGEMENT
// ============================================

export async function sendPasswordResetEmailToUser(email) {
  if (!auth) {
    throw new Error(
      "Firebase is not configured. Please try again later."
    );
  }

  const normalizedEmail = String(email || "").trim();

  if (!normalizedEmail) {
    throw new Error("Enter your email address.");
  }

  await sendPasswordResetEmail(
    auth,
    normalizedEmail
  );
}

export async function changeAccountPassword(newPassword) {
  const user = requireAuth();

  await updatePassword(user, newPassword);
}

export async function signOutAccount() {
  if (!auth) {
    throw new Error(
      "Firebase authentication is not configured."
    );
  }

  await signOut(auth);
}

export async function deleteAccount() {
  const user = requireAuth();

  await deleteUser(user);
}

// ============================================
// VOICE AUTHENTICATION SETTINGS
// ============================================

export async function getVoiceAuthenticationState() {
  return localStorage.getItem(
    "uniableVoiceAuthentication"
  ) === "true";
}

export async function setVoiceAuthenticationState(enabled) {
  localStorage.setItem(
    "uniableVoiceAuthentication",
    String(enabled)
  );

  return enabled;
}

const voiceFirstStorageKey = (uid) =>
  `uniableVoiceFirst:${uid}`;

// ============================================
// VOICE-FIRST PREFERENCE
// ============================================

export async function getVoiceFirstPreference(
  user = auth?.currentUser
) {
  const isBlind = (profile, accessibility) => {
    const value = String(accessibility || "").toLowerCase();

    return (
      profile?.id === "blind" ||
      value.includes("visual impairment") ||
      value.includes("blind") ||
      value.includes("low vision")
    );
  };

  if (user && db) {
    try {
      const snapshot = await getDoc(
        doc(db, "users", user.uid)
      );

      if (snapshot.exists()) {
        const data = snapshot.data();

        const blindProfile = isBlind(
          data.accessibilityProfile,
          data.accessibility
        );

        const explicitlySet =
          data.voiceFirstManuallySet === true;

        if (blindProfile && !explicitlySet) {
          try {
            localStorage.setItem(
              voiceFirstStorageKey(user.uid),
              "true"
            );

            localStorage.setItem(
              `uniableVoiceFirstManual:${user.uid}`,
              "false"
            );
          } catch {
            // Optional local cache.
          }

          return true;
        }

        if (typeof data.voiceFirstEnabled === "boolean") {
          try {
            localStorage.setItem(
              voiceFirstStorageKey(user.uid),
              String(data.voiceFirstEnabled)
            );

            if (explicitlySet) {
              localStorage.setItem(
                `uniableVoiceFirstManual:${user.uid}`,
                "true"
              );
            }
          } catch {
            // Optional local cache.
          }

          return data.voiceFirstEnabled;
        }
      }
    } catch (error) {
      console.warn(
        "Could not load voice-first preference from Firebase:",
        error
      );
    }
  }

  try {
    if (user) {
      const accessibility = String(
        localStorage.getItem(
          `uniableAccessibility:${user.uid}`
        ) || ""
      );

      let profile = null;

      try {
        profile = JSON.parse(
          localStorage.getItem(
            "uniableAccessibilityProfile"
          ) || "null"
        );
      } catch {
        // Optional local cache.
      }

      const manual =
        localStorage.getItem(
          `uniableVoiceFirstManual:${user.uid}`
        ) === "true";

      const cached = localStorage.getItem(
        voiceFirstStorageKey(user.uid)
      );

      if (isBlind(profile, accessibility) && !manual) {
        return true;
      }

      if (cached === "true" || cached === "false") {
        return cached === "true";
      }

      return isBlind(profile, accessibility);
    }

    let profile = null;

    try {
      profile = JSON.parse(
        localStorage.getItem(
          "uniableAccessibilityProfile"
        ) || "null"
      );
    } catch {
      // Optional local cache.
    }

    const manual =
      localStorage.getItem(
        "uniableVoiceFirstManual"
      ) === "true";

    if (isBlind(profile, "") && !manual) {
      return true;
    }

    return (
      localStorage.getItem(
        "uniableVoiceFirstEnabled"
      ) === "true"
    );
  } catch {
    return false;
  }
}

// ============================================
// SAVE VOICE-FIRST PREFERENCE
// ============================================

export async function setVoiceFirstPreference(
  enabled,
  user = auth?.currentUser
) {
  const value = Boolean(enabled);

  try {
    if (user) {
      localStorage.setItem(
        voiceFirstStorageKey(user.uid),
        String(value)
      );

      localStorage.setItem(
        `uniableVoiceFirstManual:${user.uid}`,
        "true"
      );
    } else {
      localStorage.setItem(
        "uniableVoiceFirstEnabled",
        String(value)
      );

      localStorage.setItem(
        "uniableVoiceFirstManual",
        "true"
      );
    }
  } catch (error) {
    console.warn(
      "Could not cache voice-first preference:",
      error
    );
  }

  try {
    window.dispatchEvent(
      new CustomEvent(
        "uniable-voice-first-change",
        { detail: { enabled: value } }
      )
    );
  } catch {
    // Optional event.
  }

  if (user && db) {
    await setDoc(
      doc(db, "users", user.uid),
      {
        voiceFirstEnabled: value,
        voiceFirstManuallySet: true,
        updatedAt: serverTimestamp()
      },
      { merge: true }
    );
  }

  return value;
}

// ============================================
// API CONFIGURATION
// ============================================

const UNIABLe_API_BASE = (
  import.meta.env.VITE_API_BASE_URL ||
  (
    Capacitor.getPlatform() === "android"
      ? "http://10.0.2.2:4000"
      : "http://localhost:4000"
  )
).replace(/\/$/, "");

// ============================================
// ACCOUNT VERIFICATION API
// ============================================

async function verificationApi(path, body) {
  const user = auth?.currentUser;

  if (!user) {
    throw new Error(
      "Please sign in before verifying your account."
    );
  }

  const token = await user.getIdToken();

  const response = await fetch(
    `${UNIABLe_API_BASE}/api/auth${path}`,
    {
      method: body === undefined ? "GET" : "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        ...(body === undefined
          ? {}
          : { "Content-Type": "application/json" })
      },
      ...(body === undefined
        ? {}
        : { body: JSON.stringify(body) })
    }
  );

  const result = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(
      result.error || "The verification service is unavailable."
    );

    error.status = response.status;
    throw error;
  }

  return result;
}

export async function startAccountVerification() {
  const result = await verificationApi(
    "/registration/start",
    {}
  );

  await auth.currentUser.getIdToken(true);

  return result;
}

export async function getVerificationStatus() {
  return verificationApi("/verification-status");
}

export async function sendEmailOtp() {
  return verificationApi("/email-otp/send", {});
}

export async function verifyEmailOtp(code) {
  const result = await verificationApi(
    "/email-otp/verify",
    { code }
  );

  await auth.currentUser.getIdToken(true);

  return result;
}

export async function completePhoneVerification(phoneNumber) {
  const result = await verificationApi(
    "/phone/verified",
    { phoneNumber }
  );

  await auth.currentUser.getIdToken(true);

  return result;
}

async function ensureAccountVerified(user) {
  const status = await verificationApi(
    "/verification-status"
  );

  if (status.approvalStatus === "pending") {
    const error = new Error("Your staff application is awaiting administrator approval. You will receive an email OTP after it is approved.");
    error.code = "auth/account-pending-approval";
    throw error;
  }

  if (status.status === "account_creation_denied") {
    const error = new Error("Account creation denied. Your UniAble application was declined by an administrator.");
    error.code = "auth/account-creation-denied";
    throw error;
  }

  if (status.required && !status.verified) {
    const error = new Error(
      "Your account has been approved, but email verification is still required. Enter the OTP sent to your email address."
    );
    error.code = "auth/account-not-verified";
    throw error;
  }

  return user;
}

// ============================================
// USER ACCESSIBILITY PROFILE
// ============================================

export async function saveUserAccessibilityProfile(profile) {
  const user = requireAuth();

  const accessibilityProfile = {
    id: String(profile?.id || "multiple"),
    title: String(
      profile?.title || "Multi-Disability / Custom Adaptive"
    ),
    description: String(
      profile?.description ||
      "Combine preferences in one profile"
    )
  };

  const categoryById = {
    blind: "Visual Impairment",
    deaf: "Hearing Impairment",
    mobility: "Mobility Support",
    speech: "Speech Support",
    colour: "Colour Vision",
    dyslexia: "Neurodiverse Support",
    adhd: "Neurodiverse Support",
    autism: "Neurodiverse Support",
    down: "Neurodiverse Support",
    multiple: "Other"
  };

  const accessibility =
    categoryById[accessibilityProfile.id] || "Other";

  const autoEnableVoiceFirst =
    accessibilityProfile.id === "blind";

  try {
    localStorage.setItem(
      "uniableAccessibilityProfile",
      JSON.stringify(accessibilityProfile)
    );

    localStorage.setItem(
      `uniableAccessibility:${user.uid}`,
      accessibility
    );
  } catch (error) {
    console.warn(
      "Could not cache the accessibility profile locally:",
      error
    );
  }

  if (!db) {
    throw new Error(
      "Your selection is saved on this device, but Firebase Firestore is not configured."
    );
  }

  try {
    await setDoc(
      doc(db, "users", user.uid),
      {
        displayName: user.displayName || "",
        accessibility,
        accessibilityProfile,

        ...(autoEnableVoiceFirst
          ? {
              voiceFirstEnabled: true,
              voiceFirstManuallySet: false
            }
          : {}),

        updatedAt: serverTimestamp()
      },
      { merge: true }
    );

    if (autoEnableVoiceFirst) {
      try {
        localStorage.setItem(
          voiceFirstStorageKey(user.uid),
          "true"
        );

        localStorage.setItem(
          `uniableVoiceFirstManual:${user.uid}`,
          "false"
        );
      } catch {
        // Optional local cache.
      }

      try {
        window.dispatchEvent(
          new CustomEvent(
            "uniable-voice-first-change",
            { detail: { enabled: true } }
          )
        );
      } catch {
        // Optional event.
      }
    }
  } catch (error) {
    console.error(
      "Could not sync the accessibility profile to Firebase:",
      error
    );

    throw new Error(
      "Your selection is saved on this device, but Firebase could not sync it. Check your Firestore rules and connection."
    );
  }

  return {
    accessibility,
    accessibilityProfile
  };
}

// ============================================
// GET ACCESSIBILITY PROFILE
// ============================================

export async function getUserAccessibilityProfile(
  user = auth?.currentUser
) {
  if (!user) return null;

  if (db) {
    try {
      const snapshot = await getDoc(
        doc(db, "users", user.uid)
      );

      if (snapshot.exists()) {
        const profile = snapshot.data();

        if (profile.accessibility) {
          try {
            localStorage.setItem(
              `uniableAccessibility:${user.uid}`,
              profile.accessibility
            );
          } catch {
            // Continue with Firestore data.
          }

          return profile;
        }
      }
    } catch (error) {
      console.warn(
        "Could not read the Firestore accessibility profile:",
        error
      );
    }
  }

  try {
    const accessibility = localStorage.getItem(
      `uniableAccessibility:${user.uid}`
    );

    return accessibility
      ? { accessibility }
      : null;
  } catch {
    return null;
  }
}

// ============================================
// SIGN IN
// ============================================

export async function signInWithEmailPassword(
  email,
  password
) {
  if (!firebaseConfigured || !auth) {
    throw new Error(
      "Firebase is not configured. Check the frontend environment variables."
    );
  }

  const credential = await signInWithEmailAndPassword(
    auth,
    email.trim(),
    password
  );

  return ensureAccountVerified(credential.user);
}

// ============================================
// PASSWORDLESS SIGN IN
// ============================================

export async function sendPasswordlessSignInLink(email) {
  if (!firebaseConfigured || !auth) {
    throw new Error(
      "Firebase is not configured. Check the frontend environment variables."
    );
  }

  const normalizedEmail = email.trim();

  if (!normalizedEmail) {
    throw new Error("Enter your email address first.");
  }

  const actionCodeSettings = {
    url: `${window.location.origin}/login`,
    handleCodeInApp: true
  };

  await sendSignInLinkToEmail(
    auth,
    normalizedEmail,
    actionCodeSettings
  );

  try {
    window.sessionStorage.setItem(
      "uniableEmailForSignIn",
      normalizedEmail
    );
  } catch {
    // Optional session storage.
  }
}

export function isPasswordlessSignInLink(
  link = window.location.href
) {
  return Boolean(
    auth && isSignInWithEmailLink(auth, link)
  );
}

export async function completePasswordlessSignIn(
  email,
  link = window.location.href
) {
  if (!firebaseConfigured || !auth) {
    throw new Error(
      "Firebase is not configured. Check the frontend environment variables."
    );
  }

  if (!isSignInWithEmailLink(auth, link)) {
    throw new Error(
      "This is not a valid UniAble sign-in link. Request a new link."
    );
  }

  const normalizedEmail = email.trim();

  if (!normalizedEmail) {
    throw new Error(
      "Enter the email address that received the sign-in link."
    );
  }

  const credential = await signInWithEmailLink(
    auth,
    normalizedEmail,
    link
  );

  try {
    window.sessionStorage.removeItem(
      "uniableEmailForSignIn"
    );
  } catch {
    // Optional cleanup.
  }

  return ensureAccountVerified(credential.user);
}

// ============================================
// EXPORT AUTH
// ============================================

export { auth };

// ============================================
// STUDY MATERIAL UPLOAD
// ============================================

export async function uploadStudyMaterial(file) {
  const user = requireAuth();

  if (!file || !(file instanceof File)) {
    throw new Error("Choose a valid document file.");
  }
  if (file.size >= 20 * 1024 * 1024) {
    throw new Error("Documents must be smaller than 20 MB.");
  }
  const extension = String(file.name || "").split(".").pop().toLowerCase();
  if (!["pdf", "doc", "docx", "ppt", "pptx"].includes(extension)) {
    throw new Error("Upload a PDF, Word or PowerPoint document.");
  }
  if (!storage) {
    throw new Error(
      "Firebase Storage is not configured."
    );
  }

  const safeName = String(
    file.name || "study-material"
  ).replace(/[^a-zA-Z0-9._-]/g, "_");

  const fileRef = ref(
    storage,
    `study-materials/${user.uid}/${Date.now()}-${safeName}`
  );

  await uploadBytes(fileRef, file, {
    contentType: file.type || "application/octet-stream"
  });

  return {
    fileUrl: await getDownloadURL(fileRef),
    storagePath: fileRef.fullPath,
    fileName: file.name || safeName
  };
}

export async function getStudyMaterialDownloadUrl(storagePath) {
  if (!storage || !storagePath) throw new Error("The document storage location is unavailable.");
  return getDownloadURL(ref(storage, storagePath));
}
