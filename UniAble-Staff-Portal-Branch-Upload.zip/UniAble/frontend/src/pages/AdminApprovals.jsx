import React, { useCallback, useEffect, useState } from "react";
import { CheckCircle2, XCircle, RefreshCw, UserRoundCheck } from "lucide-react";
import { api } from "../services/api";

export default function AdminApprovals() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const result = await api.getStaffApprovals();
      setApplications(result.applications || []);
    } catch (err) {
      setError(err.message || "Could not load pending applications.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function review(application, decision) {
    const label = `${application.firstName || ""} ${application.lastName || ""}`.trim() ||
      application.displayName || application.email || "this applicant";
    if (decision === "decline" && !window.confirm(`Decline the application from ${label}?`)) return;
    setWorking(application.uid);
    setError("");
    setMessage("");
    try {
      const result = await api.reviewStaffApproval(application.uid, decision);
      setMessage(result.message || (decision === "approve" ? "Application approved." : "Application declined."));
      await load();
    } catch (err) {
      setError(err.message || "Could not review the application.");
    } finally {
      setWorking("");
    }
  }

  return (
    <section className="admin-panel admin-approvals">
      <div className="admin-section-toolbar">
        <div><h2>Pending staff applications</h2><p>Review volunteer and campus security applications before granting access.</p></div>
        <button type="button" onClick={load} disabled={loading}><RefreshCw size={16}/> Refresh</button>
      </div>
      {error && <p className="admin-operation-error" role="alert">{error}</p>}
      {message && <p className="admin-operation-success" role="status">{message}</p>}
      {loading ? <p>Loading applications…</p> : applications.length === 0 ? (
        <div className="admin-empty-state"><UserRoundCheck size={28}/><strong>No pending applications</strong><span>New volunteer and security applications will appear here.</span></div>
      ) : (
        <div className="admin-approval-list">
          {applications.map(application => {
            const name = `${application.firstName || ""} ${application.lastName || ""}`.trim() || application.displayName || "Name not provided";
            return (
              <article className="admin-approval-card" key={application.uid}>
                <div className="admin-approval-person">
                  <span className="admin-approval-avatar">{name.charAt(0).toUpperCase()}</span>
                  <div><h3>{name}</h3><p>{application.email}</p><span>{application.role === "security" ? "Campus security applicant" : "Volunteer applicant"}</span></div>
                </div>
                {application.role === "volunteer" && (
                  <div className="admin-approval-details">
                    <p><strong>Availability:</strong> {application.availability || "Not provided"}</p>
                    <p><strong>Support areas:</strong> {(application.serviceAreas || []).join(", ") || "Not provided"}</p>
                    <p><strong>Experience:</strong> {application.experience || "Not provided"}</p>
                    <p><strong>Motivation:</strong> {application.motivation || "Not provided"}</p>
                  </div>
                )}
                <div className="admin-approval-actions">
                  <button type="button" disabled={working === application.uid} onClick={() => review(application, "approve")}><CheckCircle2 size={16}/> {working === application.uid ? "Processing…" : "Approve & send OTP"}</button>
                  <button type="button" className="decline" disabled={working === application.uid} onClick={() => review(application, "decline")}><XCircle size={16}/> Decline</button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
