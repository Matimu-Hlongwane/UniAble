import React, { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  BookOpen, CalendarDays, RefreshCw, Users, LogOut
} from "lucide-react";
import { api } from "../services/api";
import { getCurrentUser, signOutAccount, uploadStudyMaterial, getStudyMaterialDownloadUrl } from "../services/firebaseAuth";
import "./AdminAcademicManagement.css";

const sections = [
  { id: "modules", label: "Modules", icon: BookOpen },
  { id: "timetable", label: "Timetable", icon: CalendarDays },
  { id: "classes", label: "Classes", icon: Users },
];

function today() {
  return new Date().toISOString().slice(0, 10);
}

export default function AdminAcademicManagement({ requests = [], onRefreshRequests }) {
  const navigate = useNavigate();
  const [loggingOut, setLoggingOut] = useState(false);
  const [section, setSection] = useState("modules");
  const [modules, setModules] = useState([]);
  const [timetable, setTimetable] = useState([]);
  const [materials, setMaterials] = useState([]);
  const [documentForm, setDocumentForm] = useState({ moduleId: "", title: "", description: "", file: null });
  const [documentUrls, setDocumentUrls] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const [moduleForm, setModuleForm] = useState({
    code: "", name: "", description: "",
  });
  const [timetableForm, setTimetableForm] = useState({
    moduleId: "", title: "", date: today(),
    startTime: "08:00", endTime: "09:00", venue: "",
  });

  const loadAcademicData = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [moduleRows, timetableRows, materialRows] = await Promise.all([
        api.getAcademicModules(), api.getAcademicTimetable(), api.getAcademicMaterials(),
      ]);
      setModules(Array.isArray(moduleRows) ? moduleRows : moduleRows?.modules || []);
      setTimetable(Array.isArray(timetableRows) ? timetableRows : timetableRows?.timetable || []);
      setMaterials(Array.isArray(materialRows) ? materialRows : materialRows?.materials || []);
    } catch (err) {
      setError(err.message || "Could not load academic information.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAcademicData();
  }, [loadAcademicData]);

  useEffect(() => {
    if (!timetableForm.moduleId && modules.length) {
      setTimetableForm((form) => ({ ...form, moduleId: modules[0].id }));
    }
    if (!documentForm.moduleId && modules.length) {
      setDocumentForm((form) => ({ ...form, moduleId: modules[0].id }));
    }
  }, [modules, timetableForm.moduleId, documentForm.moduleId]);

  async function submitAction(action, successMessage) {
    setSaving(true);
    setError("");
    setNotice("");
    try {
      await action();
      setNotice(successMessage);
      await loadAcademicData();
    } catch (err) {
      setError(err.message || "The action could not be completed.");
    } finally {
      setSaving(false);
    }
  }

  function moduleName(id) {
    return modules.find((item) => item.id === id)?.name || "Module";
  }

  function renderModules() {
    return (
      <>
        <form className="lecturer-form" onSubmit={(event) => {
          event.preventDefault();
          submitAction(async () => {
            const user = getCurrentUser();
            if (!user) throw new Error("Please sign in again.");
            await api.createAcademicModule({
              ...moduleForm,
              lecturerId: user.uid,
              studentIds: [],
            });
            setModuleForm({ code: "", name: "", description: "" });
          }, "Module created.");
        }}>
          <h3>Create module</h3>
          <div className="lecturer-form-grid">
            <label>Module code
              <input required value={moduleForm.code}
                onChange={(e) => setModuleForm({ ...moduleForm, code: e.target.value })} />
            </label>
            <label>Module name
              <input required value={moduleForm.name}
                onChange={(e) => setModuleForm({ ...moduleForm, name: e.target.value })} />
            </label>
          </div>
          <label>Description
            <textarea value={moduleForm.description}
              onChange={(e) => setModuleForm({ ...moduleForm, description: e.target.value })} />
          </label>



          <button disabled={saving}>Create module</button>
        </form>

        <form className="lecturer-form" onSubmit={(event) => {
          event.preventDefault();
          submitAction(async () => {
            if (!documentForm.file) throw new Error("Choose a document to upload.");
            const uploaded = await uploadStudyMaterial(documentForm.file);
            await api.createAcademicMaterial({
              moduleId: documentForm.moduleId,
              title: documentForm.title.trim() || documentForm.file.name,
              description: documentForm.description.trim(),
              fileName: uploaded.fileName,
              storagePath: uploaded.storagePath,
              contentType: documentForm.file.type || "application/octet-stream",
            });
            setDocumentForm({ moduleId: modules[0]?.id || "", title: "", description: "", file: null });
            const fileInput = document.getElementById("academic-document-file");
            if (fileInput) fileInput.value = "";
          }, "Document uploaded and saved. It will remain available after you close and reopen UniAble.");
        }}>
          <h3>Study guides and academic resources</h3>
          <p>Upload PDF, Word or PowerPoint study guides, link each guide to a module, then publish it. Published guides appear in the student dashboard for all students.</p>
          <div className="lecturer-form-grid">
            <label>Module
              <select required value={documentForm.moduleId} onChange={(e) => setDocumentForm({ ...documentForm, moduleId: e.target.value })}>
                <option value="">Select module</option>
                {modules.map((item) => <option key={item.id} value={item.id}>{item.code} — {item.name}</option>)}
              </select>
            </label>
            <label>Document title
              <input value={documentForm.title} onChange={(e) => setDocumentForm({ ...documentForm, title: e.target.value })} placeholder="Optional — uses file name" />
            </label>
          </div>
          <label>Description
            <textarea value={documentForm.description} onChange={(e) => setDocumentForm({ ...documentForm, description: e.target.value })} />
          </label>
          <label>Choose study guide (PDF, Word or PowerPoint)
            <input id="academic-document-file" type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation" required onChange={(e) => setDocumentForm({ ...documentForm, file: e.target.files?.[0] || null })} />
          </label>
          <button disabled={saving || !modules.length || !documentForm.file}>Upload study guide</button>
          {!modules.length && <small>Create a module before uploading a document.</small>}
        </form>

        <div className="lecturer-list">
          <h3>Uploaded study guides</h3>
          {materials.map((item) => (
            <article className="lecturer-list-row" key={item.id}>
              <div><strong>{item.title || item.fileName}</strong><p>{moduleName(item.moduleId)} · {item.fileName} · {item.published ? "Published" : "Saved"}</p></div>
              <div className="lecturer-header-actions">
                <button type="button" onClick={async () => {
                  try {
                    let url = item.fileUrl || documentUrls[item.id];
                    if (!url && item.storagePath) {
                      url = await getStudyMaterialDownloadUrl(item.storagePath);
                      setDocumentUrls((current) => ({ ...current, [item.id]: url }));
                    }
                    if (!url) throw new Error("No saved file location is available for this document.");
                    window.open(url, "_blank", "noopener,noreferrer");
                  } catch (err) { setError(err.message || "Could not open the document."); }
                }}>Open document</button>
                {item.moduleId && <button type="button" disabled={saving} onClick={() => submitAction(() => api.publishAcademicMaterial(item.id, !item.published), item.published ? "Document unpublished." : "Document published to enrolled students.")}>{item.published ? "Unpublish" : "Publish"}</button>}
              </div>
            </article>
          ))}
          {!materials.length && <p className="lecturer-empty">No academic documents have been uploaded yet.</p>}
        </div>

        <div className="lecturer-card-grid">
          {modules.map((item) => (
            <article className="lecturer-card" key={item.id}>
              <span className="lecturer-card-code">{item.code || "MODULE"}</span>
              <h3>{item.name || "Untitled module"}</h3>
              <p>{item.description || "No description provided."}</p>
              <small>{item.studentIds?.length || 0} enrolled students</small>
            </article>
          ))}
          {!modules.length && !loading && (
            <div className="lecturer-empty-state lecturer-empty-state-compact">
              <BookOpen size={28} />
              <h3>No modules yet</h3>
              <p>Use the Create module form above to add your first module. It will then become available in your timetable, attendance and learning-material sections.</p>
            </div>
          )}
        </div>
      </>
    );
  }

  function renderTimetable() {
    if (!modules.length) {
      return (
        <div className="lecturer-empty-state">
          <BookOpen size={34} />
          <h2>Create your first module</h2>
          <p>You need at least one module before you can create its timetable.</p>
          <button type="button" onClick={() => setSection("modules")}>Go to module management</button>
        </div>
      );
    }

    return (
      <>
        <form className="lecturer-form" onSubmit={(event) => {
          event.preventDefault();
          submitAction(() => api.createAcademicTimetable(timetableForm),
            "Timetable entry created.");
        }}>
          <h3>Add timetable entry</h3>
          <div className="lecturer-form-grid">
            <label>Module
              <select required value={timetableForm.moduleId}
                onChange={(e) => setTimetableForm({ ...timetableForm, moduleId: e.target.value })}>
                <option value="">Select module</option>
                {modules.map((item) => <option key={item.id} value={item.id}>{item.code} — {item.name}</option>)}
              </select>
            </label>
            <label>Class title
              <input required value={timetableForm.title}
                onChange={(e) => setTimetableForm({ ...timetableForm, title: e.target.value })} />
            </label>
            <label>Date
              <input type="date" required value={timetableForm.date}
                onChange={(e) => setTimetableForm({ ...timetableForm, date: e.target.value })} />
            </label>
            <label>Venue
              <input required value={timetableForm.venue}
                onChange={(e) => setTimetableForm({ ...timetableForm, venue: e.target.value })} />
            </label>
            <label>Start time
              <input type="time" required value={timetableForm.startTime}
                onChange={(e) => setTimetableForm({ ...timetableForm, startTime: e.target.value })} />
            </label>
            <label>End time
              <input type="time" required value={timetableForm.endTime}
                onChange={(e) => setTimetableForm({ ...timetableForm, endTime: e.target.value })} />
            </label>
          </div>
          <button disabled={saving || !modules.length}>Add timetable entry</button>
        </form>
        <div className="lecturer-list">
          {timetable.map((item) => (
            <article className="lecturer-list-row" key={item.id}>
              <div><strong>{item.title || moduleName(item.moduleId)}</strong>
                <p>{moduleName(item.moduleId)} · {item.date} · {item.startTime}–{item.endTime}</p>
              </div>
              <span>{item.venue || "Venue not set"}</span>
            </article>
          ))}
          {!timetable.length && <p className="lecturer-empty">No timetable entries found.</p>}
        </div>
      </>
    );
  }

  function renderClasses() {
    return (
      <div className="lecturer-card-grid">
        {modules.map((item) => (
          <article className="lecturer-card" key={item.id}>
            <span className="lecturer-card-code">{item.code || "MODULE"}</span>
            <h3>{item.name}</h3>
            <p>{item.description || "No class description provided."}</p>
            <strong>{item.studentIds?.length || 0} enrolled students</strong>
          </article>
        ))}
        {!modules.length && <p className="lecturer-empty">No classes are available for your assigned modules.</p>}
      </div>
    );
  }

  const sectionContent = {
    modules: renderModules,
    timetable: renderTimetable,
    classes: renderClasses,
  };

  const activeSection = sections.find((item) => item.id === section);

  return (
    <div className="lecturer-shell">
      <aside className="lecturer-sidebar">
        <div className="lecturer-brand">
          <span>UA</span>
          <div><strong>UniAble</strong><small>Administrator workspace</small></div>
        </div>
        <nav aria-label="Academic management navigation">
          {sections.map(({ id, label, icon: Icon }) => (
            <button key={id} className={section === id ? "active" : ""}
              onClick={() => setSection(id)}>
              <Icon size={18} /> <span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="lecturer-sidebar-bottom">
          <button onClick={loadAcademicData} disabled={loading}>
            <RefreshCw size={17} /> Refresh academic data
          </button>
        </div>
      </aside>

      <main className="lecturer-main">
        <header className="lecturer-header">
          <div><p>UNIABLE STAFF SERVICES</p><h1>{activeSection?.label || "Academic management"}</h1></div>
          <div className="lecturer-header-actions">
            <span>Administrator</span>
            <button
              type="button"
              className="lecturer-logout-button"
              disabled={loggingOut}
              onClick={async () => {
                setLoggingOut(true);
                try {
                  sessionStorage.setItem("uniableStaffLogout", "1");
                  await signOutAccount();
                  navigate("/staff", { replace: true });
                } catch (err) {
                  setError(err.message || "Could not log out. Please try again.");
                } finally {
                  setLoggingOut(false);
                }
              }}
            >
              <LogOut size={16} />
              {loggingOut ? "Signing out..." : "Log out"}
            </button>
          </div>
        </header>

        {error && <div className="lecturer-message error" role="alert">{error}</div>}
        {notice && <div className="lecturer-message success" role="status">{notice}</div>}
        {loading && <p role="status">Loading academic data...</p>}

        {!loading && !error && (
          <section className="lecturer-content">
            {sectionContent[section]?.()}
          </section>
        )}
      </main>
    </div>
  );
}


