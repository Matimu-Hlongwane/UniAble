import React, { useEffect, useState } from "react";
import { api } from "../services/api";

export default function AdminOperations({ section }) {
  const [items, setItems] = useState([]);
  const [students, setStudents] = useState([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [priority, setPriority] = useState("important");
  const [studentId, setStudentId] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [status, setStatus] = useState("present");
  const [session, setSession] = useState("");
  const [notes, setNotes] = useState("");
  const [departmentForm, setDepartmentForm] = useState({ name: "", code: "", contactEmail: "" });
  const [settings, setSettings] = useState({ institutionName: "UniAble", campusName: "", supportEmail: "" });
  const [savingSettings, setSavingSettings] = useState(false);
  const [notice, setNotice] = useState("");

  async function load() {
    setError("");
    try {
      if (section === "announcements") setItems((await api.getAdminAnnouncements()).announcements || []);
      if (section === "attendance") {
        const [attendance, studentResult] = await Promise.all([api.getAdminAttendance(), api.getAdminStudents()]);
        setItems(attendance.attendance || []);
        setStudents(studentResult.students || []);
        if (!studentId && studentResult.students?.length) setStudentId(studentResult.students[0].id);
      }
      if (section === "support" || section === "accessibility") {
        const result = await api.getDashboard();
        setItems(section === "support" ? (result.requests || []) : (result.accessibilityProfiles || []));
      }
      if (section === "users") setItems((await api.getAdminUsers()).users || []);
      if (section === "departments") setItems((await api.getAdminDepartments()).departments || []);
      if (section === "audit") setItems((await api.getAdminAuditLogs()).logs || []);
      if (section === "settings") setSettings((await api.getAdminSettings()).settings || { institutionName: "UniAble", campusName: "", supportEmail: "" });
    } catch (e) { setError(e.message || "Could not load this section."); }
  }
  useEffect(() => { load(); }, [section]);

  async function submitAnnouncement(e) {
    e.preventDefault(); setBusy(true); setError("");
    try { await api.createAdminAnnouncement({ title, message, priority }); setTitle(""); setMessage(""); await load(); }
    catch (e) { setError(e.message); } finally { setBusy(false); }
  }
  async function submitAttendance(e) {
    e.preventDefault(); setBusy(true); setError("");
    try { await api.recordAdminAttendance({ studentId, date, status, session, notes }); setNotes(""); await load(); }
    catch (e) { setError(e.message); } finally { setBusy(false); }
  }
  async function updateRequest(id, nextStatus) {
    try { await api.updateRequest(id, nextStatus); await load(); } catch (e) { setError(e.message); }
  }
  async function removeItem(id, kind) {
    if (!window.confirm("Delete this record?")) return;
    try { if (kind === "announcement") await api.deleteAdminAnnouncement(id); else return; await load(); }
    catch (e) { setError(e.message); }
  }

  const heading = ({ users: "User management", departments: "Departments", settings: "System settings", audit: "Audit logs", announcements: "Important announcements", attendance: "Disability student attendance", support: "Student support requests", accessibility: "Accessibility profiles", academics: "Academic management" })[section] || "Administration";
  return <section className="admin-panel admin-operations">
    <h2>{heading}</h2>
    {error && <p role="alert" className="admin-operation-error">{error}</p>}
    {notice && <p className="admin-operation-success" role="status">{notice}</p>}
    {section === "users" && <>
      <h3>Registered UniAble accounts</h3>
      <div className="admin-operation-table-wrap"><table className="admin-operation-table">
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th></tr></thead>
        <tbody>{items.map(user => <tr key={user.id}><td>{user.displayName || `${user.firstName || ""} ${user.lastName || ""}`.trim() || "Name not supplied"}</td><td>{user.email || "—"}</td><td>{user.role}</td><td>{user.status || (user.isActive ? "active" : "inactive")}</td></tr>)}</tbody>
      </table></div>
      {!items.length && <p>No user records were found.</p>}
    </>}
    {section === "departments" && <>
      <form className="admin-operation-form" onSubmit={async e => {
        e.preventDefault(); setBusy(true); setError(""); setNotice("");
        try { await api.createAdminDepartment(departmentForm); setDepartmentForm({ name: "", code: "", contactEmail: "" }); setNotice("Department created."); await load(); }
        catch (err) { setError(err.message || "Could not create department."); } finally { setBusy(false); }
      }}>
        <h3>Add a department</h3>
        <input required placeholder="Department name" value={departmentForm.name} onChange={e => setDepartmentForm({ ...departmentForm, name: e.target.value })}/>
        <input required placeholder="Department code (e.g. ICT)" value={departmentForm.code} onChange={e => setDepartmentForm({ ...departmentForm, code: e.target.value })}/>
        <input type="email" placeholder="Department contact email (optional)" value={departmentForm.contactEmail} onChange={e => setDepartmentForm({ ...departmentForm, contactEmail: e.target.value })}/>
        <button disabled={busy}>{busy ? "Saving…" : "Add department"}</button>
      </form>
      {items.map(item => <article className="admin-operation-item" key={item.id}><div><b>{item.name}</b><p>{item.code} · {item.contactEmail || "No contact email"}</p></div><button type="button" onClick={async () => { if (window.confirm(`Delete ${item.name}?`)) { await api.deleteAdminDepartment(item.id); await load(); } }}>Delete</button></article>)}
      {!items.length && <p>No departments have been added yet. Add your institution's departments above.</p>}
    </>}
    {section === "settings" && <form className="admin-operation-form" onSubmit={async e => {
      e.preventDefault(); setSavingSettings(true); setError(""); setNotice("");
      try { await api.saveAdminSettings(settings); setNotice("System settings saved."); }
      catch (err) { setError(err.message || "Could not save settings."); } finally { setSavingSettings(false); }
    }}>
      <h3>Institution configuration</h3>
      <label>Institution name<input required value={settings.institutionName || ""} onChange={e => setSettings({ ...settings, institutionName: e.target.value })}/></label>
      <label>Campus name<input value={settings.campusName || ""} onChange={e => setSettings({ ...settings, campusName: e.target.value })}/></label>
      <label>Support email<input type="email" value={settings.supportEmail || ""} onChange={e => setSettings({ ...settings, supportEmail: e.target.value })}/></label>
      <button disabled={savingSettings}>{savingSettings ? "Saving…" : "Save system settings"}</button>
    </form>}
    {section === "audit" && <>
      <h3>Recent administrative activity</h3>
      <div className="admin-operation-table-wrap"><table className="admin-operation-table">
        <thead><tr><th>Action</th><th>Actor</th><th>Target</th><th>Date</th></tr></thead>
        <tbody>{items.map(log => <tr key={log.id}><td>{log.action || log.type || "Activity"}</td><td>{log.actorId || log.actorRole || "—"}</td><td>{log.targetId || "—"}</td><td>{log.createdAt ? new Date(log.createdAt).toLocaleString() : "—"}</td></tr>)}</tbody>
      </table></div>
      {!items.length && <p>No audit records have been recorded yet. New administrative changes will appear here.</p>}
    </>}
    {section === "announcements" && <>
      <form className="admin-operation-form" onSubmit={submitAnnouncement}>
        <h3>Publish an announcement</h3>
        <input required placeholder="Announcement title" value={title} onChange={e => setTitle(e.target.value)} />
        <textarea required rows="4" placeholder="Write the announcement for students and staff" value={message} onChange={e => setMessage(e.target.value)} />
        <select value={priority} onChange={e => setPriority(e.target.value)}><option value="normal">Normal</option><option value="important">Important</option><option value="urgent">Urgent</option></select>
        <button disabled={busy}>{busy ? "Publishing..." : "Publish announcement"}</button>
      </form>
      {items.map(x => <article className="admin-operation-item" key={x.id}><div><b>{x.title}</b><p>{x.message}</p><small>{x.priority} · {new Date(x.createdAt).toLocaleString()}</small></div><button onClick={() => removeItem(x.id, "announcement")}>Delete</button></article>)}
    </>}
    {section === "attendance" && <>
      <form className="admin-operation-form" onSubmit={submitAttendance}>
        <h3>Record attendance</h3>
        <select required value={studentId} onChange={e => setStudentId(e.target.value)}><option value="">Select student</option>{students.map(s => <option key={s.id} value={s.id}>{s.fullName || s.displayName || s.name || s.email || s.id}</option>)}</select>
        <label>Date <input type="date" required value={date} onChange={e => setDate(e.target.value)} /></label>
        <input placeholder="Class / session (optional)" value={session} onChange={e => setSession(e.target.value)} />
        <select value={status} onChange={e => setStatus(e.target.value)}><option value="present">Present</option><option value="absent">Absent</option><option value="late">Late</option><option value="excused">Excused</option></select>
        <textarea rows="2" placeholder="Notes (optional)" value={notes} onChange={e => setNotes(e.target.value)} />
        <button disabled={busy || !studentId}>{busy ? "Saving..." : "Save attendance"}</button>
      </form>
      <h3>Attendance records</h3>
      {items.map(x => { const student = students.find(s => s.id === x.studentId); return <article className="admin-operation-item" key={x.id}><div><b>{student?.fullName || student?.displayName || student?.email || x.studentId}</b><p>{x.date} · {x.session || "General"} · <strong>{x.status}</strong></p><small>{x.notes}</small></div></article>; })}
    </>}
    {section === "support" && items.map(x => <article className="admin-operation-item" key={x.id}><div><b>{x.type || "Student support request"}</b><p>{x.description || x.detail || x.message || "No additional details"}</p><small>Status: {x.status || "open"}</small></div><select value={x.status || "open"} onChange={e => updateRequest(x.id, e.target.value)}><option value="open">Open</option><option value="accepted">Accepted</option><option value="declined">Declined</option><option value="completed">Completed</option></select></article>)}
    {section === "accessibility" && items.map(x => <article className="admin-operation-item" key={x.studentId}><div><b>{x.fullName || x.displayName || x.studentId}</b><p>{x.disability || x.accessibilityNeeds || x.primaryNeed || "Accessibility profile"}</p><small>{JSON.stringify(x.preferences || x.accommodations || {})}</small></div></article>)}
    {!items.length && !["announcements", "attendance"].includes(section) && <p>No records are currently available.</p>}
  </section>;
}
