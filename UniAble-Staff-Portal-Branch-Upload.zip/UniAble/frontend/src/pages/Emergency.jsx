export default function Emergency() {
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const [locationLabel, setLocationLabel] = useState("Location not yet shared");
  const { t } = useSettings();

  async function sendSOS() {
    setError("");
    if (!reason.trim()) {
      setError("Please explain the emergency so campus security knows what assistance is needed.");
      return;
    }
    if (!navigator.geolocation) {
      setError("This device does not support location sharing. Enable location services or contact campus security directly.");
      return;
    }
    setSending(true);
    navigator.geolocation.getCurrentPosition(async (position) => {
      const location = {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        accuracy: position.coords.accuracy
      };
      try {
        await api.createSOS({ location, reason: reason.trim(), source: "student-emergency-button" });
        setLocationLabel(`${location.lat.toFixed(6)}, ${location.lng.toFixed(6)}`);
        setSent(true);
      } catch (err) {
        setError(err?.message || t("connectionProblem"));
      } finally {
        setSending(false);
      }
    }, (geoError) => {
      setSending(false);
      setError(geoError.code === 1
        ? "Location permission was denied. Allow location access in your browser or device settings, then try again."
        : "Your exact location could not be obtained. Move to an area with GPS/network reception and try again.");
    }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
  }

  return (
    <section className="page narrow">
      <CampusSecurityCall />
      <p className="eyebrow">{t("emergencyResponse")}</p>
      <h1>{t("emergencySos")}</h1>
      <p className="muted">{t("emergencyDescription")}</p>
      <div className="sos-card">
        <ShieldAlert size={48}/>
        <h2>{sent ? t("sosSent") : t("helpImmediate")}</h2>
        <p>{sent ? "Your emergency and live location have been shared with campus security." : t("genuineEmergency")}</p>
        {!sent && (
          <label className="form-group">
            What is happening? *
            <textarea value={reason} onChange={(event) => setReason(event.target.value)}
              rows={4} maxLength={1000}
              placeholder="Describe the emergency (for example: medical emergency, personal safety threat, accident, or need for urgent assistance)." />
          </label>
        )}
        {error && <p className="muted" role="alert">{error}</p>}
        <button className="sos-button" onClick={sendSOS} disabled={sent || sending} type="button">
          {sent ? t("helpRequested") : sending ? "Getting your location..." : t("sendEmergency")}
        </button>
        <div className="sos-details">
          <span><MapPin size={17}/> {sent ? locationLabel : "Your precise location will be requested when you send the alert"}</span>
          <span><Users size={17}/> Campus security can view the emergency details</span>
          <span><Phone size={17}/> {t("securityNotifiedShort")}</span>
        </div>
      </div>
    </section>
  );
}
