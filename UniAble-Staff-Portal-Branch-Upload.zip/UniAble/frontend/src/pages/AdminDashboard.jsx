
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Activity,
  Users,
  UserCog,
  Building2,
  ClipboardCheck,
  BarChart3,
  Settings,
  ShieldCheck,
  Search,
  Bell,
  Menu,
  X,
  LayoutDashboard,
  ChevronRight,
  LockKeyhole,
  LogOut
} from "lucide-react";

import "./AdminDashboard.css";

import { api } from "../services/api";
import StaffManagement from "./StaffManagement";
import AdminOperations from "./AdminOperations";
import AdminReports from "./AdminReports";
import AdminAcademicManagement from "./AdminAcademicManagement";
import AdminApprovals from "./AdminApprovals";
import { signOutAccount } from "../services/firebaseAuth";

// Navigation sections available in the administration dashboard.
const sections = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "users", label: "User management", icon: Users },
  { id: "staff", label: "Staff management", icon: UserCog },
  { id: "departments", label: "Departments", icon: Building2 },
  { id: "approvals", label: "Approvals", icon: ClipboardCheck },
  { id: "analytics", label: "Analytics and reports", icon: BarChart3 },
  { id: "settings", label: "System settings", icon: Settings },
  { id: "audit", label: "Audit logs", icon: ShieldCheck },
  { id: "academics", label: "Academic management", icon: Activity },
  { id: "support", label: "Student support requests", icon: ClipboardCheck },
  { id: "accessibility", label: "Accessibility profiles", icon: Users },
  { id: "announcements", label: "Announcements", icon: Bell },
  { id: "attendance", label: "Disability student attendance", icon: ClipboardCheck },
];

// Descriptions displayed when an administrator opens a section.
const descriptions = {
  users: "Manage student accounts, account status and platform access.",
  staff: "Manage lecturers and authorised university support personnel.",
  departments: "Manage institutional departments and staff assignments.",
  approvals: "Review pending account and access requests.",
  analytics: "Review platform usage and accessibility-service performance.",
  settings: "Manage institution-wide platform configuration and permissions.",
  audit: "Review administrative actions and changes across the platform.",
  academics: "Manage academic modules, learning materials and attendance records.",
  support: "Review and manage student assistance requests previously handled by lecturers and the Disability Office.",
  accessibility: "Review student accessibility profiles and accommodation information.",
  announcements: "Publish important information for students and staff.",
  attendance: "Record and review attendance for students with disabilities.",
};

export default function AdminDashboard() {
  const navigate = useNavigate();

  // Dashboard navigation and interface states.
  const [active, setActive] = useState("overview");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState("");

  // Dashboard data loading states.
  const [dashboard, setDashboard] = useState(null);
  const [dashboardLoading, setDashboardLoading] = useState(true);
  const [dashboardError, setDashboardError] = useState("");

  // Database backup states.
  const [backupLoading, setBackupLoading] = useState(false);
  const [backupResult, setBackupResult] = useState(null);
  const [backupError, setBackupError] = useState("");

  // Logout state.
  const [loggingOut, setLoggingOut] = useState(false);

  // Log out the administrator using Firebase authentication.
  async function handleLogout() {
    setLoggingOut(true);
    setDashboardError("");

    try {
      sessionStorage.setItem("uniableStaffLogout", "1");
      await signOutAccount();
      navigate("/staff", { replace: true });
    } catch (error) {
      setDashboardError(
        error.message || "Could not log out. Please try again."
      );
    } finally {
      setLoggingOut(false);
    }
  }

  // Run the Firebase-to-Supabase database backup.
  async function handleRunBackup() {
    setBackupLoading(true);
    setBackupError("");
    setBackupResult(null);

    try {
      // Call the protected backend backup endpoint.
      const result = await api.runAdminBackup();

      // Display the result returned by the backend.
      setBackupResult(result);
    } catch (error) {
      // Display an error if the backup fails.
      setBackupError(
        error.message || "The database backup could not be completed."
      );
    } finally {
      // Re-enable the button after the request finishes.
      setBackupLoading(false);
    }
  }

  // Load the administration overview when the component opens.
  useEffect(() => {
    let isActive = true;

    async function loadDashboard() {
      try {
        setDashboardLoading(true);
        setDashboardError("");

        const result = await api.getDashboard();

        if (isActive) {
          setDashboard(result);
        }
      } catch (error) {
        if (isActive) {
          setDashboardError(
            error.message || "Unable to load administration data."
          );
        }
      } finally {
        if (isActive) {
          setDashboardLoading(false);
        }
      }
    }

    loadDashboard();

    // Prevent state updates if the component is removed.
    return () => {
      isActive = false;
    };
  }, []);

  // Extract statistics returned by the backend.
  const stats = dashboard?.stats || {};

  const statCards = [
    {
      label: "Total student accounts",
      icon: Users,
      value: stats.students ?? stats.totalStudents ?? "—",
    },
    {
      label: "Registered staff",
      icon: UserCog,
      value: stats.staff ?? stats.totalStaff ?? "—",
    },
    {
      label: "Departments",
      icon: Building2,
      value: stats.departments ?? stats.totalDepartments ?? "—",
    },
    {
      label: "Pending approvals",
      icon: ClipboardCheck,
      value: stats.pendingApprovals ?? stats.pending ?? "—",
    },
  ];

  // Identify the currently selected navigation section.
  const current = sections.find((item) => item.id === active);

  // Change sections and close the mobile navigation.
  function selectSection(id) {
    setActive(id);
    setMobileOpen(false);
    setSearch("");
  }

  return (
    <div className="admin-shell">

      {/* Mobile navigation overlay. */}
      {mobileOpen && (
        <button
          className="admin-mobile-overlay"
          aria-label="Close navigation"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar navigation. */}
      <aside
        className={`admin-sidebar ${
          mobileOpen ? "admin-sidebar-open" : ""
        }`}
      >
        <div className="admin-brand">
          <div className="admin-brand-mark">U</div>

          <div>
            <strong>UniAble</strong>
            <span>STAFF PORTAL</span>
          </div>

          <button
            className="admin-close-menu"
            onClick={() => setMobileOpen(false)}
          >
            <X size={20} />
          </button>
        </div>

        <div className="admin-sidebar-label">
          ADMINISTRATION
        </div>

        <nav className="admin-navigation">
          {sections.map((item) => {
            const ItemIcon = item.icon;

            return (
              <button
                key={item.id}
                className={`admin-nav-item ${
                  active === item.id ? "active" : ""
                }`}
                onClick={() => selectSection(item.id)}
              >
                <ItemIcon size={19} />

                <span>{item.label}</span>

                {active === item.id && (
                  <ChevronRight size={16} />
                )}
              </button>
            );
          })}
        </nav>

        {/* Administrator profile and security information. */}
        <div className="admin-sidebar-bottom">
          <div className="admin-secure-note">
            <LockKeyhole size={17} />
            <span>Restricted administrator access</span>
          </div>

          <div className="admin-profile">
            <div className="admin-avatar">AD</div>

            <div>
              <strong>Administrator</strong>
              <span>Platform administration</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main dashboard area. */}
      <main className="admin-main">

        {/* Top navigation bar. */}
        <header className="admin-topbar">
          <button
            className="admin-menu-button"
            onClick={() => setMobileOpen(true)}
          >
            <Menu size={22} />
          </button>

          <div className="admin-breadcrumb">
            UniAble <span>/</span> Administration <span>/</span>{" "}
            {current?.label}
          </div>

          <div className="admin-topbar-actions">
            <label className="admin-search">
              <Search size={17} />

              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search this workspace"
              />
            </label>

            <button
              className="admin-icon-button"
              aria-label="Notifications"
            >
              <Bell size={19} />
            </button>

            <button
              type="button"
              className="admin-logout-button"
              onClick={handleLogout}
              disabled={loggingOut}
            >
              <LogOut size={17} />

              {loggingOut ? "Signing out..." : "Log out"}
            </button>
          </div>
        </header>

        {/* Main page content. */}
        <div className="admin-content">

          {/* Page heading. */}
          <div className="admin-heading">
            <div>
              <p className="admin-eyebrow">
                UNIABLE PLATFORM MANAGEMENT
              </p>

              <h1>
                {active === "overview"
                  ? "Administration overview"
                  : current?.label}
              </h1>

              <p>
                {active === "overview"
                  ? "Manage the platform, institutional accounts and administrative services."
                  : descriptions[active]}
              </p>
            </div>

            <span className="admin-access-badge">
              <ShieldCheck size={16} />
              Administrator
            </span>
          </div>

          {/* Display the appropriate dashboard section. */}
          {active === "analytics" ? (
            <AdminReports />

          ) : active === "staff" ? (
            <StaffManagement />

          ) : active === "academics" ? (
            <AdminAcademicManagement />

          ) : active === "approvals" ? (
            <AdminApprovals />

          ) : [
              "users",
              "departments",
              "settings",
              "audit",
              "support",
              "accessibility",
              "announcements",
              "attendance"
            ].includes(active) ? (
            <AdminOperations section={active} />

          ) : active === "overview" ? (

            <>
              {/* Welcome section. */}
              <section className="admin-welcome">
                <div>
                  <span>ADMINISTRATIVE WORKSPACE</span>

                  <h2>
                    Platform oversight and management
                  </h2>

                  <p>
                    A central workspace for managing UniAble accounts,
                    institutional teams and platform configuration.
                  </p>
                </div>

                <div className="admin-welcome-icon">
                  <Building2 size={42} />
                </div>
              </section>

              {/* Dashboard statistics cards. */}
              <div className="admin-stat-grid">
                {statCards.map(
                  ({ label, icon: StatIcon, value }) => (
                    <article
                      className="admin-stat-card"
                      key={label}
                    >
                      <div className="admin-stat-top">
                        <span>{label}</span>
                        <StatIcon size={20} />
                      </div>

                      <strong>
                        {dashboardLoading ? "…" : value}
                      </strong>

                      <small>
                        {dashboardLoading
                          ? "Loading live data"
                          : dashboardError
                            ? "Data unavailable"
                            : "From the UniAble database"}
                      </small>
                    </article>
                  )
                )}
              </div>

              {/* Database backup section. */}
              <section
                style={{
                  background: "#ffffff",
                  border: "1px solid #e2e8f0",
                  borderRadius: "14px",
                  padding: "24px",
                  marginTop: "24px",
                  color: "#1e293b"
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "12px"
                  }}
                >
                  <ShieldCheck
                    size={25}
                    color="#2563eb"
                  />

                  <div>
                    <h2 style={{ margin: 0 }}>
                      Database Backup
                    </h2>

                    <p
                      style={{
                        margin: "5px 0",
                        color: "#64748b"
                      }}
                    >
                      Back up UniAble Firebase records to your
                      secondary Supabase database.
                    </p>
                  </div>
                </div>

                {/* Button that starts the backup operation. */}
                <button
                  type="button"
                  onClick={handleRunBackup}
                  disabled={backupLoading}
                  style={{
                    marginTop: "18px",
                    padding: "12px 20px",
                    background: backupLoading
                      ? "#94a3b8"
                      : "#2563eb",
                    color: "#ffffff",
                    border: "none",
                    borderRadius: "8px",
                    cursor: backupLoading
                      ? "not-allowed"
                      : "pointer",
                    fontWeight: "600"
                  }}
                >
                  {backupLoading
                    ? "Running backup..."
                    : "Run Database Backup"}
                </button>

                {/* Show an error if the backup request fails. */}
                {backupError && (
                  <div
                    role="alert"
                    style={{
                      marginTop: "15px",
                      color: "#dc2626"
                    }}
                  >
                    <strong>Backup failed:</strong>{" "}
                    {backupError}
                  </div>
                )}

                {/* Display the successful backup result. */}
                {backupResult && (
                  <div
                    role="status"
                    style={{
                      marginTop: "18px",
                      padding: "15px",
                      background: "#f0fdf4",
                      borderRadius: "8px",
                      color: "#166534"
                    }}
                  >
                    <strong>
                      Backup completed successfully!
                    </strong>

                    <p>
                      Total documents backed up:{" "}
                      {backupResult.totalDocuments}
                    </p>

                    {backupResult.collections?.map((item) => (
                      <p key={item.collection}>
                        {item.collection}:{" "}
                        {item.documentsBackedUp} documents
                      </p>
                    ))}

                    <small>
                      Completed: {backupResult.completedAt}
                    </small>
                  </div>
                )}
              </section>

              {/* Display dashboard loading errors. */}
              {dashboardError && (
                <div
                  className="admin-empty-state"
                  role="alert"
                >
                  <strong>
                    Dashboard data could not be loaded
                  </strong>

                  <span>{dashboardError}</span>
                </div>
              )}
            </>

          ) : (
            <AdminOperations section={active} />
          )}

          {/* Dashboard footer. */}
          <footer className="admin-footer">
            <span>
              UniAble · Administration Portal
            </span>

            <span>
              Secure institutional workspace
            </span>
          </footer>
        </div>
      </main>
    </div>
  );
}
