
import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  Download,
  FileSpreadsheet,
  FileText,
  RefreshCw
} from "lucide-react";
import { api } from "../services/api";
import "./AdminReports.css";

const REPORTS = {
  students: {
    label: "Student accounts",
    dataKey: "students",
    columns: [
      ["Full name", "fullName"],
      ["Email", "email"],
      ["Department", "department"],
      ["Account status", "accountStatus"],
      ["Registered", "createdAt"]
    ]
  },

  volunteers: {
    label: "Volunteer accounts",
    dataKey: "volunteers",
    columns: [
      ["Full name", "fullName"],
      ["Email", "email"],
      ["Role", "role"],
      ["Account status", "accountStatus"],
      ["Availability", "volunteerAvailability"],
      ["Registered", "createdAt"]
    ]
  },

  security: {
    label: "Security accounts",
    dataKey: "security",
    columns: [
      ["Full name", "fullName"],
      ["Email", "email"],
      ["Role", "role"],
      ["Account status", "accountStatus"],
      ["Registered", "createdAt"]
    ]
  },

  securityAlerts: {
    label: "Campus security alerts",
    dataKey: "securityAlerts",
    columns: [
      ["Student ID", "studentId"],
      ["Alert status", "status"],
      ["Source", "source"],
      ["Created", "createdAt"],
      ["Last updated", "updatedAt"],
      ["Resolved", "resolvedAt"]
    ]
  },

  staff: {
    label: "Staff accounts",
    dataKey: "staff",
    columns: [
      ["Full name", "fullName"],
      ["Email", "email"],
      ["Role", "role"],
      ["Department", "department"],
      ["Account status", "accountStatus"],
      ["Registered", "createdAt"]
    ]
  },

  unassigned: {
    label: "Accounts needing role review",
    dataKey: "unassigned",
    columns: [
      ["Full name", "fullName"],
      ["Email", "email"],
      ["Role", "role"],
      ["Account status", "accountStatus"],
      ["Registered", "createdAt"]
    ]
  },

  attendance: {
    label: "Attendance",
    dataKey: "attendance",
    columns: [
      ["Student ID", "studentId"],
      ["Date", "date"],
      ["Session / module", "session"],
      ["Status", "status"]
    ]
  },

  support: {
    label: "Support requests",
    dataKey: "requests",
    columns: [
      ["Request type", "type"],
      ["Status", "status"],
      ["Priority", "priority"],
      ["Created", "createdAt"]
    ]
  },

  accessibility: {
    label: "Accessibility overview",
    summary: true
  },

  announcements: {
    label: "Announcements",
    dataKey: "announcements",
    columns: [
      ["Title", "title"],
      ["Priority", "priority"],
      ["Published", "published"],
      ["Created", "createdAt"]
    ]
  },

  modules: {
    label: "Academic modules",
    dataKey: "modules",
    columns: [
      ["Module code", "code"],
      ["Module name", "name"],
      ["Assigned students", "assignedStudents"],
      ["Created", "createdAt"]
    ]
  },

  auditLogs: {
    label: "System activity",
    dataKey: "auditLogs",
    columns: [
      ["Action", "action"],
      ["Actor role", "actorRole"],
      ["Date", "createdAt"]
    ]
  }
};

function dateValue(value) {
  if (!value) return "";

  const date = new Date(value);

  return Number.isNaN(date.getTime())
    ? String(value)
    : date.toLocaleString();
}

function csvCell(value) {
  const safe = String(value ?? "").replace(/"/g, '""');
  return `"${safe}"`;
}

function displayValue(value) {
  if (typeof value === "boolean") {
    return value ? "Yes" : "No";
  }

  return String(value ?? "—");
}

export default function AdminReports() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [reportType, setReportType] = useState("students");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const loadReports = useCallback(async (showLoading = true) => {
    if (showLoading) setLoading(true);
    setError("");

    try {
      const result = await api.getAdminReports();
      setData(result);
    } catch (e) {
      setError(e.message || "Could not load reports.");
    } finally {
      if (showLoading) setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadReports();
    const refreshId = window.setInterval(() => loadReports(false), 30000);
    return () => window.clearInterval(refreshId);
  }, [loadReports]);

  const report = REPORTS[reportType];

  const rows = useMemo(() => {
    if (!data || report.summary) return [];

    const items = data.reports?.[report.dataKey] || [];

    return items.filter(item => {
      const rawDate = item.date || item.createdAt;

      // If a record has no date, include it only when
      // the administrator has not selected a date range.
      if (!rawDate) {
        return !fromDate && !toDate;
      }

      const parsed = new Date(rawDate);

      if (Number.isNaN(parsed.getTime())) {
        return !fromDate && !toDate;
      }

      const day = parsed.toISOString().slice(0, 10);

      return (
        (!fromDate || day >= fromDate) &&
        (!toDate || day <= toDate)
      );
    });
  }, [data, report, fromDate, toDate]);

  function getPrintableRows() {
    if (report.summary) {
      return [
        [
          "Accessibility profiles recorded",
          data?.accessibility?.profilesCount ?? 0
        ],
        [
          "Note",
          "Aggregate totals only. Individual accommodation details are not exported."
        ]
      ];
    }

    return rows.map(item =>
      report.columns.map(([, key]) => {
        if (key === "createdAt" || key === "date") {
          return dateValue(item[key]);
        }

        return displayValue(item[key]);
      })
    );
  }

  function downloadCsv() {
    if (!data) return;

    const matrix = report.summary
      ? [["Metric", "Value"], ...getPrintableRows()]
      : [
          report.columns.map(([label]) => label),
          ...getPrintableRows()
        ];

    const csv =
      "\uFEFF" +
      matrix.map(row => row.map(csvCell).join(",")).join("\r\n");

    const blob = new Blob([csv], {
      type: "text/csv;charset=utf-8"
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download =
      `uniable-${reportType}-report-${new Date()
        .toISOString()
        .slice(0, 10)}.csv`;

    document.body.appendChild(link);
    link.click();
    link.remove();

    URL.revokeObjectURL(url);
  }

  function downloadPdf() {
    if (!data) return;

    const headings = report.summary
      ? ["Metric", "Value"]
      : report.columns.map(([label]) => label);

    const bodyRows = getPrintableRows();

    const escapeHtml = value =>
      String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[char]));

    const table = `
      <table>
        <thead>
          <tr>
            ${headings.map(x => `<th>${escapeHtml(x)}</th>`).join("")}
          </tr>
        </thead>
        <tbody>
          ${bodyRows.map(row => `
            <tr>
              ${row.map(x => `<td>${escapeHtml(x)}</td>`).join("")}
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;

    const win = window.open("", "_blank", "width=1000,height=750");

    if (!win) {
      setError("Please allow pop-ups to create the PDF report.");
      return;
    }

    win.document.write(`
      <!doctype html>
      <html>
        <head>
          <title>${escapeHtml(report.label)} - UniAble</title>
          <style>
            body {
              font: 12px Arial, sans-serif;
              padding: 28px;
              color: #172033;
            }

            h1 {
              font-size: 22px;
            }

            p {
              color: #555;
            }

            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }

            th, td {
              border: 1px solid #d8dee8;
              padding: 9px;
              text-align: left;
              overflow-wrap: anywhere;
            }

            th {
              background: #eef2f7;
            }

            tr {
              break-inside: avoid;
            }

            @media print {
              button {
                display: none;
              }
            }
          </style>
        </head>

        <body>
          <h1>UniAble — ${escapeHtml(report.label)}</h1>

          <p>
            Generated: ${escapeHtml(new Date().toLocaleString())}
          </p>

          <p>
            Period: ${escapeHtml(fromDate || "All dates")}
            to ${escapeHtml(toDate || "Present")}
          </p>

          ${table}

          <script>
            window.onload = () => window.print();
          <\/script>
        </body>
      </html>
    `);

    win.document.close();
  }

  return (
    <section className="admin-panel admin-reports">

      <div className="reports-toolbar">
        <div>
          <h2>Reports and downloads</h2>
          <p>Generate current reports from UniAble records.</p>
        </div>

        <button
          type="button"
          className="reports-refresh"
          onClick={() => loadReports(true)}
          disabled={loading}
        >
          <RefreshCw size={16} />
          {loading ? "Refreshing..." : "Refresh data"}
        </button>
      </div>

      {error && (
        <p className="reports-error" role="alert">
          {error}
        </p>
      )}

      <div className="reports-filters">

        <label>
          Report type

          <select
            value={reportType}
            onChange={e => setReportType(e.target.value)}
          >
            {Object.entries(REPORTS).map(([key, value]) => (
              <option key={key} value={key}>
                {value.label}
              </option>
            ))}
          </select>
        </label>

        <label>
          From date

          <input
            type="date"
            value={fromDate}
            onChange={e => setFromDate(e.target.value)}
          />
        </label>

        <label>
          To date

          <input
            type="date"
            value={toDate}
            min={fromDate || undefined}
            onChange={e => setToDate(e.target.value)}
          />
        </label>

      </div>

      <div className="reports-summary-grid">

        {Object.entries({
          "Total users": data?.summary?.totalUsers,
          "Students": data?.summary?.students,
          "Volunteers": data?.summary?.volunteers,
          "Security": data?.summary?.security,
          "Staff": data?.summary?.staff,
          "Needs role review": data?.summary?.unassignedAccounts,
          "Attendance records": data?.summary?.attendanceRecords,
          "Support requests": data?.summary?.supportRequests,
          "Accessibility profiles": data?.summary?.accessibilityProfiles
        }).map(([label, value]) => (
          <article key={label}>
            <span>{label}</span>

            <strong>
              {loading ? "…" : value ?? 0}
            </strong>
          </article>
        ))}

      </div>

      <div className="reports-preview">

        <div className="reports-preview-heading">

          <div>
            <h3>{report.label}</h3>

            <span>
              {report.summary
                ? "Aggregate information"
                : `${rows.length} record(s) in selected date range`}
            </span>
          </div>

          <div className="reports-downloads">

            <button
              type="button"
              onClick={downloadCsv}
              disabled={loading || !data}
            >
              <FileSpreadsheet size={17} />
              Download CSV (Excel-compatible)
            </button>

            <button
              type="button"
              onClick={downloadPdf}
              disabled={loading || !data}
            >
              <FileText size={17} />
              Download PDF
            </button>

          </div>

        </div>

        {loading ? (
          <p>Loading report data...</p>
        ) : report.summary ? (

          <p className="reports-accessibility-total">
            Accessibility profiles recorded:{" "}
            <strong>
              {data?.accessibility?.profilesCount ?? 0}
            </strong>

            <br />

            Individual disability and accommodation details
            are intentionally excluded from downloads.
          </p>

        ) : rows.length === 0 ? (

          <p>No records match this report and date range.</p>

        ) : (

          <div className="reports-table-wrap">

            <table>
              <thead>
                <tr>
                  {report.columns.map(([label]) => (
                    <th key={label}>{label}</th>
                  ))}
                </tr>
              </thead>

              <tbody>
                {rows.slice(0, 100).map((item, index) => (
                  <tr key={item.id || index}>
                    {report.columns.map(([label, key]) => (
                      <td key={key}>
                        {key === "createdAt" || key === "date"
                          ? dateValue(item[key])
                          : displayValue(item[key])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>

            {rows.length > 100 && (
              <small>
                Preview shows the first 100 records.
                Downloads include all matching records.
              </small>
            )}

          </div>

        )}

      </div>

      <p className="reports-footnote">
        <Download size={14} />
        CSV files open in Microsoft Excel. For PDF,
        choose "Save as PDF" in the print window.
      </p>

    </section>
  );
}
