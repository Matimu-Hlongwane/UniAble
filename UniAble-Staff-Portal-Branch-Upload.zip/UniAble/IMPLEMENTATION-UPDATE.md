# UniAble implementation update

## Changes made

- Replaced the generic volunteer request area with a volunteer-focused dashboard showing open student requests, learner names, support reasons, locations, priorities, and request status.
- Volunteers can accept an open request. The backend assigns it to the first volunteer who accepts it, and the volunteer browser opens a Google Maps route to the learner's shared coordinates (or entered campus location).
- Student peer-assistance requests can attach the student's current GPS coordinates. The student dashboard checks request status every 10 seconds and displays **Help is on the way** after a volunteer accepts.
- Emergency SOS no longer submits a hard-coded student ID or fake coordinates. It asks for the emergency reason and obtains the student's current GPS location before submitting.
- Security alerts include the learner's name, emergency reason, coordinates, and a Google Maps route action.
- Volunteer and security registration now asks for First Name and Last Name separately.
- Volunteer and security applications are created as disabled, pending applications. The admin Approvals page lists pending applications, including volunteer application details.
- Admin approval activates the account and sends an email OTP through Resend. The applicant can enter that OTP on the signup confirmation page or sign-in page. Declined applicants receive **Account creation denied**.
- Connected the previously placeholder admin pages for user directory, departments, system settings, and audit logs to backend endpoints and Firestore collections.
- Academic Management already had upload/publish controls; the wording now identifies study guides. Published study guides are available to all signed-in students in the Student Dashboard, not only students enrolled in a specific module.
- Added `firestore.rules` to match the new student and pending staff profile creation fields.

## Required setup before testing

1. Open Firebase Console → Firestore Database → Rules. Publish the contents of `firestore.rules` from this project. The old rules do not allow the new `firstName`, `lastName`, `approvalStatus`, and `pending_approval` profile fields.
2. Confirm `backend/.env` contains valid `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, and `OTP_SECRET` values. Keep these secrets on the backend only.
3. Confirm Firebase Admin credentials in `backend/.env` point to the same Firebase project used by the frontend.
4. Enable browser/device location permission. Precise GPS access normally requires HTTPS in production (localhost is permitted during local development).
5. To publish study guides, open Admin Dashboard → Academic Management, create a module, upload a PDF/Word/PowerPoint guide, and click Publish. Firebase Storage must be enabled and its Storage Rules must permit the administrator upload and authenticated student download.
6. Google Maps is used to open directions. The app does not provide live in-app vehicle tracking; the browser/device opens turn-by-turn navigation in Google Maps.

## Validation performed

- All backend JavaScript source files passed `node --check`.
- All 40 frontend JSX files passed TypeScript JSX syntax transpilation.
- All relative frontend imports were checked and resolved.
- A full Vite production build and live Firebase/Resend integration test were not run in this environment. The frontend dependency installation did not complete before the environment timeout, and live credentials are not included in the uploaded archive.
