﻿import React from "react";
import { Link } from "react-router-dom";
import Landing from "./Landing";
import "./AuthPages.css";

export default function LandingEntry() {
  return (
    <>
      <nav className="landing-auth-nav" aria-label="Account">
        <Link to="/login">Sign in</Link>
        <Link className="landing-signup-link" to="/signup">Create account</Link>
      </nav>
      <Landing />
    </>
  );
}

