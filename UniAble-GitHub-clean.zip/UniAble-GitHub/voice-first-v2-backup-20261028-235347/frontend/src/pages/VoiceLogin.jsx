import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mic, MicOff, Volume2 } from "lucide-react";
import { SpeechRecognition } from "@capacitor-community/speech-recognition";
import { signInWithEmailPassword } from "../services/firebaseAuth";
import { speak } from "../services/speechService";
import "./VoiceLogin.css";

function cleanSpokenEmail(value) {
  return value
    .trim()
    .toLowerCase()
    .replace(/\bat sign\b|\bat\b/g, "@")
    .replace(/\bdot\b/g, ".")
    .replace(/\s+at\s+/g, "@")
    .replace(/\s+/g, "");
}

function browserRecognizeEmail() {
  return new Promise((resolve, reject) => {
    const BrowserRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!BrowserRecognition) {
      reject(new Error("Voice recognition is not supported in this browser."));
      return;
    }

    const recognition = new BrowserRecognition();
    recognition.lang = "en-ZA";
    recognition.maxAlternatives = 3;
    recognition.interimResults = false;
    recognition.continuous = false;

    recognition.onresult = (event) => {
      const transcript = event.results?.[0]?.[0]?.transcript;
      if (transcript) resolve(transcript);
      else reject(new Error("I could not hear an email address. Please try again."));
    };

    recognition.onerror = () => {
      reject(new Error("I could not recognise your email. Please try again or type it."));
    };

    recognition.onend = () => {};
    recognition.start();
  });
}

export default function VoiceLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [listening, setListening] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("Press the microphone and say your email address.");
  const [error, setError] = useState("");

  async function captureEmail() {
    if (listening || busy) return;

    setListening(true);
    setError("");
    setMessage("Listening for your email address…");

    try {
      let transcript = "";

      try {
        const permission = await SpeechRecognition.requestPermissions();
        const state = permission?.speechRecognition;
        if (state && state !== "granted") {
          throw new Error("Microphone permission was not granted.");
        }

        const result = await SpeechRecognition.start({
          language: "en-ZA",
          maxResults: 3,
          prompt: "Say your email address",
          partialResults: false
        });

        transcript = result?.matches?.[0] || "";
      } catch (nativeError) {
        // Use browser speech recognition if the native plugin is unavailable.
        if (nativeError?.message?.includes("permission")) throw nativeError;
        transcript = await browserRecognizeEmail();
      }

      const cleaned = cleanSpokenEmail(transcript);

      if (!cleaned.includes("@") || !cleaned.includes(".")) {
        throw new Error("That did not sound like a complete email address. Try again or type it.");
      }

      setEmail(cleaned);
      setMessage(`Email captured: ${cleaned}. Check it before signing in.`);
    } catch (captureError) {
      setError(captureError?.message || "Voice input failed. You can type your email instead.");
      setMessage("Voice input did not complete.");
    } finally {
      setListening(false);
      try {
        await SpeechRecognition.stop();
      } catch {
        // It is okay if recognition has already stopped.
      }
    }
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError("");
    setBusy(true);

    try {
      await signInWithEmailPassword(email.trim(), password);
      navigate("/dashboard", { replace: true });
    } catch (err) {
      console.error("UniAble voice-assisted login failed:", err);

      if (
        err.code === "auth/invalid-credential" ||
        err.code === "auth/wrong-password" ||
        err.code === "auth/user-not-found"
      ) {
        setError("The email address or password is incorrect.");
      } else if (err.code === "auth/too-many-requests") {
        setError("Too many attempts. Please wait and try again.");
      } else {
        setError(err.message || "Unable to sign in. Please try again.");
      }
    } finally {
      setBusy(false);
    }
  }

  async function readInstructions() {
    const result = await speak(
      "Welcome to UniAble voice-assisted login. Press the microphone and say your email address. Check the email, then enter your password using the password field. Your password should not be spoken aloud.",
      { locale: "en-ZA" }
    );
    if (!result.started) {
      setMessage("Text-to-speech is not available on this device. The sign-in instructions remain available on screen.");
    }
  }

  return (
    <main className="voice-login-page">
      <section className="voice-login-card" aria-labelledby="voice-login-heading">
        <Link className="voice-login-brand" to="/">UniAble</Link>
        <p className="voice-login-eyebrow">ACCESSIBLE SIGN-IN</p>
        <h1 id="voice-login-heading">Voice Login</h1>
        <p className="voice-login-description">
          Use your voice to enter your email, then sign in securely with your password.
        </p>

        <button
          className="voice-login-mic"
          type="button"
          onClick={captureEmail}
          disabled={listening || busy}
          aria-label={listening ? "Listening for email address" : "Speak email address"}
        >
          {listening ? <MicOff size={30} /> : <Mic size={30} />}
          <span>{listening ? "Listening…" : "Speak your email"}</span>
        </button>

        <p className="voice-login-status" role="status" aria-live="polite">
          {message}
        </p>

        <button className="voice-login-read" type="button" onClick={readInstructions}>
          <Volume2 size={18} /> Read instructions aloud
        </button>

        <form onSubmit={handleSubmit} className="voice-login-form">
          <label htmlFor="voice-login-email">Email address</label>
          <input
            id="voice-login-email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="Check or type your email"
            required
          />

          <label htmlFor="voice-login-password">Password</label>
          <input
            id="voice-login-password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Enter your password"
            required
          />

          {error && <p className="voice-login-error" role="alert">{error}</p>}

          <button className="voice-login-submit" type="submit" disabled={busy || listening}>
            {busy ? "Signing in…" : "Confirm and sign in"}
          </button>
        </form>

        <p className="voice-login-switch">
          Prefer typing? <Link to="/login">Login with Email</Link>
        </p>
        <Link className="voice-login-back" to="/">Back to home</Link>
      </section>
    </main>
  );
}
