# UniAble Voice-First Accessibility Patch

This patch updates five existing source files only:

- `frontend/src/components/Layout.jsx`
- `frontend/src/pages/Login.jsx`
- `frontend/src/services/speechService.js`
- `frontend/src/services/firebaseAuth.js`
- `frontend/src/auth-signup/pages/SignUp.jsx`

## Apply it

1. Extract the entire ZIP directly into `C:\Users\gundo\OneDrive\Desktop\UniAble-GitHub` and allow the `patch` folder and PowerShell script to appear there. Do not extract over the `frontend/src` folder manually.
2. Open PowerShell in the `UniAble-GitHub` project root and run:

   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass
   .\Apply-UniAble-VoiceFirst-Fix.ps1
   ```

3. The script creates a timestamped backup of all five original files before replacing them.
4. Then run:

   ```powershell
   Set-Location .\frontend
   npm run build
   ```

## What this patch changes

- Voice-first page guidance no longer depends on the separate UniPal `spokenResponses` setting.
- Known pages receive page-specific guidance; other pages inside the shared layout receive generic navigation guidance.
- The sign-in page announces instructions for password sign-in, email-link requests, and email-link callbacks.
- Signup gets a spoken introduction for a saved Blind / Low-Vision profile.
- A stale `voiceFirstEnabled: false` value no longer overrides a Blind / Low-Vision default unless the preference was deliberately changed through the voice-first toggle.
- Speech requests are invalidated when pages change, preventing an older delayed speech request from starting on the next page.
- The email and password are not spoken aloud.

## Important browser limitation

Some browsers block automatic speech until the user has interacted with the page, and speech depends on an available device voice or text-to-speech engine. The patch adds visible status feedback when guidance cannot start, but it cannot install or enable a missing operating-system speech engine.
