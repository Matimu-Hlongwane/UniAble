﻿import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Accessibility,
  GraduationCap,
  Mic,
  Volume2,
  Mail,
  Globe,
  Sparkles,
  ArrowRight,
} from "lucide-react";
import "./LandingPrototype.css";

export default function Landing() {
  const [guestMessage, setGuestMessage] = useState("");

  return (
    <main className="uniable-welcome">
      <section className="uniable-welcome-card" aria-labelledby="uniable-title">
        <header className="uniable-welcome-brand">
          <div className="uniable-welcome-logo" aria-hidden="true">
            <GraduationCap size={39} strokeWidth={1.8} />
          </div>
          <h1 id="uniable-title">UniAble</h1>
          <p className="uniable-welcome-tagline">
            Inclusion Starts With Access
          </p>
        </header>

        <div className="uniable-welcome-actions">
          <Link className="uniable-entry-button uniable-entry-primary" to="/signup">
            <Mic size={21} aria-hidden="true" />
            <span>
              <strong>Voice Sign-Up</strong>
              <small>New student</small>
            </span>
            <ArrowRight className="uniable-entry-arrow" size={18} aria-hidden="true" />
          </Link>

          <Link className="uniable-entry-button" to="/login">
            <Volume2 size={21} aria-hidden="true" />
            <span>
              <strong>Voice Login</strong>
              <small>Returning student</small>
            </span>
            <ArrowRight className="uniable-entry-arrow" size={18} aria-hidden="true" />
          </Link>

          <Link className="uniable-entry-button" to="/login">
            <Mail size={21} aria-hidden="true" />
            <span>
              <strong>Login with Email</strong>
              <small>Sign in with your credentials</small>
            </span>
            <ArrowRight className="uniable-entry-arrow" size={18} aria-hidden="true" />
          </Link>

          <button
            className="uniable-entry-button uniable-entry-guest"
            type="button"
            onClick={() =>
              setGuestMessage(
                "Guest access is not available yet. Please sign in or create an account."
              )
            }
          >
            <Accessibility size={21} aria-hidden="true" />
            <span>
              <strong>Continue as Guest</strong>
              <small>Guest access not yet enabled</small>
            </span>
          </button>
        </div>

        {guestMessage && (
          <p className="uniable-guest-message" role="status">
            {guestMessage}
          </p>
        )}

        <section className="uniable-info-card">
          <div className="uniable-info-icon">
            <Globe size={23} aria-hidden="true" />
          </div>
          <div>
            <h2>South African languages</h2>
            <p>Accessible language and voice support for students.</p>
          </div>
        </section>

        <section className="uniable-info-card">
          <div className="uniable-info-icon">
            <Sparkles size={23} aria-hidden="true" />
          </div>
          <div>
            <h2>Say “Hey UniAble”</h2>
            <p>Your accessible campus companion, designed around your needs.</p>
          </div>
        </section>

        <footer className="uniable-welcome-footer">
          <Accessibility size={17} aria-hidden="true" />
          <span>Designed for accessible, independent learning</span>
        </footer>
      </section>
    </main>
  );
}
