﻿$ErrorActionPreference = "Stop"

$project = $PSScriptRoot
$patchRoot = Join-Path $project "patch\frontend\src"
$sourceRoot = Join-Path $project "frontend\src"
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupRoot = Join-Path $project "voice-first-fix-backup-$stamp"

$relativeFiles = @(
    "components\Layout.jsx",
    "pages\Login.jsx",
    "services\speechService.js",
    "services\firebaseAuth.js",
    "auth-signup\pages\SignUp.jsx"
)

foreach ($relative in $relativeFiles) {
    $source = Join-Path $patchRoot $relative
    $target = Join-Path $sourceRoot $relative
    if (-not (Test-Path $source)) {
        throw "Patch file is missing: $source. Extract the entire ZIP into the UniAble-GitHub project root first."
    }
    if (-not (Test-Path $target)) {
        throw "Your current project file was not found: $target. No files have been changed."
    }
}

New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

foreach ($relative in $relativeFiles) {
    $source = Join-Path $patchRoot $relative
    $target = Join-Path $sourceRoot $relative
    $backup = Join-Path $backupRoot $relative

    New-Item -ItemType Directory -Path (Split-Path $backup) -Force | Out-Null
    Copy-Item -LiteralPath $target -Destination $backup
    Copy-Item -LiteralPath $source -Destination $target -Force
    Write-Host "Updated: $relative"
}

Write-Host ""
Write-Host "Voice-first accessibility fixes applied."
Write-Host "Backup of original files: $backupRoot"
Write-Host "No Git commit or push was performed."
Write-Host "Next, run npm run build from the frontend folder."
