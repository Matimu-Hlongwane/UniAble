import React, { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../services/api";
import { useSettings } from "../context/settingsContext/SettingsContext";
import { isNative, startNativeVoiceRecognition } from "../services/platformVoice";
import { speak, stopSpeaking } from "../services/speechService";

const ROUTES = [
  { path: "/dashboard", words: ["dashboard", "home", "student home"] },
  { path: "/schedule", words: ["schedule", "timetable", "classes", "my classes"] },
  { path: "/learning-materials", words: ["learning materials", "study materials", "course materials", "my materials", "notes"] },
  { path: "/campus", words: ["campus", "campus navigation", "directions", "navigate"] },
  { path: "/peer-assistance", words: ["peer assistance", "peer support", "student support", "volunteer help"] },
  { path: "/scan-read", words: ["scan and read", "scan document", "read document", "ocr"] },
  { path: "/accessibility", words: ["accessibility", "accessibility settings"] },
  { path: "/settings", words: ["settings", "my settings"] },
  { path: "/emergency", words: ["emergency", "emergency page", "emergency options"] },
  { path: "/unipal", words: ["unipal page", "open unipal"] },
];

const normalise = (value) => String(value || "").toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();

function dateLabel(value) {
  if (!value) return "date not provided";
  const parsed = new Date(`${value}T00:00:00`);
  return Number.isNaN(parsed.getTime()) ? String(value) : parsed.toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" });
}

export default function HandsFreeUniPal({ enabled = false }) {
  const { locale = "en-ZA", language = "English", theme, fontSize } = useSettings();
  const navigate = useNavigate();
  const [status, setStatus] = useState("Starting voice access");
  const [lastHeard, setLastHeard] = useState("");
  const [lastReply, setLastReply] = useState("UniPal is preparing your hands-free assistant.");
  const [problem, setProblem] = useState("");
  const activeRef = useRef(false);
  const startingRef = useRef(false);
  const processingRef = useRef(false);
  const speakingRef = useRef(false);
  const greetedRef = useRef(false);
  const browserRef = useRef(null);
  const nativeStopRef = useRef(null);
  const restartTimerRef = useRef(null);
  const pendingRef = useRef(null);
  const conversationRef = useRef([]);

  const stopRecognition = useCallback(async () => {
    if (restartTimerRef.current) window.clearTimeout(restartTimerRef.current);
    restartTimerRef.current = null;
    const nativeStop = nativeStopRef.current;
    nativeStopRef.current = null;
    if (nativeStop) {
      try { await nativeStop(); } catch (error) { console.warn("UniPal native stop:", error); }
    }
    const browser = browserRef.current;
    if (browser) {
      try { browser.stop(); } catch { /* already stopped */ }
    }
    startingRef.current = false;
  }, []);

  const startListening = useCallback(async () => {
    if (!activeRef.current || startingRef.current || processingRef.current) return;
    startingRef.current = true;
    setProblem("");
    setStatus("Listening for your voice");
    try {
      if (isNative()) {
        const stop = await startNativeVoiceRecognition({
          language: locale || "en-ZA",
          onResult: (text, isFinal) => {
            if (isFinal && String(text || "").trim()) void handleUtteranceRef.current(text);
          },
          onError: (error) => {
            startingRef.current = false;
            setProblem(error?.message || "Voice recognition is unavailable. Check microphone permission and speech services.");
            setStatus("Voice access needs attention");
          },
          onEnd: () => {
            nativeStopRef.current = null;
            startingRef.current = false;
            if (activeRef.current && !processingRef.current) scheduleRestart();
          },
        });
        nativeStopRef.current = stop;
      } else {
        const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!Recognition) throw new Error("This browser does not support speech recognition. Try the UniAble Android app or a supported browser.");
        let recognition = browserRef.current;
        if (!recognition) {
          recognition = new Recognition();
          recognition.continuous = true;
          recognition.interimResults = false;
          recognition.maxAlternatives = 1;
          browserRef.current = recognition;
          recognition.onresult = (event) => {
            for (let index = event.resultIndex; index < event.results.length; index += 1) {
              const result = event.results[index];
              if (result.isFinal && result[0]?.transcript) void handleUtteranceRef.current(result[0].transcript);
            }
          };
          recognition.onerror = (event) => {
            if (["not-allowed", "service-not-allowed"].includes(event.error)) {
              setProblem("Microphone permission is required. Allow microphone access in your browser or device settings, then reload UniAble.");
              setStatus("Microphone permission required");
              activeRef.current = false;
            } else if (event.error !== "no-speech" && event.error !== "aborted") {
              setProblem(`Voice recognition issue: ${event.error}. UniPal will try again.`);
            }
          };
          recognition.onend = () => {
            startingRef.current = false;
            if (activeRef.current && !processingRef.current) scheduleRestart();
          };
        }
        recognition.lang = locale || "en-ZA";
        recognition.start();
      }
    } catch (error) {
      startingRef.current = false;
      setProblem(error?.message || "Voice recognition could not start.");
      setStatus("Voice access unavailable");
    }
  // startListening intentionally calls a ref for the latest command handler.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locale]);

  const say = useCallback(async (text) => {
    const message = String(text || "").trim();
    if (!message) return;
    setLastReply(message);
    setStatus("UniPal is speaking");
    speakingRef.current = true;
    // Keep recognition active during speech so the student can interrupt UniPal.
    // Supported browser/native engines apply their own microphone echo handling.
    let completed = false;
    const resume = () => {
      if (completed) return;
      completed = true;
      speakingRef.current = false;
      if (activeRef.current) setStatus("Listening for your voice");
      if (activeRef.current && !processingRef.current) scheduleRestart(450);
    };
    try {
      const result = await speak(message, {
        locale: locale || "en-ZA",
        rate: 0.96,
        onEnd: resume,
        onError: resume,
      });
      if (!result.started) {
        setProblem("Spoken output is not available for this language or device. Your response remains available to a screen reader.");
        resume();
      }
    } catch (error) {
      setProblem(error?.message || "UniPal could not speak this response.");
      resume();
    }
  }, [locale]);

  function scheduleRestart(delay = 500) {
    if (!activeRef.current) return;
    if (restartTimerRef.current) window.clearTimeout(restartTimerRef.current);
    restartTimerRef.current = window.setTimeout(() => {
      restartTimerRef.current = null;
      void startListening();
    }, delay);
  }

  const readTimetable = useCallback(async () => {
    setStatus("Loading your timetable");
    const result = await api.getAcademicTimetable();
    const entries = Array.isArray(result?.timetable) ? result.timetable : [];
    if (!entries.length) {
      await say("I could not find any timetable entries assigned to your account yet. Please ask your lecturer or department to publish your timetable.");
      return;
    }
    const sorted = [...entries].sort((a, b) => `${a.date || ""} ${a.startTime || ""}`.localeCompare(`${b.date || ""} ${b.startTime || ""}`));
    const summary = sorted.slice(0, 12).map((item, index) => {
      const title = item.title || "Class";
      return `Class ${index + 1}: ${title}, ${dateLabel(item.date)}, from ${item.startTime || "time not set"} to ${item.endTime || "end time not set"}, venue ${item.venue || "venue not provided"}.`;
    }).join(" ");
    navigate("/schedule");
    await say(`I found ${entries.length} timetable ${entries.length === 1 ? "entry" : "entries"}. ${summary}${entries.length > 12 ? " There are more entries on your schedule page." : ""}`);
  }, [navigate, say]);

  const readMaterials = useCallback(async () => {
    setStatus("Loading your learning materials");
    const result = await api.getAcademicMaterials();
    const materials = Array.isArray(result?.materials) ? result.materials : [];
    navigate("/learning-materials");
    if (!materials.length) {
      await say("Your lecturers have not published any learning materials for your modules yet.");
      return;
    }
    const summary = materials.slice(0, 10).map((item, index) => `${index + 1}. ${item.title || item.fileName || "Untitled material"}${item.description ? `. ${item.description}` : ""}`).join(". ");
    await say(`I found ${materials.length} published learning ${materials.length === 1 ? "resource" : "resources"}. ${summary}${materials.length > 10 ? ". More resources are listed on your learning materials page." : ""}`);
  }, [navigate, say]);

  const executeSOS = useCallback(async () => {
    setStatus("Recording emergency alert");
    let locationData = null;
    if (navigator.geolocation) {
      locationData = await new Promise((resolve) => navigator.geolocation.getCurrentPosition(
        (position) => resolve({ lat: position.coords.latitude, lng: position.coords.longitude }),
        () => resolve(null),
        { enableHighAccuracy: true, timeout: 7000, maximumAge: 60000 },
      ));
    }
    const result = await api.createSOS({ location: locationData, source: "hands-free-unipal" });
    pendingRef.current = null;
    await say(`${result.message || "The SOS alert was recorded."} Important: the current UniAble server confirms that the alert is stored, but notification delivery to responders is not configured. Please contact campus security or local emergency services directly if you are in immediate danger.`);
  }, [say]);

  const handleUtterance = useCallback(async (rawText) => {
    const text = String(rawText || "").trim();
    const command = normalise(text);
    if (!command || processingRef.current) return;
    processingRef.current = true;
    setLastHeard(text);
    setProblem("");
    stopSpeaking();
    speakingRef.current = false;

    try {
      if (["stop", "be quiet", "stop talking", "stop speaking"].includes(command)) {
        setStatus("Listening");
        return;
      }
      if (pendingRef.current?.type === "sos") {
        if (/^(yes|confirm|confirm sos|send sos|do it)$/.test(command)) {
          await executeSOS();
          return;
        }
        if (/^(no|cancel|cancel sos|do not)$/.test(command)) {
          pendingRef.current = null;
          await say("I have cancelled the SOS request. No alert was recorded.");
          return;
        }
        await say("I am waiting for you to say confirm SOS or cancel SOS.");
        return;
      }
      if (pendingRef.current?.type === "peer") {
        if (/^(yes|confirm|submit|send request|send it)$/.test(command)) {
          const detail = pendingRef.current.detail;
          await api.createRequest({ type: "General assistance", detail, location: "Campus", priority: "Normal" });
          pendingRef.current = null;
          await say("Your peer assistance request has been submitted.");
          return;
        }
        if (/^(no|cancel|cancel request)$/.test(command)) {
          pendingRef.current = null;
          await say("I cancelled the assistance request. Nothing was submitted.");
          return;
        }
        pendingRef.current.detail = text;
        await say(`You said: ${text}. Should I submit this peer assistance request? Say confirm or cancel.`);
        return;
      }
      if (/^(read|tell me|what is) (my )?(timetable|schedule|classes)$/.test(command) || /read my timetable|my timetable|today.s classes/.test(command)) {
        await readTimetable();
        return;
      }
      if (/learning materials|study materials|course materials|my materials/.test(command)) {
        await readMaterials();
        return;
      }
      if (/^(send|trigger|activate) (an )?(sos|emergency alert)$/.test(command) || command === "sos" || command === "send sos") {
        pendingRef.current = { type: "sos" };
        await say("You are asking me to record an emergency SOS alert. The current server does not send notifications to responders. If you need immediate help, contact campus security or local emergency services. Do you still want me to record the alert? Say confirm SOS or cancel SOS.");
        return;
      }
      if (/peer assistance|request help|request a volunteer|peer support/.test(command)) {
        pendingRef.current = { type: "peer", detail: "Student requested peer assistance." };
        await say("I can submit a peer assistance request. Please tell me what help you need and where you are on campus.");
        return;
      }
      if (/i need help|help me|what can you do/.test(command)) {
        await say("I can read your timetable, find your published learning materials, open campus navigation, help you request peer assistance, explain accessibility settings, and guide you through emergency options. You can speak naturally and interrupt me by speaking when the microphone is listening. What would you like help with?");
        return;
      }
      const destination = ROUTES.find((route) => route.words.some((word) => command === word || command.includes(word) || command.includes(`open ${word}`) || command.includes(`go to ${word}`)));
      if (destination) {
        navigate(destination.path);
        await say(`Opening ${destination.words[0]}. You can continue speaking whenever you are ready.`);
        return;
      }
      const history = [...conversationRef.current, { role: "user", content: text }].slice(-8);
      const data = await api.chatWithUniPal({
        message: text,
        language,
        locale,
        profile: { accessibility: "voice-first", preferences: { theme, fontSize } },
        messages: history,
      });
      const reply = data?.message || "I could not get an answer just now. Please try asking in a different way.";
      conversationRef.current = [...history, { role: "assistant", content: reply }].slice(-8);
      await say(reply);
    } catch (error) {
      const message = error?.message || "I could not complete that request.";
      setProblem(message);
      await say(`I could not complete that. ${message}`);
    } finally {
      processingRef.current = false;
      if (activeRef.current && !speakingRef.current) scheduleRestart(500);
    }
  }, [executeSOS, language, locale, navigate, readMaterials, readTimetable, say, theme, fontSize]);

  const handleUtteranceRef = useRef(handleUtterance);
  useEffect(() => { handleUtteranceRef.current = handleUtterance; }, [handleUtterance]);

  useEffect(() => {
    if (!enabled) {
      activeRef.current = false;
      void stopRecognition();
      stopSpeaking();
      speakingRef.current = false;
      setStatus("Voice assistant paused");
      return undefined;
    }
    activeRef.current = true;
    void startListening();
    if (!greetedRef.current) {
      greetedRef.current = true;
      void say("Hello. I am UniPal, your UniAble companion. Your hands-free voice assistant is ready. You can ask me to read your timetable, open your learning materials, navigate campus, or help you request support. What would you like to do?");
    } else {
      scheduleRestart(250);
    }
    return () => {
      activeRef.current = false;
      void stopRecognition();
      stopSpeaking();
      speakingRef.current = false;
    };
  }, [enabled, say, startListening, stopRecognition]);


  if (!enabled) return null;

  return (
    <aside className="uniable-handsfree" role="status" aria-live="polite" aria-atomic="true" style={{ position: "fixed", right: 16, bottom: 92, zIndex: 1200, width: "min(360px, calc(100vw - 32px))", display: "flex", alignItems: "flex-start", gap: 12, padding: 14, borderRadius: 14, border: "1px solid var(--border, #555)", background: "var(--surface, #171717)", color: "var(--text, #fff)", boxShadow: "0 8px 28px rgba(0,0,0,.28)" }}>
      <span className={`uniable-handsfree-indicator ${status.toLowerCase().includes("listen") ? "is-listening" : ""}`} aria-hidden="true" style={{ flex: "0 0 10px", width: 10, height: 10, marginTop: 5, borderRadius: "50%", background: status.toLowerCase().includes("listen") ? "#22c55e" : "#9ca3af" }} />
      <div className="uniable-handsfree-copy" style={{ minWidth: 0, display: "grid", gap: 4, overflowWrap: "anywhere" }}>
        <strong>UniPal · {status}</strong>
        <span>{lastHeard ? `You said: ${lastHeard}` : lastReply}</span>
        {problem && <span className="uniable-handsfree-error" style={{ color: "#fca5a5" }}>{problem}</span>}
      </div>
    </aside>
  );
}
