import React, { useCallback, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { speak, stopSpeaking } from "../services/speechService";

const FIELD_STEPS = [
  ["fullName", "first name or names", "Please say your first name or names."],
  ["surname", "surname", "Please say your surname."],
  ["studentNumber", "student number", "Please say your student number, digit by digit."],
  ["qualification", "Richfield qualification", "Please say the name of your Richfield qualification. You can also say skip and choose it later."],
  ["dateOfBirth", "date of birth", "Please say your date of birth, for example, 15 March 2002."],
  ["yearOfStudy", "year of study", "Please say your year of study, for example 2026."],
  ["modules", "registered modules", "Please say your registered module codes or names."],
  ["phoneNumber", "cellphone number", "Please say your cellphone number, including the country code if possible."],
  ["accountType", "account type", "Your account type is Student. I will select Student for you."],
  ["accessibility", "accessibility needs", "Please say your accessibility needs, such as visual, hearing, mobility, speech, neurodiverse support, other, or no accessibility needs."],
  ["additionalNeeds", "additional support information", "Would you like to add any other information about the support you need? Say skip if not."],
  ["email", "Richfield email address", "Please say your Richfield email address. For example, student at richfield dot ac dot za."],
];

const clean = (value) => String(value || "").toLowerCase().replace(/[^a-z0-9@.+ ]/g, " ").replace(/\s+/g, " ").trim();
const isStop = (value) => /^(stop|stop talking|stop speaking|stop reading|be quiet|quiet|silence|cancel speech|enough)$/.test(clean(value));

function setReactField(element, value) {
  if (!element) return false;
  const prototype = element instanceof HTMLSelectElement
    ? HTMLSelectElement.prototype
    : element instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
  if (setter) setter.call(element, value);
  else element.value = value;
  element.dispatchEvent(new Event("input", { bubbles: true }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
  element.dispatchEvent(new Event("blur", { bubbles: true }));
  return true;
}

function normaliseEmail(value) {
  return String(value || "").toLowerCase().trim()
    .replace(/\bat\s+the\s+rate\b|\bat\s+sign\b|\bat\b/g, "@")
    .replace(/\bdot\b/g, ".").replace(/\s+/g, "");
}

function spokenDigits(value) {
  const words = { zero: "0", oh: "0", one: "1", two: "2", three: "3", four: "4", five: "5", six: "6", seven: "7", eight: "8", nine: "9" };
  return String(value || "").toLowerCase().split(/\s+/).map((part) => words[part] ?? part).join("").replace(/[^0-9]/g, "");
}

function spokenDate(value) {
  const raw = String(value || "").trim();
  const direct = raw.match(/^(\d{1,2})[ /-](\d{1,2})[ /-](\d{4})$/);
  if (direct) return `${direct[3]}-${direct[2].padStart(2, "0")}-${direct[1].padStart(2, "0")}`;
  const parsed = new Date(raw);
  if (!Number.isNaN(parsed.getTime()) && /\b(19|20)\d{2}\b/.test(raw)) {
    return `${parsed.getFullYear()}-${String(parsed.getMonth() + 1).padStart(2, "0")}-${String(parsed.getDate()).padStart(2, "0")}`;
  }
  return "";
}

export default function PublicVoiceGuide() {
  const location = useLocation();
  const navigate = useNavigate();
  const recognitionRef = useRef(null);
  const activeRef = useRef(false);
  const busyRef = useRef(false);
  const routeRef = useRef("");
  const stepRef = useRef(0);
  const pendingRef = useRef(null);
  const reviewRef = useRef(false);
  const signupReadyRef = useRef(false);
  const verificationAnnouncedRef = useRef(false);
  const verificationCodePendingRef = useRef(null);
  const currentPathRef = useRef(location.pathname);
  const restartRef = useRef(null);

  const stopListening = useCallback(() => {
    activeRef.current = false;
    if (restartRef.current) window.clearTimeout(restartRef.current);
    restartRef.current = null;
    try { recognitionRef.current?.stop(); } catch { /* already stopped */ }
  }, []);

  const startListening = useCallback(() => {
    if (!activeRef.current) return;
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) return;
    try {
      let recognition = recognitionRef.current;
      if (!recognition) {
        recognition = new Recognition();
        recognition.lang = "en-ZA";
        recognition.continuous = true;
        recognition.interimResults = false;
        recognition.maxAlternatives = 4;
        recognition.onresult = (event) => {
          const result = event.results?.[event.resultIndex || 0];
          const transcript = Array.from(result || []).map((item) => item.transcript || "").sort((a, b) => b.length - a.length)[0] || "";
          if (transcript.trim()) void handleSpeechRef.current(transcript.trim());
        };
        recognition.onerror = (event) => {
          if (["not-allowed", "service-not-allowed"].includes(event.error)) {
            activeRef.current = false;
            window.dispatchEvent(new CustomEvent("uniable-voice-guide-status", { detail: "Microphone permission is required. Allow microphone access and reload the page." }));
          }
        };
        recognition.onend = () => {
          if (activeRef.current && !busyRef.current) {
            restartRef.current = window.setTimeout(() => startListeningRef.current(), 350);
          }
        };
        recognitionRef.current = recognition;
      }
      recognition.start();
    } catch (error) {
      if (error?.name !== "InvalidStateError") console.warn("Public voice guide could not start:", error);
    }
  }, []);

  const startListeningRef = useRef(startListening);
  startListeningRef.current = startListening;

  const say = useCallback(async (message) => {
    busyRef.current = true;
    try {
      await new Promise((resolve) => {
        let finished = false;
        const finish = () => { if (!finished) { finished = true; resolve(); } };
        speak(message, { locale: "en-ZA", rate: 0.94, onEnd: finish, onError: finish })
          .then((result) => { if (!result?.started) finish(); })
          .catch((error) => { console.warn("Public voice guidance failed:", error); finish(); });
        // Keep recognition active during speech so the user can say "stop".
        // Non-stop recognition results are ignored while the assistant is speaking.
        if (activeRef.current) window.setTimeout(() => startListeningRef.current(), 80);
      });
    } finally {
      busyRef.current = false;
      if (activeRef.current) {
        restartRef.current = window.setTimeout(() => startListeningRef.current(), 250);
      }
    }
  }, []);

  const promptSignupField = useCallback(async (index) => {
    const [name, label, prompt] = FIELD_STEPS[index] || [];
    if (!name) return;
    stepRef.current = index;
    const input = document.querySelector(`[name="${name}"]`);
    if (!input) {
      await say(`I cannot see the ${label} field yet. I will try again in a moment.`);
      return;
    }
    input.focus?.();
    if (input instanceof HTMLSelectElement && name !== "accountType") {
      const options = Array.from(input.options).filter((option) => option.value).map((option) => option.textContent.trim());
      const sample = options.join(", ");
      await say(`${prompt} Available choices include: ${sample}.`);
      return;
    }
    if (name === "accountType") {
      setReactField(input, "student");
      pendingRef.current = { name, label, value: "Student" };
      await say("Your account type is Student. I have selected Student. Say confirm to continue.");
      return;
    }
    await say(prompt);
  }, [say]);

  const beginSignup = useCallback(async () => {
    if (signupReadyRef.current) return;
    signupReadyRef.current = true;
    // The existing sign-up screen initially opens in voice mode. Switch to its
    // accessible full form so the guide can populate the actual React fields.
    const switchButton = Array.from(document.querySelectorAll("button")).find((button) => /switch to typing/i.test(button.textContent || ""));
    if (switchButton) switchButton.click();
    await new Promise((resolve) => window.setTimeout(resolve, 500));
    const form = document.querySelector(".typing-signup");
    if (!form) {
      signupReadyRef.current = false;
      await say("The sign-up form is not ready. Please choose Switch to Typing once, then I can guide you through the fields.");
      return;
    }
    await say("The sign-up page is open. I will guide you through each field one at a time. After each answer, I will repeat what I heard and ask you to confirm it. I will not ask you to speak your password. We will enter that privately at the end. Let's begin.");
    await promptSignupField(0);
  }, [promptSignupField, say]);

  const finishSignupReview = useCallback(async () => {
    const summary = FIELD_STEPS.map(([name, label]) => {
      const element = document.querySelector(`[name="${name}"]`);
      let value = element?.value || "not provided";
      if (name === "accessibility" && element?.selectedOptions?.[0]) value = element.selectedOptions[0].textContent;
      if (name === "dateOfBirth" && value !== "not provided") {
        const parsed = new Date(`${value}T00:00:00`);
        if (!Number.isNaN(parsed.getTime())) value = parsed.toLocaleDateString("en-ZA", { day: "numeric", month: "long", year: "numeric" });
      }
      return `${label}: ${value}`;
    }).join(". ");
    reviewRef.current = true;
    await say(`Please review your information. ${summary}. Your password will remain private and will not be read aloud. Say change followed by the field name, or say continue if everything is correct.`);
  }, [say]);

  const handleSpeech = useCallback(async (transcript) => {
    const command = clean(transcript);
    if (!command) return;
    if (isStop(command)) {
      stopSpeaking();
      busyRef.current = false;
      window.dispatchEvent(new CustomEvent("uniable-voice-guide-status", { detail: "Speech stopped." }));
      return;
    }
    if (busyRef.current) return;
    const path = currentPathRef.current;

    if (path === "/") {
      if (/voice or text\s*(sign ?up|signup)|voice and text\s*(sign ?up|signup)/.test(command)) {
        await say("Would you prefer Voice Signup or Text Signup? Say Voice Signup or Text Signup.");
      } else if (/text\s*(sign ?up|signup)|typing\s*(sign ?up|signup)/.test(command)) {
        stopListening();
        try { window.sessionStorage.removeItem("uniable-voice-onboarding-active"); } catch { /* optional */ }
        await say("Opening text sign-up.");
        navigate("/signup?mode=text");
      } else if (/voice\s*(sign ?up|signup)|sign ?up|create account/.test(command)) {
        stopListening();
        try { window.sessionStorage.setItem("uniable-voice-onboarding-active", "1"); } catch { /* optional */ }
        await say("Opening the voice sign-up page.");
        navigate("/signup");
      } else if (/voice\s*login|speak.*login/.test(command)) {
        stopListening();
        try { window.sessionStorage.setItem("uniable-voice-onboarding-active", "1"); } catch { /* optional */ }
        await say("Opening Voice Login.");
        navigate("/voice-login");
      } else if (/email\s*login|email sign in|password login|login/.test(command)) {
        stopListening();
        try { window.sessionStorage.setItem("uniable-voice-onboarding-active", "1"); } catch { /* optional */ }
        await say("Opening Email Login.");
        navigate("/login");
      } else {
        await say("I heard you. Please say Voice Signup, Voice Login, or Email Login.");
      }
      return;
    }

    if (path === "/signup") {
      if (!signupReadyRef.current && !document.querySelector("#verification-heading")) { await beginSignup(); return; }
      if (document.querySelector("#verification-heading")) {
        const codeInput = document.querySelector("#verification-code");
        const phoneInput = document.querySelector("#verification-phone");
        if (/^(email otp|email verification|use email)$/.test(command)) {
          Array.from(document.querySelectorAll("button")).find((button) => /^email otp$/i.test(button.textContent.trim()))?.click();
          await say("Email verification has been selected. Say send code to my email when you are ready.");
          return;
        }
        if (/^(sms otp|text message|use sms)$/.test(command)) {
          Array.from(document.querySelectorAll("button")).find((button) => /^sms otp$/i.test(button.textContent.trim()))?.click();
          await say("SMS verification has been selected. Say your mobile number, then say send SMS code.");
          return;
        }
        if (phoneInput && !phoneInput.value && /[0-9]|zero|one|two|three|four|five|six|seven|eight|nine/.test(command)) {
          let number = transcript.trim();
          const digits = spokenDigits(number);
          if (digits.length >= 8) {
            number = digits.startsWith("0") ? `+27${digits.slice(1)}` : (number.startsWith("+") ? number : `+${digits}`);
            setReactField(phoneInput, number);
            await say(`I entered ${number} as your verification mobile number. Say send SMS code to continue.`);
          }
          return;
        }
        if (/^(send code|send email code|send code to my email|send sms code)$/.test(command)) {
          const label = phoneInput ? "Send SMS code" : "Send code to my email";
          Array.from(document.querySelectorAll("button")).find((button) => clean(button.textContent).includes(clean(label)))?.click();
          await say("I have requested your verification code. Check your email or phone. When you have the six-digit code, say the digits clearly.");
          return;
        }
        if (codeInput && /^\d{6}$/.test(spokenDigits(transcript))) {
          const code = spokenDigits(transcript);
          setReactField(codeInput, code);
          verificationCodePendingRef.current = code;
          await say("I captured six digits for your verification code. Say confirm code to verify it, or repeat the six digits. I will not read the code aloud.");
          return;
        }
        if (/^(confirm code|verify code|confirm|yes)$/.test(command) && codeInput?.value?.length === 6) {
          Array.from(document.querySelectorAll("button")).find((button) => /^verify code$/i.test(button.textContent.trim()))?.click();
          await say("I am submitting your verification code. I will tell you when verification is complete.");
          return;
        }
        if (/^(repeat|try again)$/.test(command) && codeInput) {
          setReactField(codeInput, "");
          await say("Please say the six-digit verification code again.");
          return;
        }
        await say("Your account details have been accepted. Choose Email OTP or SMS OTP, then say send code. After receiving the code, say the six digits and confirm code.");
        return;
      }
      if (!signupReadyRef.current) { await beginSignup(); return; }
      if (pendingRef.current) {
        if (/^(confirm|yes|correct|that's right|that is right|continue)$/.test(command)) {
          const pending = pendingRef.current;
          const input = document.querySelector(`[name="${pending.name}"]`);
          if (input && pending.name !== "accountType") setReactField(input, pending.value);
          pendingRef.current = null;
          const next = stepRef.current + 1;
          if (next < FIELD_STEPS.length) await promptSignupField(next);
          else await finishSignupReview();
          return;
        }
        if (/^(repeat|try again|again|no)$/.test(command)) {
          pendingRef.current = null;
          await promptSignupField(stepRef.current);
          return;
        }
      }
      if (reviewRef.current) {
        if (/^(yes|change something|i want to change)$/.test(command)) {
          await say("Which field would you like to change? Say change name, change surname, change student number, change qualification, change date of birth, change year of study, change modules, change cellphone number, change accessibility, change additional information, or change email.");
          return;
        }
        if (/^(continue|no|no changes|everything is correct|correct)$/.test(command)) {
          reviewRef.current = false;
          await say("Your information is confirmed. For account security, please enter your password and confirm password in the password fields. Do not speak your password aloud. When both fields are complete, say create account.");
          return;
        }
        const change = command.match(/(?:change|edit)\s+(first name|name|surname|student number|qualification|date of birth|year of study|modules|cellphone|phone number|accessibility|additional information|email)/);
        if (change) {
          const key = ({ "first name": "fullName", name: "fullName", surname: "surname", "student number": "studentNumber", qualification: "qualification", "date of birth": "dateOfBirth", "year of study": "yearOfStudy", modules: "modules", cellphone: "phoneNumber", "phone number": "phoneNumber", accessibility: "accessibility", "additional information": "additionalNeeds", email: "email" })[change[1]];
          const index = FIELD_STEPS.findIndex(([field]) => field === key);
          if (index >= 0) { reviewRef.current = false; await promptSignupField(index); }
          return;
        }
      }
      if (command === "create account" || command === "submit account" || command === "register") {
        const password = document.querySelector('[name="password"]')?.value;
        const confirmPassword = document.querySelector('[name="confirmPassword"]')?.value;
        if (!password || !confirmPassword) {
          await say("The password and confirm password fields are still empty. Please enter them privately, then say create account.");
          return;
        }
        const createButton = Array.from(document.querySelectorAll("button")).find((button) => /create account/i.test(button.textContent || ""));
        await say("Submitting your account details now.");
        createButton?.click();
        return;
      }
      const index = stepRef.current;
      const [name, label] = FIELD_STEPS[index] || [];
      const element = document.querySelector(`[name="${name}"]`);
      if (!element) { await beginSignup(); return; }
      let value = transcript.trim();
      if (/^(skip|none|no|not applicable)$/.test(command) && name === "additionalNeeds") value = "";
      if (name === "email") value = normaliseEmail(value);
      if (name === "studentNumber") value = spokenDigits(value);
      if (name === "phoneNumber") {
        const digits = spokenDigits(value);
        value = digits.startsWith("0") ? `+27${digits.slice(1)}` : (value.trim().startsWith("+") ? value.replace(/[\s()-]/g, "") : `+${digits}`);
      }
      if (name === "dateOfBirth") value = spokenDate(value);
      if (element instanceof HTMLSelectElement) {
        let selectCommand = command;
        if (name === "accessibility") {
          if (/blind|low vision|visually impaired/.test(command)) selectCommand = "visual impairment";
          else if (/deaf|hard of hearing|hearing loss/.test(command)) selectCommand = "hearing impairment";
          else if (/no (accessibility )?needs|none|not applicable/.test(command)) selectCommand = "no accessibility needs";
          else if (/wheelchair|mobility|walking support/.test(command)) selectCommand = "mobility support";
          else if (/speech|non verbal|stutter/.test(command)) selectCommand = "speech support";
          else if (/colour|color blind/.test(command)) selectCommand = "colour vision";
          else if (/adhd|autis|dyslex|neurodiv/.test(command)) selectCommand = "neurodiverse support";
        }
        const option = Array.from(element.options).filter((item) => item.value).sort((a, b) => {
          const aText = clean(`${a.textContent} ${a.value}`); const bText = clean(`${b.textContent} ${b.value}`);
          return Number(bText.includes(selectCommand)) - Number(aText.includes(selectCommand));
        }).find((item) => clean(`${item.textContent} ${item.value}`).includes(selectCommand) || selectCommand.includes(clean(item.textContent)));
        if (!option) {
          await say(`I could not match that to an available ${label}. Please say one of the options I listed, or use the keyboard to choose it.`);
          return;
        }
        value = option.value;
      }
      if (name === "dateOfBirth" && !value) { await say("I could not understand that date. Please say the day, month and year, for example 15 March 2002."); return; }
      if (name === "email" && !/^[^\s@]+@richfield\.ac\.za$/i.test(value)) { await say("That does not look like a Richfield student email address. Please say it again, including at richfield dot ac dot za."); return; }
      if (name === "studentNumber" && !/^\d{6,12}$/.test(value)) { await say("The student number should contain between six and twelve digits. Please say it again, digit by digit."); return; }
      if (name === "phoneNumber" && !/^\+?[1-9]\d{7,14}$/.test(value)) { await say("I could not confirm that cellphone number. Please say the full number with its country code."); return; }
      if (name === "accountType") value = "student";
      const display = element instanceof HTMLSelectElement ? Array.from(element.options).find((option) => option.value === value)?.textContent || value : value || "no additional information";
      if (name !== "accountType") setReactField(element, value);
      pendingRef.current = { name, label, value };
      await say(`I heard ${display} for ${label}. Say confirm if that is correct, or repeat to try again.`);
      return;
    }

    if (path === "/login" || path === "/voice-login") {
      const emailField = document.querySelector('input[type="email"]');
      const passwordField = document.querySelector('input[type="password"]');
      if (/^(voice login|open voice login)$/.test(command)) { navigate("/voice-login"); return; }
      if (/^(email login|password login)$/.test(command) && path !== "/login") { navigate("/login"); return; }
      if (/^(email sign in link|passwordless login|send me a sign in link)$/.test(command) && path === "/login") {
        const modeButton = Array.from(document.querySelectorAll("button")).find((button) => /email sign-in link/i.test(button.textContent || ""));
        modeButton?.click();
        await say("Email sign-in link has been selected. Say your email address, then say send link.");
        return;
      }
      if (!emailField?.value && (command.includes("@") || command.includes(" at ") || command.includes(" dot "))) {
        const email = normaliseEmail(transcript);
        if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          setReactField(emailField, email);
          await say(`I heard ${email}. Your email address has been entered. Passwords are private. Please enter your password using your secure keyboard or password manager, then say sign in.`);
        } else await say("I could not confirm that email address. Please say it again.");
        return;
      }
      if (/^(sign in|log in|login|submit)$/.test(command)) {
        if (path === "/login" && document.querySelector('button[type="submit"]')) {
          if (document.querySelector('button[type="submit"]')?.textContent?.toLowerCase().includes("email me")) {
            document.querySelector('button[type="submit"]')?.click();
            await say("Your secure sign-in link request has been submitted. Check your email inbox and open the link on this device.");
            return;
          }
        }
        if (passwordField && !passwordField.value) { await say("Your password field is empty. Please enter your password privately, then say sign in again."); return; }
        document.querySelector('form button[type="submit"]')?.click();
        await say("Your sign-in request is being processed. I will announce when your dashboard opens.");
        return;
      }
      if (emailField?.value) await say("I am ready. You can say sign in after entering your password privately, or say email sign-in link to use a secure email link.");
      else await say("Please say your email address. I will repeat it for confirmation. Your password must be entered privately.");
      return;
    }
  }, [beginSignup, finishSignupReview, navigate, promptSignupField, say, stopListening]);

  const handleSpeechRef = useRef(handleSpeech);
  handleSpeechRef.current = handleSpeech;

  useEffect(() => {
    const path = location.pathname;
    currentPathRef.current = path;
    if (!["/", "/signup", "/login", "/voice-login"].includes(path)) {
      stopListening();
      return undefined;
    }
    if (routeRef.current === path) return undefined;
    routeRef.current = path;
    signupReadyRef.current = false;
    verificationAnnouncedRef.current = false;
    verificationCodePendingRef.current = null;
    stepRef.current = 0;
    pendingRef.current = null;
    reviewRef.current = false;
    stopListening();
    activeRef.current = true;

    const timer = window.setTimeout(async () => {
      if (path === "/") {
        await say("Welcome to the UniAble landing page. Your options are Voice Signup or Text Signup, Voice Login, and Email Login. Say Voice Signup, Text Signup, Voice Login, or Email Login. I am listening for your choice.");
      } else if (path === "/signup") {
        const textMode = new URLSearchParams(location.search).get("mode") === "text";
        if (textMode) {
          const switchButton = Array.from(document.querySelectorAll("button")).find((button) => /switch to typing/i.test(button.textContent || ""));
          switchButton?.click();
          await say("The text sign-up page is open. You can complete the form using your preferred input method. Say switch to voice if you want spoken field guidance.");
          activeRef.current = false;
        } else {
          try { window.sessionStorage.setItem("uniable-voice-onboarding-active", "1"); } catch { /* optional */ }
          await beginSignup();
        }
      } else if (path === "/voice-login") {
        try { window.sessionStorage.setItem("uniable-voice-onboarding-active", "1"); } catch { /* optional */ }
        await say("The Voice Login page is open. I can capture your email address by voice. For your security, enter your password privately, then say sign in. You can also return to the landing page.");
      } else if (path === "/login") {
        try { if (window.sessionStorage.getItem("uniable-voice-onboarding-active") === "1") window.sessionStorage.setItem("uniable-public-voice-guide", "1"); } catch { /* optional */ }
        await say("The Email Login page is open. Your options are password sign-in or a secure email sign-in link. Say your email address to enter it by voice. Passwords are never spoken or recorded. Enter your password privately, then say sign in, or say email sign-in link.");
      }
      startListeningRef.current();
    }, 500);
    return () => { window.clearTimeout(timer); stopListening(); };
  }, [location.pathname, location.search, beginSignup, say, stopListening]);


  useEffect(() => {
    if (location.pathname !== "/signup") return undefined;
    const announceVerification = () => {
      if (document.querySelector("#verification-heading") && !verificationAnnouncedRef.current) {
        verificationAnnouncedRef.current = true;
        void say("Your account has been successfully created. The account verification page is now open. You can choose Email OTP or SMS OTP. Say Email OTP or SMS OTP to select your method.");
      }
    };
    const observer = new MutationObserver(announceVerification);
    observer.observe(document.body, { childList: true, subtree: true });
    announceVerification();
    return () => observer.disconnect();
  }, [location.pathname, say]);

  useEffect(() => () => { stopListening(); stopSpeaking(); }, [stopListening]);

  return <div className="sr-only" aria-live="polite" aria-atomic="true" data-uniable-public-voice-guide="true">UniAble voice guidance is active on this page.</div>;
}
