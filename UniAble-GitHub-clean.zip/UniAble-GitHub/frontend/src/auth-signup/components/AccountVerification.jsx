﻿import React, { useState } from "react";
import {
  startSpeechRecognition,
  speakText
} from "../services/speechService";

const spokenDigitMap = {
  zero: "0",
  oh: "0",
  one: "1",
  two: "2",
  three: "3",
  four: "4",
  five: "5",
  six: "6",
  seven: "7",
  eight: "8",
  nine: "9"
};

function convertSpokenDigits(transcript, allowPlus = false) {
  const tokens = transcript.toLowerCase().match(/[a-z]+|\d+/g) || [];

  if (tokens.length === 0) return null;

  const hasPlus = allowPlus && tokens[0] === "plus";
  const numberTokens = hasPlus ? tokens.slice(1) : tokens;

  if (numberTokens.length === 0) return null;

  let digits = "";

  for (const token of numberTokens) {
    if (/^\d+$/.test(token)) {
      digits += token;
    } else if (Object.prototype.hasOwnProperty.call(spokenDigitMap, token)) {
      digits += spokenDigitMap[token];
    } else {
      return null;
    }
  }

  return hasPlus ? `+${digits}` : digits;
}

export default function AccountVerification({
  stage, method, setMethod, phoneNumber, setPhoneNumber, code, setCode,
  busy, error, email, onSendEmail, onSendPhone, onVerify, onResend, onBack,
}) {
  const [isListening, setIsListening] = useState(false);
  const [voiceError, setVoiceError] = useState("");

  const inputStyle = {
    width: "100%",
    boxSizing: "border-box",
    padding: "13px",
    border: "1px solid #777",
    borderRadius: 9,
    fontSize: 16,
    marginTop: 7,
    marginBottom: 14
  };

  const buttonStyle = {
    padding: "12px 16px",
    borderRadius: 9,
    border: "1px solid currentColor",
    cursor: busy || isListening ? "wait" : "pointer",
    fontSize: 15,
    fontWeight: 600,
    margin: "5px 6px 5px 0"
  };

  function startVoiceInput(target) {
    if (busy || isListening) return;

    setVoiceError("");

    try {
      const recognition = startSpeechRecognition({
        onStart: () => {
          setIsListening(true);
        },

        onResult: (transcript) => {
          const spoken = transcript.trim();

          if (target === "method") {
            const answer = spoken.toLowerCase();

            if (answer.includes("email")) {
              setMethod("email");
              speakText("Email verification selected.");
            } else if (
              answer.includes("sms") ||
              answer.includes("text message") ||
              answer.includes("phone")
            ) {
              setMethod("sms");
              speakText("SMS verification selected.");
            } else {
              const message = "Please say email or SMS.";
              setVoiceError(message);
              speakText(message);
            }

            return;
          }

          if (target === "phone") {
            const number = convertSpokenDigits(spoken, true);

            if (!number || !/^\+[1-9]\d{7,14}$/.test(number)) {
              const message =
                "I could not recognise a valid international phone number. Please say plus, followed by your country code and phone number.";
              setVoiceError(message);
              speakText(message);
              return;
            }

            setPhoneNumber(number);
            speakText("Phone number entered. Please check it before sending your SMS code.");
            return;
          }

          if (target === "code") {
            const digits = convertSpokenDigits(spoken);

            if (!digits || !/^\d{6}$/.test(digits)) {
              const message =
                "I could not recognise exactly six digits. Please try saying the code one digit at a time.";
              setVoiceError(message);
              speakText(message);
              return;
            }

            setCode(digits);
            speakText("Six-digit code entered. You can now select Verify code.");
          }
        },

        onEnd: () => {
          setIsListening(false);
        },

        onError: (recognitionError) => {
          setIsListening(false);
          const message =
            recognitionError?.message || "Voice recognition failed. Please try again.";
          setVoiceError(message);
          speakText(message);
        }
      });

      if (!recognition) {
        setIsListening(false);
      }
    } catch (recognitionError) {
      setIsListening(false);
      const message =
        recognitionError?.message || "Unable to start voice recognition.";
      setVoiceError(message);
      speakText(message);
    }
  }

  function readInstructions() {
    if (stage === "choose") {
      speakText(
        "Account verification. Choose email or SMS. You can say email or SMS to select your preferred method."
      );
    } else if (method === "email") {
      speakText(
        "Enter the six-digit code sent to your email address. You can type the code or select the microphone button and say all six digits."
      );
    } else {
      speakText(
        "Enter the six-digit code sent to your mobile phone. You can type the code or select the microphone button and say all six digits."
      );
    }
  }

  return (
    <section
      aria-labelledby="verification-heading"
      style={{ maxWidth: 520, margin: "0 auto", padding: 18 }}
    >
      <h2 id="verification-heading">Verify your UniAble account</h2>

      <button
        type="button"
        style={buttonStyle}
        onClick={readInstructions}
        disabled={busy || isListening}
      >
        Read instructions aloud
      </button>

      <div id="uniable-phone-recaptcha" />

      {stage === "choose" ? (
        <>
          <p>Choose one method. You only need to verify using email or SMS.</p>
          <p><strong>Email address:</strong> {email || "Not available"}</p>

          <button
            type="button"
            style={buttonStyle}
            disabled={busy || isListening}
            onClick={() => startVoiceInput("method")}
          >
            {isListening ? "Listening..." : "Speak verification method"}
          </button>

          <p>Say email or SMS.</p>

          <div role="group" aria-label="Choose verification method">
            <button
              type="button"
              style={{
                ...buttonStyle,
                background: method === "email" ? "#e8eefc" : "transparent"
              }}
              aria-pressed={method === "email"}
              onClick={() => setMethod("email")}
              disabled={busy || isListening}
            >
              Email OTP
            </button>

            <button
              type="button"
              style={{
                ...buttonStyle,
                background: method === "sms" ? "#e8eefc" : "transparent"
              }}
              aria-pressed={method === "sms"}
              onClick={() => setMethod("sms")}
              disabled={busy || isListening}
            >
              SMS OTP
            </button>
          </div>

          {method === "email" && (
            <button
              type="button"
              style={buttonStyle}
              disabled={busy || isListening}
              onClick={onSendEmail}
            >
              {busy ? "Sending..." : "Send code to my email"}
            </button>
          )}

          {method === "sms" && (
            <>
              <label htmlFor="verification-phone">
                Mobile number (international format)
              </label>

              <input
                id="verification-phone"
                type="tel"
                autoComplete="tel"
                placeholder="+27821234567"
                value={phoneNumber}
                onChange={(event) => setPhoneNumber(event.target.value)}
                style={inputStyle}
                disabled={busy || isListening}
              />

              <button
                type="button"
                style={buttonStyle}
                disabled={busy || isListening}
                onClick={() => startVoiceInput("phone")}
              >
                Speak phone number
              </button>

              <button
                type="button"
                style={buttonStyle}
                disabled={busy || isListening}
                onClick={onSendPhone}
              >
                {busy ? "Sending..." : "Send SMS code"}
              </button>

              <p>
                Enter your number with the country code, for example +27 for South Africa.
                When speaking, say plus followed by the digits.
              </p>
            </>
          )}
        </>
      ) : (
        <>
          <p>
            Enter the six-digit code sent to {method === "email" ? email : phoneNumber}.
            The code expires after 10 minutes.
          </p>

          <label htmlFor="verification-code">
            Six-digit verification code
          </label>

          <input
            id="verification-code"
            type="text"
            inputMode="numeric"
            autoComplete="one-time-code"
            maxLength={6}
            pattern="[0-9]{6}"
            value={code}
            onChange={(event) =>
              setCode(event.target.value.replace(/\D/g, "").slice(0, 6))
            }
            style={inputStyle}
            disabled={busy || isListening}
          />

          <button
            type="button"
            style={buttonStyle}
            disabled={busy || isListening}
            onClick={() => startVoiceInput("code")}
          >
            {isListening ? "Listening..." : "Speak verification code"}
          </button>

          <p>Say the six digits one at a time.</p>

          <button
            type="button"
            style={buttonStyle}
            disabled={busy || isListening || code.length !== 6}
            onClick={onVerify}
          >
            {busy ? "Verifying..." : "Verify code"}
          </button>

          <button
            type="button"
            style={buttonStyle}
            disabled={busy || isListening}
            onClick={onResend}
          >
            Send another code
          </button>

          <button
            type="button"
            style={buttonStyle}
            disabled={busy || isListening}
            onClick={onBack}
          >
            Choose another method
          </button>
        </>
      )}

      {voiceError && (
        <p role="status" aria-live="polite" style={{ color: "#b00020", marginTop: 12 }}>
          {voiceError}
        </p>
      )}

      {error && (
        <p role="alert" style={{ color: "#b00020", marginTop: 12 }}>
          {error}
        </p>
      )}

      <p style={{ fontSize: 13, marginTop: 18 }}>
        Keep your verification code private. UniAble staff will never ask you to share it.
      </p>
    </section>
  );
}
