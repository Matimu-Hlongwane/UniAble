/* =========================================
   UNIABLE FORM VALIDATION
   ========================================= */

export function isValidEmail(email) {
    const emailPattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    return emailPattern.test(email);
}


export function validateSignUpForm(formData) {

    const errors = {};


    /* FULL NAME */

    if (!formData.fullName.trim()) {

        errors.fullName =
            "Please enter your full name.";

    }

    else if (formData.fullName.trim().length < 2) {

        errors.fullName =
            "Please enter a valid full name.";

    }


    if (!formData.surname?.trim()) errors.surname = "Please enter your surname.";
    if (!/^\d{6,12}$/.test(String(formData.studentNumber || "").trim())) errors.studentNumber = "Enter a valid student number (6–12 digits).";
    if (!formData.qualification) errors.qualification = "Choose your Richfield qualification.";
    if (!formData.yearOfStudy || !/^20\d{2}$/.test(String(formData.yearOfStudy))) errors.yearOfStudy = "Choose a valid year of study.";
    if (!formData.dateOfBirth || Number.isNaN(Date.parse(formData.dateOfBirth)) || new Date(formData.dateOfBirth) >= new Date()) errors.dateOfBirth = "Enter a valid date of birth in the past.";
    if (!/^\+?[1-9]\d{7,14}$/.test(String(formData.phoneNumber || "").replace(/[\s()-]/g, ""))) errors.phoneNumber = "Enter a valid international cellphone number, e.g. +27821234567 (do not add the leading 0).";
    const expectedStudentEmail = `${String(formData.studentNumber || "").trim()}@my.richfield.ac.za`;
    if (!formData.email?.trim() || formData.email.trim().toLowerCase() !== expectedStudentEmail.toLowerCase()) errors.email = "Your student email must be generated from your student number.";
    if (!formData.confirmPassword) errors.confirmPassword = "Please confirm your password.";
    else if (formData.confirmPassword !== formData.password) errors.confirmPassword = "Passwords do not match.";

    /* ACCESSIBILITY */

    if (!formData.accessibility) {

        errors.accessibility =
            "Please select an accessibility option.";

    }


    /* PASSWORD */

    if (!formData.password) {

        errors.password =
            "Please create a password.";

    }

    else if (formData.password.length < 8) {
        errors.password = "Password must contain at least 8 characters.";
    }
    else if (!/[A-Z]/.test(formData.password)) {
        errors.password = "Password must contain at least one uppercase letter.";
    }
    else if (!/[a-z]/.test(formData.password)) {
        errors.password = "Password must contain at least one lowercase letter.";
    }
    else if (!/[0-9]/.test(formData.password)) {
        errors.password = "Password must contain at least one number.";
    }
    else if (!/[^A-Za-z0-9]/.test(formData.password)) {
        errors.password = "Password must contain at least one special character.";
    }


    return errors;
}

