﻿import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Accessibility,
  Mic,
  Volume2,
  Mail,
  Eye,
  Ear,
  Accessibility as MobilityIcon,
  MessageCircle,
  Palette,
  Brain,
  ShieldAlert,
  Users,
  Globe,
  ArrowRight,
  MapPin,
  CalendarDays,
  Sparkles,
  Menu,
  X,
} from "lucide-react";
import "./LandingPrototype.css";

const dashboardTypes = [
  {
    title: "Visual",
    description: "A clearer way to experience campus",
    icon: Eye,
    className: "visual",
    features: ["Screen reader support", "Large text", "High contrast"],
  },
  {
    title: "Hearing",
    description: "Stay connected through visual information",
    icon: Ear,
    className: "hearing",
    features: ["Live captions", "Visual alerts", "Transcripts"],
  },
  {
    title: "Mobility",
    description: "Navigate campus with confidence",
    icon: MobilityIcon,
    className: "mobility",
    features: ["Accessible routes", "Building access", "Route planning"],
  },
  {
    title: "Speech",
    description: "Communicate in the way that works for you",
    icon: MessageCircle,
    className: "speech",
    features: ["Voice alternatives", "Quick responses", "Communication tools"],
  },
  {
    title: "Colour vision",
    description: "Make information easier to distinguish",
    icon: Palette,
    className: "colour",
    features: ["Colour filters", "Contrast options", "Clear visual labels"],
  },
  {
    title: "Neurodiverse",
    description: "A calmer, more personalised experience",
    icon: Brain,
    className: "neuro",
    features: ["Reduced distractions", "Reading support", "Personalised layout"],
  },
];

function DashboardPreview({ item }) {
  const Icon = item.icon;

  return (
    <article className={`landing-dashboard-card ${item.className}`}>
      <div className="landing-dashboard-heading">
        <span className="landing-dashboard-icon">
          <Icon size={19} aria-hidden="true" />
        </span>
        <div>
          <h3>{item.title}</h3>
          <p>{item.description}</p>
        </div>
      </div>

      <div className="landing-preview-window">
        <div className="landing-preview-sidebar">
          <span className="landing-preview-logo">U</span>
          <span className="landing-preview-nav active" />
          <span className="landing-preview-nav" />
          <span className="landing-preview-nav" />
          <span className="landing-preview-nav" />
        </div>

        <div className="landing-preview-content">
          <div className="landing-preview-topline">
            <span>Good morning, student</span>
            <span className="landing-preview-dot" />
          </div>
          <div className="landing-preview-banner">
            <strong>Your experience, your way.</strong>
            <span>Personalised support is ready.</span>
          </div>
          <div className="landing-preview-feature-grid">
            {item.features.map((feature) => (
              <div className="landing-preview-feature" key={feature}>
                <span className="landing-preview-feature-dot" />
                <span>{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </article>
  );
}

export default function Landing() {
  const [guestMessage, setGuestMessage] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <main className="landing-page" id="main-content">
      <a className="landing-skip-link" href="#landing-actions">
        Skip to main content
      </a>

      <section className="landing-hero">
        <header className="landing-header">
          <Link to="/" className="landing-logo" aria-label="UniAble home">
            <span className="landing-logo-icon">
              <Accessibility size={25} aria-hidden="true" />
            </span>
            <span>UniAble</span>
          </Link>

          <button
            className="landing-menu-toggle"
            type="button"
            aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileMenuOpen}
            onClick={() => setMobileMenuOpen((open) => !open)}
          >
            {mobileMenuOpen ? <X size={23} /> : <Menu size={23} />}
          </button>

          <nav
            className={`landing-nav ${mobileMenuOpen ? "is-open" : ""}`}
            aria-label="Main navigation"
          >
            <a href="#features" onClick={() => setMobileMenuOpen(false)}>Features</a>
            <a href="#dashboards" onClick={() => setMobileMenuOpen(false)}>Dashboards</a>
            <a href="#support" onClick={() => setMobileMenuOpen(false)}>Support</a>
            <a href="#landing-actions" onClick={() => setMobileMenuOpen(false)}>Get started</a>
          </nav>

          <span className="landing-language-label">
            <Globe size={15} aria-hidden="true" />
            South African languages
          </span>
        </header>

        <div className="landing-hero-content">
          <div className="landing-eyebrow">
            <Sparkles size={15} aria-hidden="true" />
            Inclusion starts with access
          </div>

          <h1>
            Campus life that
            <br />
            <span>works for you,</span> your way.
          </h1>

          <p className="landing-hero-description">
            Voice-first support for students with every kind of need.
            Navigate campus, connect with peers and talk to UniPal in
            your own language.
          </p>

          <div
            className="landing-entry-actions"
            id="landing-actions"
            aria-label="Choose how to access UniAble"
          >
            <Link className="landing-action-button landing-action-primary" to="/signup">
              <Mic size={19} aria-hidden="true" />
              Voice sign-up
            </Link>

            <Link className="landing-action-button landing-action-outline" to="/voice-login">
              <Volume2 size={19} aria-hidden="true" />
              Voice login
            </Link>

            <Link className="landing-action-button landing-action-outline" to="/login">
              <Mail size={19} aria-hidden="true" />
              Email login
            </Link>
          </div>

          <p className="landing-hero-note">
            Accessible tools. Personalised support. One campus community.
          </p>
        </div>

        <div className="landing-hero-bottom">
          <div className="landing-hero-benefit">
            <MapPin size={19} aria-hidden="true" />
            <span>Campus navigation</span>
          </div>
          <div className="landing-hero-benefit">
            <CalendarDays size={19} aria-hidden="true" />
            <span>Smart schedule</span>
          </div>
          <div className="landing-hero-benefit">
            <Users size={19} aria-hidden="true" />
            <span>Peer assistance</span>
          </div>
          <div className="landing-hero-benefit">
            <MessageCircle size={19} aria-hidden="true" />
            <span>UniPal companion</span>
          </div>
        </div>
      </section>

      <section className="landing-dashboards" id="dashboards">
        <div className="landing-section-heading">
          <span className="landing-section-kicker">Designed around you</span>
          <h2>One platform. Six personalised dashboards.</h2>
          <p>
            UniAble adapts its layout, colours, text and support tools
            to your accessibility preferences.
          </p>
        </div>

        <div className="landing-dashboard-grid">
          {dashboardTypes.map((item) => (
            <DashboardPreview item={item} key={item.title} />
          ))}
        </div>
      </section>

      <section className="landing-support" id="support">
        <div className="landing-support-copy">
          <span className="landing-section-kicker">Support when it matters</span>
          <h2>Your campus. Your people. Your support.</h2>
          <p>
            Get connected to the people and services that make university
            life safer, more accessible and more welcoming.
          </p>
        </div>

        <div className="landing-support-cards" id="features">
          <article className="landing-support-card">
            <span className="landing-support-icon peer">
              <Users size={23} aria-hidden="true" />
            </span>
            <h3>Peer assistance</h3>
            <p>Connect with fellow students for guidance and support.</p>
            <Link to="/peer-assistance">
              Explore peer support <ArrowRight size={15} />
            </Link>
          </article>

          <article className="landing-support-card">
            <span className="landing-support-icon emergency">
              <ShieldAlert size={23} aria-hidden="true" />
            </span>
            <h3>Emergency SOS</h3>
            <p>Reach campus support quickly when you need assistance.</p>
            <Link to="/emergency">
              Emergency support <ArrowRight size={15} />
            </Link>
          </article>

          <article className="landing-support-card">
            <span className="landing-support-icon campus">
              <MapPin size={23} aria-hidden="true" />
            </span>
            <h3>Campus navigation</h3>
            <p>Find buildings and explore accessible campus routes.</p>
            <Link to="/campus">
              Explore navigation <ArrowRight size={15} />
            </Link>
          </article>
        </div>
      </section>

      <section className="landing-language-strip">
        <span className="landing-language-symbol">
          <Globe size={25} aria-hidden="true" />
        </span>
        <div>
          <strong>Support in your language</strong>
          <p>Designed for South African students and multilingual experiences.</p>
        </div>
        <span className="landing-language-pill">English</span>
        <span className="landing-language-pill">isiZulu</span>
      </section>

      <footer className="landing-footer">
        <Link to="/" className="landing-footer-brand">
          <Accessibility size={19} aria-hidden="true" />
          UniAble
        </Link>
        <p>Designed for access. Built for everyone.</p>
        <button
          className="landing-guest-button"
          type="button"
          onClick={() =>
            setGuestMessage(
              "Guest access is not available yet. Please sign in or create an account."
            )
          }
        >
          Continue as guest
        </button>
        {guestMessage && (
          <p className="landing-status-message" role="status" aria-live="polite">
            {guestMessage}
          </p>
        )}
      </footer>
    </main>
  );
}
