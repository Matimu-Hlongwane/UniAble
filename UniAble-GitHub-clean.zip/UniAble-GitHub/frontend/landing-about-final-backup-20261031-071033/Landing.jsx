﻿import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Accessibility,
  Mic,
  Volume2,
  Mail,
  Eye,
  Ear,
  Accessibility as MobilityIcon,
  MessageCircle,
  Palette,
  Brain,
  ShieldAlert,
  Users,
  Globe,
  ArrowRight,
  MapPin,
  CalendarDays,
  Sparkles,
  Menu,
  X,
} from "lucide-react";
import "./LandingPrototype.css";

const dashboardTypes = [
  {
    title: "Visual",
    description: "A clearer way to experience campus",
    icon: Eye,
    className: "visual",
    features: ["Screen reader support", "Large text", "High contrast"],
  },
  {
    title: "Hearing",
    description: "Stay connected through visual information",
    icon: Ear,
    className: "hearing",
    features: ["Live captions", "Visual alerts", "Transcripts"],
  },
  {
    title: "Mobility",
    description: "Navigate campus with confidence",
    icon: MobilityIcon,
    className: "mobility",
    features: ["Accessible routes", "Building access", "Route planning"],
  },
  {
    title: "Speech",
    description: "Communicate in the way that works for you",
    icon: MessageCircle,
    className: "speech",
    features: ["Voice alternatives", "Quick responses", "Communication tools"],
  },
  {
    title: "Colour vision",
    description: "Make information easier to distinguish",
    icon: Palette,
    className: "colour",
    features: ["Colour filters", "Contrast options", "Clear visual labels"],
  },
  {
    title: "Neurodiverse",
    description: "A calmer, more personalised experience",
    icon: Brain,
    className: "neuro",
    features: ["Reduced distractions", "Reading support", "Personalised layout"],
  },
];

function DashboardPreview({ item }) {
  return <li className="landing-disability-item">{item.title}</li>;
}
export default function Landing() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <main className="landing-page" id="main-content">
      <a className="landing-skip-link" href="#landing-actions">
        Skip to main content
      </a>

      <section className="landing-hero">
        <header className="landing-header">
          <Link to="/" className="landing-logo" aria-label="UniAble home">
            <span className="landing-logo-icon">
              <Accessibility size={25} aria-hidden="true" />
            </span>
            <span>UniAble</span>
          </Link>

          <button
            className="landing-menu-toggle"
            type="button"
            aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileMenuOpen}
            onClick={() => setMobileMenuOpen((open) => !open)}
          >
            {mobileMenuOpen ? <X size={23} /> : <Menu size={23} />}
          </button>

          <nav
            className={`landing-nav ${mobileMenuOpen ? "is-open" : ""}`}
            aria-label="Main navigation"
          >
            
            <a href="#dashboards" onClick={() => setMobileMenuOpen(false)}>Disability Dashboards</a>
            <a href="#about" onClick={() => setMobileMenuOpen(false)}>About</a>
          </nav>


        </header>

        <div className="landing-hero-content">
          <div className="landing-eyebrow">
            
            Inclusion starts with access
          </div>

          <h1>
            Campus life that
            <br />
            <span>works for you,</span> your way.
          </h1>

          <p className="landing-hero-description">
            Voice-first support for students with every kind of need.
            Navigate campus, connect with peers and talk to UniPal in
            your own language.
          </p>

          <div
            className="landing-entry-actions"
            id="landing-actions"
            aria-label="Choose how to access UniAble"
          >
            <Link className="landing-action-button landing-action-primary" to="/signup">
              <Mic size={19} aria-hidden="true" />
              Voice sign-up
            </Link>

            <Link className="landing-action-button landing-action-outline" to="/voice-login">
              <Volume2 size={19} aria-hidden="true" />
              Voice login
            </Link>

            <Link className="landing-action-button landing-action-outline" to="/login">
              <Mail size={19} aria-hidden="true" />
              Email login
            </Link>
          </div>

          <p className="landing-hero-note">
            Accessible tools. Personalised support. One campus community.
          </p>
        </div>

        <div className="landing-hero-bottom">
          <div className="landing-hero-benefit">
            <MapPin size={19} aria-hidden="true" />
            <span>Campus navigation</span>
          </div>
          <div className="landing-hero-benefit">
            <CalendarDays size={19} aria-hidden="true" />
            <span>Smart schedule</span>
          </div>
          <div className="landing-hero-benefit">
            <Users size={19} aria-hidden="true" />
            <span>Peer assistance</span>
          </div>
          <div className="landing-hero-benefit">
            <MessageCircle size={19} aria-hidden="true" />
            <span>UniPal companion</span>
          </div>
        </div>
      </section>

      <section className="landing-dashboards" id="dashboards">
        <div className="landing-section-heading">
          <span className="landing-section-kicker">Designed around you</span>
          <h2>Disability Dashboards</h2>
          <p>
            UniAble adapts its layout, colours, text and support tools
            to your accessibility preferences.
          </p>
        </div>

        <div className="landing-dashboard-grid">
          {dashboardTypes.map((item) => (
            <DashboardPreview item={item} key={item.title} />
          ))}
        </div>
      </section>


      <section className="landing-about" id="about">
        <div className="landing-section-heading">
          <span className="landing-section-kicker">About UniAble</span>
          <h2>Access without limits. Education for everyone.</h2>
          <p>
            UniAble is an accessibility support platform designed to help
            higher education students participate in campus life with greater
            independence. It brings together accessible communication,
            campus navigation, peer assistance, emergency support and
            personalised tools in one place.
          </p>
        </div>
      </section>
            <section className="landing-language-strip" aria-labelledby="landing-language-title">
        <span className="landing-language-symbol">
          <Globe size={25} aria-hidden="true" />
        </span>
        <div>
          <strong id="landing-language-title">Support in your language</strong>
          <p>UniAble recognises South Africa's 12 official languages.</p>
          <ul className="landing-language-list">
            <li>isiZulu</li>
            <li>isiXhosa</li>
            <li>Afrikaans</li>
            <li>English</li>
            <li>Sepedi</li>
            <li>Setswana</li>
            <li>Sesotho</li>
            <li>siSwati</li>
            <li>itsonga</li>
            <li>Tshivenda</li>
            <li>isiNdebele</li>
            <li>South African Sign Language</li>
          </ul>
        </div>
      </section>

      <footer className="landing-footer">
        <Link to="/" className="landing-footer-brand">
          <Accessibility size={19} aria-hidden="true" />
          UniAble
        </Link>
        <p>Designed for access. Built for everyone.</p>
      </footer>
    </main>
  );
}


